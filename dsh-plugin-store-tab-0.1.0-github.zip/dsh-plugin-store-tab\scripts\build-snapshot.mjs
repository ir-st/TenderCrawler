#!/usr/bin/env node
/**
 * Generate `src/client/snapshot.data.js` from the live DSH plugin catalog.
 *
 * The plugin's data layer (`src/client/data.js`) ships a bundled fallback snapshot so the Store tab
 * still has content when every catalog mirror is unreachable. This script downloads the official
 * catalog with the same mirrors the client uses, keeps the most-starred entries (at most 300, all
 * categories represented when possible) and writes a plain-ESM module:
 *
 *   export const SNAPSHOT = { sourceUrl, generatedAt, plugins: RawCatalogEntry[] }
 *
 * Network is only used here; the client bundle never fetches at build time.
 *
 * Usage: node scripts/build-snapshot.mjs
 */

import { writeFileSync } from 'node:fs'
import { dirname, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'

/** Mirrors, tried in order. Keep in sync with DEFAULT_SOURCE_URLS in src/client/data.js. */
const SOURCE_URLS = Object.freeze([
  'https://cdn.jsdelivr.net/npm/dsh-plugin-catalog@latest/plugins.json',
  'https://unpkg.com/dsh-plugin-catalog@latest/plugins.json',
  'https://awesome-dsh-plugin.com/plugins.json',
])

/** Category ids, in the order data.js lists them. Keep in sync with CATEGORY_TITLES. */
const CATEGORY_IDS = Object.freeze([
  'agi', 'ui', 'usage', 'theme', 'model', 'identity', 'session', 'memory', 'tools', 'wsl',
  'browser', 'vision', 'voice', 'docs', 'skill', 'workflow', 'git', 'notify', 'dev', 'security',
  'remote', 'market', 'fun',
])

const MAX_ENTRIES = 300
/** The generated module must never exceed this (contract: <= ~400 KB). */
const MAX_FILE_BYTES = 400 * 1024
/** Aim slightly below the hard limit so a future catalog tweak cannot silently overflow it. */
const TARGET_FILE_BYTES = 390 * 1024
const REQUEST_TIMEOUT_MS = 30000
const OUT_FILE = resolve(dirname(fileURLToPath(import.meta.url)), '../src/client/snapshot.data.js')

/** Fetch a URL as JSON, aborting after `timeoutMs`. */
async function fetchJson(url) {
  const controller = new AbortController()
  const timer = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS)
  try {
    const response = await fetch(url, {
      signal: controller.signal,
      headers: { accept: 'application/json' },
      cache: 'no-store',
      credentials: 'omit',
    })
    if (!response || !response.ok) {
      throw new Error(`HTTP ${response && response.status} for ${url}`)
    }
    return await response.json()
  } finally {
    clearTimeout(timer)
  }
}

/** Download the first mirror that returns a valid catalog (object, plugins array, > 100 entries). */
async function fetchCatalog() {
  const failures = []
  for (const url of SOURCE_URLS) {
    try {
      const json = await fetchJson(url)
      if (!json || typeof json !== 'object' || !Array.isArray(json.plugins)) {
        throw new Error('payload has no plugins array')
      }
      if (json.plugins.length <= 100) {
        throw new Error(`payload only has ${json.plugins.length} plugins`)
      }
      return { plugins: json.plugins, sourceUrl: url }
    } catch (error) {
      failures.push(`${url} -> ${error && error.message ? error.message : String(error)}`)
    }
  }
  throw new Error(`could not download the plugin catalog:\n  ${failures.join('\n  ')}`)
}

/** Numeric star count for ranking; missing/invalid stars rank last. */
function starsOf(entry) {
  const value = entry && entry.stars
  return typeof value === 'number' && Number.isFinite(value) ? value : -1
}

function categoryOf(entry) {
  const value = entry && entry.category
  return typeof value === 'string' && CATEGORY_IDS.includes(value) ? value : ''
}

/** Names must be non-empty strings for an entry to be usable as a snapshot item. */
function isUsable(entry) {
  return Boolean(entry) && typeof entry === 'object' && !Array.isArray(entry)
    && typeof entry.name === 'string' && entry.name.trim() !== ''
}

/**
 * Pick at most `MAX_ENTRIES` entries: highest stars first, then guarantee that every category with
 * at least one catalog entry is represented by replacing the lowest-ranked non-unique entry.
 */
function selectEntries(catalog) {
  const usable = catalog.filter(isUsable)
  const ranked = usable
    .map((entry, index) => ({ entry, index }))
    .sort((a, b) => (
      starsOf(b.entry) - starsOf(a.entry)
      || String(a.entry.name).localeCompare(String(b.entry.name))
      || a.index - b.index
    ))

  const selected = ranked.slice(0, MAX_ENTRIES).map((item) => item.entry)
  const selectedSet = new Set(selected)
  const counts = new Map()
  for (const entry of selected) {
    const id = categoryOf(entry)
    if (id) counts.set(id, (counts.get(id) || 0) + 1)
  }

  for (const id of CATEGORY_IDS) {
    if (counts.get(id)) continue
    const candidate = ranked.find((item) => !selectedSet.has(item.entry) && categoryOf(item.entry) === id)
    if (!candidate) continue // category genuinely absent from the catalog
    // Replace the least-starred selected entry whose category has another representative.
    let replaced = false
    for (let i = selected.length - 1; i >= 0; i -= 1) {
      const currentCategory = categoryOf(selected[i])
      if (currentCategory && (counts.get(currentCategory) || 0) > 1) {
        counts.set(currentCategory, counts.get(currentCategory) - 1)
        selectedSet.delete(selected[i])
        selected[i] = candidate.entry
        selectedSet.add(candidate.entry)
        counts.set(id, 1)
        replaced = true
        break
      }
    }
    if (!replaced && selected.length < MAX_ENTRIES) {
      selected.push(candidate.entry)
      selectedSet.add(candidate.entry)
      counts.set(id, 1)
    }
  }

  // Re-sort after replacements so the snapshot reads as "top by stars".
  selected.sort((a, b) => (
    starsOf(b) - starsOf(a)
    || String(a.name).localeCompare(String(b.name))
  ))
  return selected
}

/** U+2028/U+2029 are legal in JSON but were historically illegal in raw JS string literals. */
function escapeJsonForJs(json) {
  return json.replace(/[\u2028\u2029]/g, (ch) => `\\u${ch.charCodeAt(0).toString(16).padStart(4, '0')}`)
}

/** Shorten descriptions so the generated module stays under the size limit. */
function withDescriptionCap(entry, cap) {
  if (!Number.isFinite(cap)) return entry
  const description = entry.description
  if (!description || typeof description !== 'object' || Array.isArray(description)) return entry
  const cut = (value) => {
    if (typeof value !== 'string' || value.length <= cap) return value
    const slice = value.slice(0, cap)
    const atSpace = slice.lastIndexOf(' ')
    return `${(atSpace > cap * 0.6 ? slice.slice(0, atSpace) : slice).trimEnd()}...`
  }
  return {
    ...entry,
    description: { ...description, zh: cut(description.zh), en: cut(description.en) },
  }
}

function renderModule(plugins, meta) {
  const body = plugins.map((entry) => `    ${escapeJsonForJs(JSON.stringify(entry))},`).join('\n')
  return [
    '// Generated by scripts/build-snapshot.mjs - do not edit by hand.',
    `// Source: ${meta.sourceUrl}`,
    `// Generated at: ${meta.generatedAt}`,
    `// Entries: ${plugins.length} (top by stars; every catalog category represented when possible)`,
    'export const SNAPSHOT = {',
    `  sourceUrl: ${JSON.stringify(meta.sourceUrl)},`,
    `  generatedAt: ${JSON.stringify(meta.generatedAt)},`,
    '  plugins: [',
    body,
    '  ],',
    '}',
    '',
  ].join('\n')
}

function bytesOf(text) {
  return Buffer.byteLength(text, 'utf8')
}

function formatKb(bytes) {
  return `${(bytes / 1024).toFixed(1)} KB`
}

async function main() {
  console.log(`[snapshot] fetching catalog from ${SOURCE_URLS.length} mirror(s) ...`)
  const catalog = await fetchCatalog()
  console.log(`[snapshot] got ${catalog.plugins.length} raw entries from ${catalog.sourceUrl}`)

  const selected = selectEntries(catalog.plugins)
  if (selected.length === 0) throw new Error('the catalog contains no usable plugin entries')

  const meta = {
    sourceUrl: catalog.sourceUrl,
    generatedAt: new Date().toISOString(),
  }

  const descriptionCaps = [Infinity, 480, 360, 280, 200, 140, 100]
  let plugins = null
  let text = ''
  let usedCap = null
  for (const cap of descriptionCaps) {
    const candidatePlugins = selected.map((entry) => withDescriptionCap(entry, cap))
    const candidateText = renderModule(candidatePlugins, meta)
    if (bytesOf(candidateText) <= TARGET_FILE_BYTES) {
      plugins = candidatePlugins
      text = candidateText
      usedCap = cap
      break
    }
  }

  if (!plugins) {
    // Extremely unlikely: shrink the entry list until it fits, always keeping at least one per category.
    const kept = selected.slice()
    while (kept.length > CATEGORY_IDS.length) {
      kept.pop()
      const candidateText = renderModule(kept.map((entry) => withDescriptionCap(entry, 100)), meta)
      if (bytesOf(candidateText) <= MAX_FILE_BYTES) {
        plugins = kept.map((entry) => withDescriptionCap(entry, 100))
        text = candidateText
        usedCap = 100
        break
      }
    }
    if (!plugins) throw new Error('could not fit the snapshot under the 400 KB limit')
    console.warn(`[snapshot] WARNING: reduced entry count to ${plugins.length} to respect the size limit`)
  }

  const size = bytesOf(text)
  if (size > MAX_FILE_BYTES) throw new Error(`generated snapshot is ${size} bytes, above the 400 KB limit`)

  writeFileSync(OUT_FILE, text, 'utf8')

  const represented = new Set(plugins.map((entry) => categoryOf(entry)).filter(Boolean))
  const withIcon = plugins.filter((entry) => typeof entry.icon === 'string' && entry.icon).length
  console.log('[snapshot] wrote', OUT_FILE)
  console.log(`[snapshot] entries: ${plugins.length} / ${selected.length} selected / ${catalog.plugins.length} catalog`)
  console.log(`[snapshot] categories represented: ${represented.size} / ${CATEGORY_IDS.length}`)
  console.log(`[snapshot] entries with declared icon: ${withIcon} (rest use owner avatars)`)
  console.log(`[snapshot] file size: ${size} bytes (${formatKb(size)}) — limit ${formatKb(MAX_FILE_BYTES)}`)
  console.log(`[snapshot] description trimming: ${Number.isFinite(usedCap) ? `${usedCap} chars/lang` : 'none'}`)
  console.log(`[snapshot] generatedAt: ${meta.generatedAt}`)
}

main().catch((error) => {
  console.error('[snapshot] FAILED:', error && error.message ? error.message : error)
  process.exit(1)
})
