# 插件商店 · dsh-plugin-store-tab

在 **DeepSeek Harness（DSH）** Web 界面的**插件**页里新增一个「商店」标签页：从 DSH 插件目录（社区维护）抓取插件的
**名称、图标、描述**，并支持**分类 / 能力标签筛选**、搜索、排序与详情查看。

![插件商店概览](docs/store-overview.png)

> 商店只读取公开目录数据，**不会安装任何插件**；安装仍走 DSH 自己的插件管理流程。
> 本项目是社区项目，与 DeepSeek 官方无隶属关系。

## 功能

- **插件目录抓取**：运行时拉取 `dsh-plugin-catalog` 的 `plugins.json`（8000+ 插件），依次尝试
  jsDelivr、unpkg、awesome-dsh-plugin.com 三个镜像；全部失败时回退到随包内置的快照（离线可用）。
- **名称 / 图标 / 描述**：卡片标题优先显示 npm 包名（仓库子目录条目显示子包名）；图标优先使用目录声明的
  插件图标，缺失时尝试作者头像，超时或失败后显示按名称生成的彩色字母图标，因此每张卡片都有图标。
- **标签筛选**：23 个分类（单选）与 10 个能力标签（多选，全部满足），与搜索词叠加过滤。
- **搜索**：匹配名称、npm 包名、作者、中英文描述、分类、能力，大小写不敏感。
- **排序**：最热（星标）、最新（收录时间）、名称。
- **详情页**：大图标、完整中英文简介、标签、星标/版本、目录名称、安装命令（可复制）、目录页与源代码链接。
- **状态处理**：骨架屏、错误重试、空目录、无匹配结果、加载更多（每页 60 个）。
- **中英双语**：跟随 DSH 界面语言（`ctx.locale`），文案由插件自己的 `pluginStore` 字典提供。
- **主题适配**：使用 DSH 设计 token（`--dsw-alias-*`），浅色/深色、焦点环、`prefers-reduced-motion` 均适配。

<table>
  <tr>
    <td><img src="docs/store-filtered.png" alt="按分类筛选" /></td>
    <td><img src="docs/store-detail.png" alt="插件详情页" /></td>
  </tr>
  <tr>
    <td align="center">按「UI 增强」分类筛选（1628 / 8281）</td>
    <td align="center">插件详情与安装命令</td>
  </tr>
</table>

## 要求

- DSH 0.2.1 及以上（Web 载体）
- 构建/测试需要 Node.js 20+（DSH 自身要求 22+）

## 安装

### 从 npm 安装（发布后）

```sh
dsh plugin --profile <profile> add dsh-plugin-store-tab
```

### 从本地目录或 Git 仓库安装

```sh
dsh plugin --profile <profile> add /absolute/path/to/dsh-plugin-store-tab
# 或
dsh plugin --profile <profile> add github:<owner>/<repo>
```

安装后打开**插件**页，在「已安装」之后会出现「商店」标签页。如果标签页没有出现，刷新页面一次；
仍不出现时重启 DSH（新安装的客户端 bundle 有进程内缓存）。

卸载：

```sh
dsh plugin --profile <profile> remove dsh-plugin-store-tab
```

## 数据来源与隐私

目录数据来自社区维护的 DeepSeek Harness 插件目录（CC0-1.0）：

- https://awesome-dsh-plugin.com
- npm 包 `dsh-plugin-catalog`（`plugins.json`）

商店只读取公开目录，**不上传任何内容、不接入分析或遥测**。目录地址集中定义在
`src/client/data.js` 的 `DEFAULT_SOURCE_URLS`，可替换为自己的 format 1 索引源。
图标是远程图片，加载时会向图片主机暴露用户 IP；无法访问时显示字母图标。

## 开发

```sh
npm install
npm run build      # 构建 lib/client.js
npm run verify     # 构建 + 全部测试（60 项）
npm run privacy    # 提交前隐私扫描（绝对路径 / 邮箱 / 令牌 / 带凭据 URL）
npm run snapshot   # 重新生成离线快照（需要网络）
```

### 目录结构

```
src/client/index.jsx          客户端入口：locale 字典、样式注入、plugins.tab 注册
src/client/data.js            目录抓取/规范化/标签/过滤/排序/控制器（无 React）
src/client/snapshot.data.js   离线回退快照（脚本生成，勿手改）
src/client/ui.jsx             商店 UI 组件
src/client/styles.js          作用域 CSS（ps- 前缀）
lib/index.js                  Host 行（空实现，仅让 bundle 可挂载）
lib/client.js                 构建产物（window.__ModuleLoader__ CJS 闭包）
scripts/                      构建、验证、快照生成脚本
tests/                        node:test 测试（bundle / 数据层 / SSR）
```

### 工作原理

- DSH 浏览器侧以 `window.__ModuleLoader__.load({ id, factory })` 加载单一客户端 bundle；
  `scripts/build-client.mjs` 用 esbuild 打包 `src/client/index.jsx` 并按该协议包一层 CJS 闭包。
- 插件通过 `ctx.slots.inject('plugins.tab', …)` 注册标签页，owner props 与 slot 生命周期由 DSH 管理。
- 数据层是纯 JavaScript：镜像回退、超时、5 分钟缓存、离线快照、分面统计、过滤/排序全部与 React 解耦，
  便于单元测试。
- 所有 UI 文案来自 `pluginStore` locale 命名空间（中英双语），不硬编码语言。

## 已知限制

- 不提供安装按钮：不同 DSH 版本的安装入口/权限不同，商店只展示来源信息与安装命令。
- 目录是第三方内容，插件名称/描述/图标由目录提供，本项目只做展示，不校验其真实性。
- 目录中仅少量条目声明了图标，其余显示按名称生成的字母图标。
- 目录约 1.8 MB（br 压缩后），首次加载需要下载；成功结果在页面内缓存 5 分钟。

## 贡献

欢迎 issue / PR。提交前请运行 `npm run verify` 与 `npm run privacy`，并确保没有把本地路径、令牌或个人信息写进仓库。

## License

MIT。目录数据来自 [awesome-dsh-plugin](https://awesome-dsh-plugin.com)（CC0-1.0），版权归其作者所有；
DSH 名称与商标归 DeepSeek 所有，本项目与官方无隶属关系。
