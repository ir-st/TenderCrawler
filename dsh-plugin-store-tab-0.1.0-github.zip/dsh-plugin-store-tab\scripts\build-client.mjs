#!/usr/bin/env node
/**
 * Build the browser bundle for the DSH Plugin Store tab.
 *
 * The DeepSeek Harness Web GUI loads a plugin client as ONE classic script that calls
 * `window.__ModuleLoader__.load({ id, factory })`. We therefore bundle `src/client/index.jsx`
 * with esbuild into a single CJS chunk and wrap the whole chunk in that loader call. The
 * factory receives the platform `require`, so only `react` / `react/jsx-runtime` may be
 * required at runtime.
 *
 * esbuild is a devDependency, resolved from this package's local `node_modules`.
 * The esbuild *native CLI* is spawned with inherited stdio (the JS API spawns a service with
 * piped stdio, which this sandbox blocks); it writes an unwrapped temp chunk that we wrap and
 * validate ourselves.
 *
 * Usage:
 *   node scripts/build-client.mjs
 *
 * Exit code is non-zero on any source, build, or output-validation problem.
 */

import { spawnSync } from 'node:child_process'
import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const SCRIPT_DIR = path.dirname(fileURLToPath(import.meta.url))
const PACKAGE_ROOT = path.resolve(SCRIPT_DIR, '..')
const NODE_MODULES = path.join(PACKAGE_ROOT, 'node_modules')
const PACKAGE_JSON = JSON.parse(fs.readFileSync(path.join(PACKAGE_ROOT, 'package.json'), 'utf8'))
const SRC_DIR = path.join(PACKAGE_ROOT, 'src', 'client')
const ENTRY = path.join(SRC_DIR, 'index.jsx')
const LIB_DIR = path.join(PACKAGE_ROOT, 'lib')
const OUTFILE = path.join(LIB_DIR, 'client.js')

const PLUGIN_ID = PACKAGE_JSON.name

/** Modules the factory may require at runtime (platform modules only). */
const PLATFORM_MODULES = new Set(['react', 'react/jsx-runtime'])
const ALLOWED_REQUIRES = PLATFORM_MODULES

/** Wrap the esbuild CJS output in the DSH browser module-loader protocol. */
const BANNER = `window.__ModuleLoader__.load({
  id: "${PLUGIN_ID}",
  factory: (require) => {
    var module = { exports: {} };
    var exports = module.exports;
`
const FOOTER = `
    return module.exports;
  }
});
`

const SOURCE_EXTENSIONS = new Set(['.js', '.jsx', '.mjs', '.cjs'])
const RELATIVE_SUFFIXES = ['', '.js', '.jsx', '.mjs', '.cjs', '.json']
const INDEX_SUFFIXES = ['index.js', 'index.jsx', 'index.mjs']

// ---------------------------------------------------------------------------------------------
// Source audit: only relative files and platform modules may be imported, no dynamic import().
// ---------------------------------------------------------------------------------------------

function listSourceFiles(dir) {
  const files = []
  if (!fs.existsSync(dir)) return files
  const walk = (current) => {
    const entries = fs.readdirSync(current, { withFileTypes: true })
    entries.sort((a, b) => a.name.localeCompare(b.name))
    for (const entry of entries) {
      const full = path.join(current, entry.name)
      if (entry.isDirectory()) {
        walk(full)
      } else if (SOURCE_EXTENSIONS.has(path.extname(entry.name))) {
        files.push(full)
      }
    }
  }
  walk(dir)
  return files
}

function lineOf(text, index) {
  let line = 1
  for (let i = 0; i < index && i < text.length; i += 1) {
    if (text.charCodeAt(i) === 10) line += 1
  }
  return line
}

function resolveRelativeImport(specifier, fromFile) {
  const base = path.resolve(path.dirname(fromFile), specifier)
  for (const suffix of RELATIVE_SUFFIXES) {
    const candidate = `${base}${suffix}`
    if (fs.existsSync(candidate) && fs.statSync(candidate).isFile()) return candidate
  }
  for (const indexName of INDEX_SUFFIXES) {
    const candidate = path.join(base, indexName)
    if (fs.existsSync(candidate) && fs.statSync(candidate).isFile()) return candidate
  }
  return null
}

function isInside(parent, child) {
  const relative = path.relative(parent, child)
  return relative !== '' && !relative.startsWith('..') && !path.isAbsolute(relative)
}

/**
 * Mask string literals, template literals, and comments so code-shape checks (dynamic import,
 * top-level `document`) do not trip over catalog descriptions that merely mention such text.
 * The returned string has the same length/newlines, so offsets still map to source lines.
 */
export function maskNonCode(text) {
  const chars = text.split('')
  const length = text.length
  const mask = (index) => {
    if (chars[index] !== '\n' && chars[index] !== '\r') chars[index] = ' '
  }
  let index = 0
  while (index < length) {
    const char = text[index]
    const next = text[index + 1]

    if (char === '/' && next === '/') {
      while (index < length && text[index] !== '\n') {
        mask(index)
        index += 1
      }
    } else if (char === '/' && next === '*') {
      mask(index)
      mask(index + 1)
      index += 2
      while (index < length && !(text[index] === '*' && text[index + 1] === '/')) {
        mask(index)
        index += 1
      }
      if (index < length) {
        mask(index)
        mask(index + 1)
        index += 2
      }
    } else if (char === '"' || char === "'") {
      const quote = char
      mask(index)
      index += 1
      while (index < length) {
        if (text[index] === '\\') {
          mask(index)
          if (index + 1 < length) mask(index + 1)
          index += 2
          continue
        }
        if (text[index] === quote) {
          mask(index)
          index += 1
          break
        }
        if (text[index] === '\n') break // unterminated string: stop at end of line
        mask(index)
        index += 1
      }
    } else if (char === '`') {
      mask(index)
      index += 1
      while (index < length) {
        if (text[index] === '\\') {
          mask(index)
          if (index + 1 < length) mask(index + 1)
          index += 2
          continue
        }
        if (text[index] === '`') {
          mask(index)
          index += 1
          break
        }
        mask(index)
        index += 1
      }
    } else {
      index += 1
    }
  }
  return chars.join('')
}

/**
 * Collect every static import/export specifier in a source file (single line statements,
 * bare `import 'x'` statements, and the common multi-line `import { ... } from 'x'` form),
 * plus dynamic `import(` calls and top-level `document` access.
 */
function scanSourceFile(file) {
  const text = fs.readFileSync(file, 'utf8')
  const code = maskNonCode(text)
  const relative = path.relative(PACKAGE_ROOT, file)
  const problems = []
  const specifiers = []

  const collect = (regexp) => {
    for (const match of text.matchAll(regexp)) {
      specifiers.push({ specifier: match[2], line: lineOf(text, match.index) })
    }
  }

  // `import ... from 'x'` / `export ... from 'x'` on one line.
  collect(/^(?:import|export)\b[^\n]*?\bfrom\s+(['"])([^'"]+)\1/gm)
  // Bare side-effect imports: `import 'x'`.
  collect(/^import\s+(['"])([^'"]+)\1/gm)
  // Multi-line named imports/exports: `import {\n ... \n} from 'x'`.
  collect(/^(?:import|export)\s*\{[^}]*\}\s*from\s+(['"])([^'"]+)\1/gm)

  const seen = new Set()
  for (const { specifier, line } of specifiers) {
    const key = `${specifier}@${line}`
    if (seen.has(key)) continue
    seen.add(key)

    if (specifier.startsWith('.')) {
      const resolved = resolveRelativeImport(specifier, file)
      if (!resolved) {
        problems.push(
          `${relative}:${line}: relative import '${specifier}' does not resolve to an existing file`,
        )
      } else if (!isInside(SRC_DIR, resolved)) {
        problems.push(
          `${relative}:${line}: relative import '${specifier}' escapes src/client (${path.relative(
            PACKAGE_ROOT,
            resolved,
          )})`,
        )
      }
    } else if (PLATFORM_MODULES.has(specifier)) {
      // Allowed platform module.
    } else {
      problems.push(
        `${relative}:${line}: non-platform import '${specifier}' (only relative files, react, react/jsx-runtime are allowed)`,
      )
    }
  }

  // Dynamic import() is forbidden: the bundle must be self-contained.
  for (const match of code.matchAll(/\bimport\s*\(/g)) {
    problems.push(
      `${relative}:${lineOf(code, match.index)}: dynamic import() is not allowed in the client bundle`,
    )
  }

  // Module top-level `document` access breaks SSR: it must be guarded inside a function.
  const lines = code.split(/\r?\n/)
  lines.forEach((line, index) => {
    if (!/^\S/.test(line)) return // only column-0 statements count as module top level
    if (!/\bdocument\b/.test(line)) return
    if (/typeof\s+document/.test(line)) return
    problems.push(
      `${relative}:${index + 1}: 'document' is used at module top level; guard it with typeof document !== 'undefined' inside a function (SSR safety)`,
    )
  })

  return { problems, specifiers: specifiers.length }
}

function auditSources() {
  if (!fs.existsSync(SRC_DIR)) {
    throw new Error(`source directory not found: ${path.relative(PACKAGE_ROOT, SRC_DIR)}`)
  }
  const files = listSourceFiles(SRC_DIR)
  if (files.length === 0) {
    throw new Error(`no client source files found under ${path.relative(PACKAGE_ROOT, SRC_DIR)}`)
  }
  const problems = []
  for (const file of files) problems.push(...scanSourceFile(file).problems)
  return { fileCount: files.length, problems }
}

// ---------------------------------------------------------------------------------------------
// Bundle output audit.
// ---------------------------------------------------------------------------------------------

function auditBundle(text) {
  const problems = []
  // Code-shape checks must ignore string literals, template literals, and comments: catalog
  // descriptions can legitimately contain text such as `import(` or `require(`.
  const code = maskNonCode(text)

  const expectedHead = `window.__ModuleLoader__.load({\n  id: "${PLUGIN_ID}",\n  factory: (require) => {`
  if (!text.startsWith(expectedHead)) {
    problems.push('bundle does not start with the expected window.__ModuleLoader__.load wrapper banner')
  }
  if (!text.includes(`id: "${PLUGIN_ID}"`)) {
    problems.push(`bundle is missing the plugin id "${PLUGIN_ID}"`)
  }
  if (!text.trimEnd().endsWith(FOOTER.trimEnd())) {
    problems.push('bundle does not end with the factory footer (return module.exports; })')
  }

  // Dynamic imports must never appear in the emitted chunk (code only).
  const dynamicImports = [...code.matchAll(/\bimport\s*\(/g)]
  for (const match of dynamicImports) {
    problems.push(
      `bundle contains a dynamic import() call at line ${lineOf(code, match.index)}`,
    )
  }

  // Static ESM imports cannot survive in a classic-script CJS chunk.
  code.split(/\r?\n/).forEach((line, index) => {
    if (/^import\b/.test(line)) {
      problems.push(`bundle has a top-level import statement at line ${index + 1}`)
    }
  })

  // Every real `require(...)` must be a literal platform module. Matches are found on the
  // masked code, then the specifier is read from the original text at the same offset.
  const requiredModules = new Set()
  for (const match of code.matchAll(/\brequire\s*\(/g)) {
    const afterCall = match.index + match[0].length
    const literal = /^\s*(['"])([^'"]+)\1\s*\)/.exec(text.slice(afterCall))
    if (!literal) {
      problems.push(
        `bundle has a non-literal require() call at line ${lineOf(code, match.index)}; only static platform requires are allowed`,
      )
      continue
    }
    const specifier = literal[2]
    requiredModules.add(specifier)
    if (!ALLOWED_REQUIRES.has(specifier)) {
      problems.push(
        `bundle requires '${specifier}', but only react / react/jsx-runtime may be required at runtime`,
      )
    }
  }

  return { problems, requiredModules: [...requiredModules] }
}

// ---------------------------------------------------------------------------------------------
// esbuild CLI.
// ---------------------------------------------------------------------------------------------

/**
 * Locate the installed esbuild native binary (no JS-API service, no network, no install).
 * @returns {{ binary: string, version: string }}
 */
function resolveEsbuild() {
  const platformPackage = `@esbuild/${process.platform}-${process.arch}`
  const executable = process.platform === 'win32' ? 'esbuild.exe' : 'esbuild'
  const candidates = [
    path.join(NODE_MODULES, platformPackage, executable),
    path.join(NODE_MODULES, '.bin', process.platform === 'win32' ? 'esbuild.cmd' : 'esbuild'),
  ]
  const binary = candidates.find((candidate) => fs.existsSync(candidate))
  if (!binary) {
    throw new Error(
      `esbuild binary not found under ${NODE_MODULES}; expected ${platformPackage}/${executable}`,
    )
  }
  let version = 'unknown'
  try {
    const manifest = path.join(NODE_MODULES, 'esbuild', 'package.json')
    version = JSON.parse(fs.readFileSync(manifest, 'utf8')).version ?? version
  } catch {
    // Version is informational only.
  }
  return { binary, version }
}

function runEsbuild(binary, args) {
  const result = spawnSync(binary, args, {
    cwd: PACKAGE_ROOT,
    stdio: 'inherit',
    windowsHide: true,
  })
  if (result.error) {
    throw new Error(`could not run esbuild (${path.relative(PACKAGE_ROOT, binary)}): ${result.error.message}`)
  }
  if (result.status !== 0) {
    const reason = result.signal ? `signal ${result.signal}` : `exit code ${result.status}`
    throw new Error(`esbuild failed (${reason})`)
  }
}

function esbuildArgs(rawRelative, metaRelative) {
  return [
    'src/client/index.jsx',
    '--bundle',
    '--format=cjs',
    '--platform=browser',
    '--target=es2022',
    '--jsx=automatic',
    '--external:react',
    '--external:react/jsx-runtime',
    '--define:process.env.NODE_ENV="production"',
    '--charset=utf8',
    '--legal-comments=none',
    `--outfile=${rawRelative}`,
    `--metafile=${metaRelative}`,
    '--log-level=warning',
  ]
}

// ---------------------------------------------------------------------------------------------
// Main.
// ---------------------------------------------------------------------------------------------

function main() {
  if (!fs.existsSync(ENTRY)) {
    throw new Error(`entry not found: ${path.relative(PACKAGE_ROOT, ENTRY)}`)
  }

  const audit = auditSources()
  if (audit.problems.length > 0) {
    throw new Error(`source import audit failed:\n  - ${audit.problems.join('\n  - ')}`)
  }
  console.log(
    `[build] source audit OK: ${audit.fileCount} file(s), relative files + platform modules only`,
  )

  const { binary, version } = resolveEsbuild()
  fs.mkdirSync(LIB_DIR, { recursive: true })

  const rawFile = path.join(LIB_DIR, '.client.raw.cjs')
  const metaFile = path.join(LIB_DIR, '.client.meta.json')
  const rawRelative = path.relative(PACKAGE_ROOT, rawFile)
  const metaRelative = path.relative(PACKAGE_ROOT, metaFile)

  const startedAt = Date.now()
  let raw
  let moduleCount = 0
  try {
    runEsbuild(binary, esbuildArgs(rawRelative, metaRelative))
    raw = fs.readFileSync(rawFile, 'utf8')
    try {
      const meta = JSON.parse(fs.readFileSync(metaFile, 'utf8'))
      moduleCount = Object.keys(meta.inputs ?? {}).length
    } catch {
      // Module count is informational only.
    }
  } finally {
    for (const temp of [rawFile, metaFile]) {
      try {
        if (fs.existsSync(temp)) fs.unlinkSync(temp)
      } catch {
        // Temp cleanup is best effort.
      }
    }
  }

  const wrapped = `${BANNER}${raw}${FOOTER}`
  const byteSize = Buffer.byteLength(wrapped, 'utf8')

  const auditResult = auditBundle(wrapped)
  if (auditResult.problems.length > 0) {
    throw new Error(`bundle validation failed:\n  - ${auditResult.problems.join('\n  - ')}`)
  }

  fs.writeFileSync(OUTFILE, wrapped, 'utf8')

  const elapsedMs = Date.now() - startedAt
  console.log(
    `[build] esbuild ${version}${moduleCount ? ` (${moduleCount} module(s))` : ''} in ${elapsedMs} ms`,
  )
  console.log(`[build] wrapper OK: window.__ModuleLoader__.load + id "${PLUGIN_ID}"`)
  console.log(`[build] runtime requires: ${auditResult.requiredModules.join(', ') || '(none)'}`)
  console.log(`[build] bundle size: ${byteSize} bytes (${(byteSize / 1024).toFixed(1)} KB)`)
  console.log('[build] OK')
}

/** Only run when invoked as a script; importing this module (e.g. from tests) is side-effect free. */
const isDirectRun = (() => {
  try {
    return path.resolve(fileURLToPath(import.meta.url)) === path.resolve(process.argv[1] ?? '')
  } catch {
    return false
  }
})()

if (isDirectRun) {
  try {
    main()
  } catch (error) {
    console.error(`[build] FAILED: ${error.message}`)
    process.exitCode = 1
  }
}
