/**
 * Store tab UI for the Plugins page.
 *
 * Rendered by the registration in `index.jsx` with `{ controller, t }` props:
 * - `controller` owns all catalog/filter/pagination state (see CONTRACT.md).
 * - `t` is the locale-bound translator for the `pluginStore` namespace.
 *
 * Optional props, used only to localize catalog text (`description.zh` / `.en`):
 * - `resolveText(text)` - locale service resolver, e.g. `ctx.locale.resolveText`.
 * - `lang` - `'zh' | 'en'`; wins over everything else.
 * When neither is supplied the UI sniffs the script of `t('title')`, so the
 * correct language is still chosen inside the real web GUI.
 *
 * Everything here is SSR-safe: no `document` / `window` / `navigator` access at
 * module scope, and browser-only APIs are guarded where they are used.
 */
import { useEffect, useMemo, useRef, useState, useSyncExternalStore } from 'react'

/** Deterministic palette for letter tiles when a remote icon cannot load. */
const LETTER_TILE_COLORS = ['#5b7cfa', '#c05c9e', '#2f9d8a', '#c98a2e', '#7a63d6', '#c25757', '#2c8fb0', '#6f8f34']

/** Cards in the loading skeleton grid. */
const SKELETON_CARDS = 8

/** Tag chips rendered on a card before the rest move to the detail view. */
const CARD_TAG_LIMIT = 3

const EMPTY_LIST = []
const EMPTY_SOURCE = { url: null, title: '', fetchedAt: null, offline: false }
const EMPTY_QUERY = { text: '', category: null, capabilities: EMPTY_LIST }
const EMPTY_FACETS = { categories: EMPTY_LIST, capabilities: EMPTY_LIST }

/** Small deterministic string hash (djb2) used for the letter-tile color. */
function hashText(text) {
  let hash = 5381
  for (let index = 0; index < text.length; index += 1) {
    hash = ((hash << 5) + hash + text.charCodeAt(index)) | 0
  }
  return Math.abs(hash)
}

/** Deterministic fallback tile: first ASCII letter of name/owner + stable color. */
function letterTile(plugin) {
  const name = typeof plugin.name === 'string' ? plugin.name : ''
  const title = typeof plugin.title === 'string' ? plugin.title : ''
  const owner = typeof plugin.owner === 'string' ? plugin.owner : ''
  const basis = `${owner}/${name || title}`
  const candidate = (name || title || owner).replace(/^@+/, '')
  const match = candidate.match(/[0-9a-z]/i)
  return {
    letter: match ? match[0].toUpperCase() : '?',
    color: LETTER_TILE_COLORS[hashText(basis) % LETTER_TILE_COLORS.length],
  }
}

/** Only absolute http(s) links are rendered; catalog data is third-party. */
function isHttpUrl(value) {
  return typeof value === 'string' && /^https?:\/\//i.test(value)
}

/**
 * Normalize the controller snapshot so missing optional fields never crash the
 * UI (handy for tests that seed a partial snapshot). Arrays keep their identity
 * so memoized derivations stay cheap.
 */
function readSnapshot(raw) {
  const state = raw && typeof raw === 'object' ? raw : {}
  const query = state.query && typeof state.query === 'object' ? state.query : EMPTY_QUERY
  const results = Array.isArray(state.results) ? state.results : EMPTY_LIST
  const plugins = Array.isArray(state.plugins) ? state.plugins : EMPTY_LIST
  const facets = state.facets && typeof state.facets === 'object' ? state.facets : EMPTY_FACETS
  const queryCapabilities = Array.isArray(query.capabilities) ? query.capabilities : EMPTY_LIST
  return {
    status: state.status || 'idle',
    refreshing: state.refreshing === true,
    error: state.error || null,
    source: state.source && typeof state.source === 'object' ? state.source : EMPTY_SOURCE,
    plugins,
    results,
    facets: {
      categories: Array.isArray(facets.categories) ? facets.categories : EMPTY_LIST,
      capabilities: Array.isArray(facets.capabilities) ? facets.capabilities : EMPTY_LIST,
    },
    query: {
      text: typeof query.text === 'string' ? query.text : '',
      category: query.category || null,
      capabilities: queryCapabilities,
    },
    sort: state.sort || 'stars',
    visible: typeof state.visible === 'number' ? state.visible : results.length,
    total: typeof state.total === 'number' ? state.total : results.length,
    hasMore: state.hasMore === true,
  }
}

/**
 * Active UI language for catalog copy. Preference is zh-first (the product UI
 * defaults to Chinese): only an explicit `lang: 'en'` or an English-looking
 * translated tab title switches to en. The translated title itself is the probe; when
 * no dictionary is bound (harness) it returns the key itself, so we stay zh.
 */
function pickLanguage(props, t) {
  if (props.lang === 'zh' || props.lang === 'en') return props.lang
  let probe = ''
  try {
    probe = typeof t === 'function' ? t('title') : ''
  } catch {
    probe = ''
  }
  if (typeof probe !== 'string' || !probe || probe === 'title') return 'zh'
  return /[\u4e00-\u9fff]/.test(probe) ? 'zh' : 'en'
}

/**
 * Localize `{ zh, en }` catalog text. `resolveText` (locale service) wins when
 * wired; otherwise pick by language and fall back to the other language so a
 * plugin is never described by an empty string.
 */
function localizeText(text, resolveText, lang) {
  if (typeof text === 'string') return text
  if (!text || typeof text !== 'object') return ''
  if (typeof resolveText === 'function') {
    let resolved = ''
    try {
      resolved = resolveText(text)
    } catch {
      resolved = ''
    }
    if (typeof resolved === 'string' && resolved) return resolved
  }
  if (lang === 'zh') {
    if (typeof text.zh === 'string' && text.zh) return text.zh
    if (typeof text.en === 'string' && text.en) return text.en
  } else {
    if (typeof text.en === 'string' && text.en) return text.en
    if (typeof text.zh === 'string' && text.zh) return text.zh
  }
  return ''
}

function pluginTitle(plugin) {
  return plugin.title || plugin.name || ''
}

/** Rendered card/detail icon: catalog icon, owner avatar, then letter tile. */
function PluginArtwork({ plugin, large }) {
  const primary = typeof plugin.icon === 'string' ? plugin.icon : ''
  const fallback = typeof plugin.avatar === 'string' ? plugin.avatar : ''
  const [source, setSource] = useState(primary || fallback)
  const [failed, setFailed] = useState(!primary && !fallback)
  const [loaded, setLoaded] = useState(false)

  useEffect(() => {
    const next = primary || fallback
    setSource(next)
    setFailed(!next)
    setLoaded(false)
  }, [primary, fallback])

  // Remote icons can hang (blocked hosts) instead of erroring: degrade to the letter tile on a timer.
  // Declared catalog icons get a longer budget; owner avatars are a best-effort fallback.
  useEffect(() => {
    if (failed || loaded || !source) return undefined
    const timer = setTimeout(() => setFailed(true), primary ? 2500 : 900)
    return () => clearTimeout(timer)
  }, [failed, loaded, primary, source])

  if (failed || !source) {
    const tile = letterTile(plugin)
    return (
      <span
        className={large ? 'ps-art ps-art-lg ps-art-letter' : 'ps-art ps-art-letter'}
        style={{ '--ps-letter-bg': tile.color }}
        aria-hidden="true"
      >
        {tile.letter}
      </span>
    )
  }

  return (
    <img
      className={large ? 'ps-art ps-art-lg' : 'ps-art'}
      src={source}
      width={large ? 56 : 48}
      height={large ? 56 : 48}
      loading="lazy"
      decoding="async"
      referrerPolicy="no-referrer"
      alt=""
      draggable={false}
      onLoad={() => setLoaded(true)}
      onError={() => {
        if (fallback && source !== fallback) setSource(fallback)
        else setFailed(true)
      }}
    />
  )
}

/** Inline refresh glyph (replaced by a spinner while a load is in flight). */
function RefreshIcon() {
  return (
    <svg className="ps-refresh-icon" viewBox="0 0 16 16" width="14" height="14" aria-hidden="true" focusable="false">
      <path
        d="M13.5 8a5.5 5.5 0 1 1-1.61-3.89M13.5 2.5V6H10"
        fill="none"
        stroke="currentColor"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  )
}

function Header({ t, state, countText, busy, onRefresh }) {
  return (
    <header className="ps-header">
      <div className="ps-heading">
        <h2 className="ps-title">{t('title')}</h2>
        <p className="ps-subtitle">{t('subtitle')}</p>
      </div>
      <div className="ps-header-actions">
        <span className="ps-count">{countText}</span>
        <button
          type="button"
          className="ps-refresh"
          onClick={onRefresh}
          disabled={busy}
          aria-label={t('refreshAria')}
          aria-busy={busy ? 'true' : 'false'}
          title={t('tooltipRefresh')}
        >
          {busy ? <span className="ps-spinner" aria-hidden="true" /> : <RefreshIcon />}
          <span>{t('refresh')}</span>
        </button>
      </div>
    </header>
  )
}

function Toolbar({ t, state, onText, onSort }) {
  return (
    <div className="ps-toolbar">
      <input
        className="ps-search"
        type="search"
        value={state.query.text}
        placeholder={t('searchPlaceholder')}
        aria-label={t('searchPlaceholder')}
        autoComplete="off"
        spellCheck={false}
        onChange={(event) => onText(event.target.value)}
      />
      <label className="ps-sort">
        <span className="ps-sort-label">{t('sortLabel')}</span>
        <select
          className="ps-select"
          value={state.sort}
          aria-label={t('sortLabel')}
          onChange={(event) => onSort(event.target.value)}
        >
          <option value="stars">{t('sortStars')}</option>
          <option value="added">{t('sortAdded')}</option>
          <option value="name">{t('sortName')}</option>
        </select>
      </label>
    </div>
  )
}

function CategoryChips({ t, categories, selected, language, resolveText, onSelect }) {
  return (
    <div className="ps-chip-row" role="group" aria-label={t('categoriesLabel')}>
      <span className="ps-chip-row-label">{t('categoriesLabel')}</span>
      <button
        type="button"
        className="ps-chip"
        aria-pressed={selected === null ? 'true' : 'false'}
        onClick={() => onSelect(null)}
      >
        {t('allCategories')}
      </button>
      {categories.map((category) => (
        <button
          type="button"
          className="ps-chip"
          key={category.id}
          aria-pressed={selected === category.id ? 'true' : 'false'}
          onClick={() => onSelect(selected === category.id ? null : category.id)}
        >
          <span>{localizeText(category.label, resolveText, language) || category.id}</span>
          {typeof category.count === 'number' ? (
            <span className="ps-chip-count" aria-hidden="true">
              {category.count}
            </span>
          ) : null}
        </button>
      ))}
    </div>
  )
}

function CapabilityChips({ t, capabilities, selected, language, resolveText, onToggle }) {
  return (
    <div className="ps-chip-row" role="group" aria-label={t('capabilitiesLabel')}>
      <span className="ps-chip-row-label">{t('capabilitiesLabel')}</span>
      {capabilities.map((capability) => (
        <button
          type="button"
          className="ps-chip"
          key={capability.id}
          aria-pressed={selected.includes(capability.id) ? 'true' : 'false'}
          onClick={() => onToggle(capability.id)}
        >
          <span>{localizeText(capability.label, resolveText, language) || capability.id}</span>
          {typeof capability.count === 'number' ? (
            <span className="ps-chip-count" aria-hidden="true">
              {capability.count}
            </span>
          ) : null}
        </button>
      ))}
    </div>
  )
}

function PluginCard({ plugin, t, labels, language, resolveText, onOpen }) {
  const description = localizeText(plugin.description, resolveText, language)
  const capabilities = Array.isArray(plugin.capabilities) ? plugin.capabilities : EMPTY_LIST
  const tags = []
  if (plugin.category && labels.categories[plugin.category]) tags.push(labels.categories[plugin.category])
  for (let index = 0; index < capabilities.length && tags.length < CARD_TAG_LIMIT; index += 1) {
    const label = labels.capabilities[capabilities[index]]
    if (label) tags.push(label)
  }
  const stars = typeof plugin.stars === 'number' ? plugin.stars : null
  const hasMeta = stars !== null || Boolean(plugin.npm)

  return (
    <button
      type="button"
      className="ps-card"
      data-plugin-id={plugin.id}
      onClick={() => onOpen(plugin.id)}
      aria-label={t('openDetail', { name: pluginTitle(plugin) })}
    >
      <PluginArtwork plugin={plugin} />
      <span className="ps-card-main">
        <span className="ps-card-title">{pluginTitle(plugin)}</span>
        {plugin.owner ? <span className="ps-card-owner">{plugin.owner}</span> : null}
        {description ? <span className="ps-card-desc">{description}</span> : null}
        {tags.length > 0 ? (
          <span className="ps-card-tags">
            {tags.map((label, index) => (
              <span className="ps-chip ps-chip-tiny" key={`${index}:${String(label)}`}>
                {localizeText(label, resolveText, language)}
              </span>
            ))}
          </span>
        ) : null}
        {hasMeta ? (
          <span className="ps-card-meta">
            {stars !== null ? <span className="ps-stars">{t('starsCount', { stars })}</span> : null}
            {plugin.npm ? (
              <span className="ps-badge" title={plugin.npm}>
                <span>{t('npmBadge')}</span>
                {plugin.version ? <span className="ps-badge-version">{plugin.version}</span> : null}
              </span>
            ) : null}
          </span>
        ) : null}
      </span>
    </button>
  )
}

function PluginGrid({ plugins, t, labels, language, resolveText, onOpen }) {
  return (
    <div className="ps-grid">
      {plugins.map((plugin) => (
        <PluginCard
          key={plugin.id}
          plugin={plugin}
          t={t}
          labels={labels}
          language={language}
          resolveText={resolveText}
          onOpen={onOpen}
        />
      ))}
    </div>
  )
}

function SkeletonGrid({ t }) {
  return (
    <div className="ps-loading" role="status">
      <p className="ps-loading-title">{t('loading')}</p>
      <p className="ps-loading-hint">{t('loadingHint')}</p>
      <div className="ps-grid ps-grid-skeleton" aria-hidden="true">
        {Array.from({ length: SKELETON_CARDS }, (unused, index) => (
          <div className="ps-card ps-card-skeleton" key={index}>
            <span className="ps-skeleton ps-skeleton-art" />
            <span className="ps-skeleton-lines">
              <span className="ps-skeleton ps-skeleton-line ps-skeleton-title" />
              <span className="ps-skeleton ps-skeleton-line" />
              <span className="ps-skeleton ps-skeleton-line ps-skeleton-short" />
            </span>
          </div>
        ))}
      </div>
    </div>
  )
}

function StatePanel({ title, children, actions, role, error }) {
  return (
    <div className="ps-state" role={role}>
      <h3 className="ps-state-title">{title}</h3>
      {children}
      {error ? <p className="ps-state-detail">{error}</p> : null}
      {actions ? <div className="ps-state-actions">{actions}</div> : null}
    </div>
  )
}

function DetailView({ plugin, t, labels, language, resolveText, onBack }) {
  const backRef = useRef(null)
  const timerRef = useRef(0)
  const [copyStatus, setCopyStatus] = useState(null)

  useEffect(() => {
    if (backRef.current && typeof backRef.current.focus === 'function') backRef.current.focus()
  }, [])

  useEffect(() => {
    setCopyStatus(null)
  }, [plugin.id])

  useEffect(
    () => () => {
      if (timerRef.current) clearTimeout(timerRef.current)
    },
    [],
  )

  const install = plugin.install || `dsh plugin --profile web add ${plugin.name || plugin.id}`

  const copyInstall = () => {
    const finish = (status) => {
      setCopyStatus(status)
      if (timerRef.current) clearTimeout(timerRef.current)
      timerRef.current = setTimeout(() => setCopyStatus(null), 2000)
    }
    if (typeof navigator === 'undefined' || !navigator.clipboard || typeof navigator.clipboard.writeText !== 'function') {
      finish('failed')
      return
    }
    let promise
    try {
      promise = navigator.clipboard.writeText(install)
    } catch {
      finish('failed')
      return
    }
    if (promise && typeof promise.then === 'function') promise.then(() => finish('copied'), () => finish('failed'))
    else finish('copied')
  }

  const description = localizeText(plugin.description, resolveText, language)
  const capabilities = Array.isArray(plugin.capabilities) ? plugin.capabilities : EMPTY_LIST
  const tags = []
  if (plugin.category) tags.push(labels.categories[plugin.category] || plugin.category)
  for (const capability of capabilities) tags.push(labels.capabilities[capability] || capability)

  const facts = []
  const title = pluginTitle(plugin)
  if (plugin.name && plugin.name !== title) facts.push({ id: 'catalogName', label: t('detailCatalogName'), value: plugin.name })
  if (plugin.owner) facts.push({ id: 'owner', label: t('detailOwner'), value: plugin.owner })
  if (plugin.category) facts.push({ id: 'category', label: t('detailCategory'), value: localizeText(labels.categories[plugin.category], resolveText, language) || plugin.category })
  if (capabilities.length > 0) {
    const names = capabilities.map((capability) => localizeText(labels.capabilities[capability], resolveText, language) || capability)
    facts.push({ id: 'capabilities', label: t('detailCapabilities'), value: names.join(', ') })
  }
  if (typeof plugin.stars === 'number') facts.push({ id: 'stars', label: t('detailStars'), value: t('starsCount', { stars: plugin.stars }) })
  if (plugin.version) facts.push({ id: 'version', label: t('detailVersion'), value: plugin.version })
  if (plugin.npm) facts.push({ id: 'npm', label: t('npmBadge'), value: plugin.npm })
  if (plugin.added) facts.push({ id: 'added', label: t('detailAdded'), value: plugin.added })

  const copyLabel = copyStatus === 'copied' ? t('copied') : copyStatus === 'failed' ? t('copyFailed') : t('copy')

  return (
    <section className="ps-detail" data-plugin-detail={plugin.id}>
      <button type="button" className="ps-back" ref={backRef} onClick={onBack}>
        {t('back')}
      </button>

      <div className="ps-detail-head">
        <PluginArtwork plugin={plugin} large />
        <div className="ps-detail-headings">
          <h2 className="ps-detail-title">{pluginTitle(plugin)}</h2>
          {plugin.owner ? <p className="ps-detail-owner">{plugin.owner}</p> : null}
        </div>
      </div>

      {description ? (
        <div className="ps-detail-section">
          <h3 className="ps-detail-heading">{t('detailDescription')}</h3>
          <p className="ps-detail-desc">{description}</p>
        </div>
      ) : null}

      {tags.length > 0 ? (
        <div className="ps-detail-section">
          <h3 className="ps-detail-heading">{t('detailTags')}</h3>
          <div className="ps-tag-row">
            {tags.map((label, index) => (
              <span className="ps-chip ps-chip-tiny" key={`${index}:${String(label)}`}>
                {localizeText(label, resolveText, language)}
              </span>
            ))}
          </div>
        </div>
      ) : null}

      <div className="ps-detail-section">
        <h3 className="ps-detail-heading">{t('detailSource')}</h3>
        <dl className="ps-facts" aria-label={t('detailSource')}>
          {facts.map((fact) => (
            <div className="ps-fact" key={fact.id}>
              <dt>{fact.label}</dt>
              <dd>{fact.value}</dd>
            </div>
          ))}
        </dl>
      </div>

      <div className="ps-detail-section">
        <h3 className="ps-detail-heading">{t('detailInstall')}</h3>
        <div className="ps-install">
          <code>{install}</code>
          <button type="button" className="ps-button" onClick={copyInstall}>
            <span aria-live="polite">{copyLabel}</span>
          </button>
        </div>
        <p className="ps-install-hint">{t('installHint')}</p>
      </div>

      {isHttpUrl(plugin.page) || isHttpUrl(plugin.repo) ? (
        <div className="ps-detail-section">
          <h3 className="ps-detail-heading">{t('detailLinks')}</h3>
          <div className="ps-links">
            {isHttpUrl(plugin.page) ? (
              <a className="ps-link" href={plugin.page} target="_blank" rel="noreferrer">
                {t('visitPage')}
              </a>
            ) : null}
            {isHttpUrl(plugin.repo) ? (
              <a className="ps-link" href={plugin.repo} target="_blank" rel="noreferrer">
                {t('visitRepo')}
              </a>
            ) : null}
          </div>
        </div>
      ) : null}
    </section>
  )
}

function SourceFooter({ t, source }) {
  const liveLabel = t('sourceLive')
  return (
    <footer className="ps-footer">
      <p className="ps-source">
        <span className="ps-source-label">{t('sourceLabel')}</span>
        <span className="ps-source-value">{source.offline ? t('sourceOffline') : source.title || liveLabel}</span>
        {!source.offline && isHttpUrl(source.url) ? (
          <span className="ps-source-url" title={source.url}>
            {source.url}
          </span>
        ) : null}
      </p>
      <p className="ps-attribution">{t('attribution')}</p>
    </footer>
  )
}

/** Top-level component rendered inside the Plugins page tab. */
export function StoreTab(props) {
  const { controller, t } = props
  const rawState = useSyncExternalStore(controller.subscribe, controller.getSnapshot, controller.getSnapshot)
  const state = readSnapshot(rawState)
  const language = pickLanguage(props, t)
  const resolveText = typeof props.resolveText === 'function' ? props.resolveText : null

  const [selectedId, setSelectedId] = useState(null)

  useEffect(() => {
    controller.load()
  }, [controller])

  const labels = useMemo(() => {
    const categories = {}
    for (const category of state.facets.categories) {
      if (category && category.id) categories[category.id] = category.label || category.id
    }
    const capabilities = {}
    for (const capability of state.facets.capabilities) {
      if (capability && capability.id) capabilities[capability.id] = capability.label || capability.id
    }
    return { categories, capabilities }
  }, [state.facets.categories, state.facets.capabilities])

  const selected = useMemo(() => {
    if (!selectedId) return null
    for (const plugin of state.plugins) {
      if (plugin.id === selectedId) return plugin
    }
    return null
  }, [selectedId, state.plugins])

  useEffect(() => {
    if (selectedId && !selected) setSelectedId(null)
  }, [selectedId, selected])

  const initialLoading = (state.status === 'idle' || state.status === 'loading') && state.plugins.length === 0
  const failedWithoutData = state.status === 'error' && state.plugins.length === 0
  const busy = state.refreshing || initialLoading
  const filtersActive = state.query.text.trim() !== '' || state.query.category !== null || state.query.capabilities.length > 0
  const countText = filtersActive
    ? t('countFiltered', { count: state.results.length, total: state.plugins.length })
    : t('count', { count: state.plugins.length })

  let body
  if (selected) {
    body = (
      <DetailView
        plugin={selected}
        t={t}
        labels={labels}
        language={language}
        resolveText={resolveText}
        onBack={() => setSelectedId(null)}
      />
    )
  } else if (initialLoading) {
    body = <SkeletonGrid t={t} />
  } else if (failedWithoutData) {
    body = (
      <StatePanel
        role="alert"
        title={t('errorTitle')}
        error={state.error}
        actions={
          <button type="button" className="ps-button ps-button-primary" onClick={() => controller.retry()}>
            {t('retry')}
          </button>
        }
      >
        <p className="ps-state-text">{t('errorDescription')}</p>
      </StatePanel>
    )
  } else if (state.plugins.length === 0) {
    body = (
      <StatePanel
        role="status"
        title={t('emptyTitle')}
        actions={
          <>
            <button type="button" className="ps-button ps-button-primary" onClick={() => controller.refresh()}>
              {t('refresh')}
            </button>
            {filtersActive ? (
              <button type="button" className="ps-button" onClick={() => controller.clearFilters()}>
                {t('clearFilters')}
              </button>
            ) : null}
          </>
        }
      >
        <p className="ps-state-text">{t('emptyDescription')}</p>
      </StatePanel>
    )
  } else if (state.results.length === 0) {
    body = (
      <StatePanel
        role="status"
        title={t('noMatches')}
        actions={
          <button type="button" className="ps-button ps-button-primary" onClick={() => controller.clearFilters()}>
            {t('clearFilters')}
          </button>
        }
      >
        <p className="ps-state-text">{t('noMatchesHint')}</p>
      </StatePanel>
    )
  } else {
    const shown = Math.min(state.visible, state.results.length)
    body = (
      <>
        <PluginGrid
          plugins={state.results.slice(0, shown)}
          t={t}
          labels={labels}
          language={language}
          resolveText={resolveText}
          onOpen={setSelectedId}
        />
        <div className="ps-more">
          <span className="ps-more-count">{t('showingMore', { shown, total: state.results.length })}</span>
          {state.hasMore ? (
            <button type="button" className="ps-button" onClick={() => controller.showMore()}>
              {t('showMore')}
            </button>
          ) : null}
        </div>
      </>
    )
  }

  return (
    <div className="ps-root" data-plugin-tab="store">
      <Header t={t} state={state} countText={countText} busy={busy} onRefresh={() => controller.refresh()} />

      <Toolbar
        t={t}
        state={state}
        onText={(text) => controller.setText(text)}
        onSort={(sort) => controller.setSort(sort)}
      />

      <div className="ps-filters">
        <CategoryChips
          t={t}
          categories={state.facets.categories}
          selected={state.query.category}
          language={language}
          resolveText={resolveText}
          onSelect={(category) => controller.setCategory(category)}
        />
        <CapabilityChips
          t={t}
          capabilities={state.facets.capabilities}
          selected={state.query.capabilities}
          language={language}
          resolveText={resolveText}
          onToggle={(capability) => controller.toggleCapability(capability)}
        />
      </div>

      {state.error && !initialLoading && !failedWithoutData ? (
        <div className="ps-banner" role="alert">
          <span>{state.error}</span>
          <button type="button" className="ps-button" onClick={() => controller.retry()}>
            {t('retry')}
          </button>
        </div>
      ) : null}

      {body}

      <SourceFooter t={t} source={state.source} />
    </div>
  )
}
