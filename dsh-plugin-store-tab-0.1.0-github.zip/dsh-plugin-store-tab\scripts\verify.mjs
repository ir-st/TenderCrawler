#!/usr/bin/env node
/**
 * One-command offline verification for the DSH Plugin Store tab.
 *
 *   1. builds `lib/client.js` from `src/client/index.jsx` (scripts/build-client.mjs),
 *   2. runs every `tests/*.test.mjs` with the Node test runner,
 *   3. prints a PASS summary (and exits non-zero on the first failure).
 *
 * Usage:
 *   node scripts/verify.mjs
 */

import { spawnSync } from 'node:child_process'
import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const SCRIPT_DIR = path.dirname(fileURLToPath(import.meta.url))
const PACKAGE_ROOT = path.resolve(SCRIPT_DIR, '..')
const BUILD_SCRIPT = path.join(SCRIPT_DIR, 'build-client.mjs')
const TESTS_DIR = path.join(PACKAGE_ROOT, 'tests')
const BUNDLE = path.join(PACKAGE_ROOT, 'lib', 'client.js')
const PACKAGE_JSON = JSON.parse(fs.readFileSync(path.join(PACKAGE_ROOT, 'package.json'), 'utf8'))

function run(label, args, cwd) {
  console.log(`\n[verify] > ${label}`)
  const result = spawnSync(process.execPath, args, {
    cwd,
    stdio: 'inherit',
    env: { ...process.env, NODE_ENV: 'test' },
  })
  if (result.error) throw result.error
  if (result.status !== 0) {
    const reason = result.signal
      ? `terminated by ${result.signal}`
      : `exit code ${result.status}`
    throw new Error(`${label} failed (${reason})`)
  }
}

function listTestFiles() {
  if (!fs.existsSync(TESTS_DIR)) return []
  return fs
    .readdirSync(TESTS_DIR)
    .filter((file) => file.endsWith('.test.mjs'))
    .sort()
}

/**
 * The node:test CLI spawns one child process per test file with piped stdio. Some sandboxed
 * environments block those pipes (spawn EPERM), in which case `node --test` cannot run at all.
 * Probe once; when unavailable, run each test file directly (`node tests/foo.test.mjs`), which
 * executes node:test in-process and still exits non-zero on failure.
 */
function canUseNodeTestRunner() {
  const probe = [
    "const { spawnSync } = require('node:child_process')",
    "const result = spawnSync(process.execPath, ['-e', '0'], { stdio: 'pipe' })",
    "process.exit(result.error && result.error.code === 'EPERM' ? 7 : 0)",
  ].join(';')
  const result = spawnSync(process.execPath, ['-e', probe], {
    stdio: 'ignore',
    windowsHide: true,
  })
  return result.status === 0
}

function runTests(testFiles) {
  if (canUseNodeTestRunner()) {
    run(`node --test tests/ (${testFiles.length} file(s))`, [
      '--test',
      '--test-reporter=spec',
      'tests/',
    ], PACKAGE_ROOT)
    return
  }
  console.log(
    '[verify] note: node --test is unavailable here (child-process pipes blocked); ' +
      'running each test file directly via node <file>',
  )
  for (const file of testFiles) {
    run(`node tests/${file}`, [path.join(TESTS_DIR, file)], PACKAGE_ROOT)
  }
}

function main() {
  console.log(`[verify] ${PACKAGE_JSON.name} — offline build + test verification`)
  console.log(`[verify] package: ${PACKAGE_ROOT}`)

  if (!fs.existsSync(BUILD_SCRIPT)) {
    throw new Error(`missing build script: ${path.relative(PACKAGE_ROOT, BUILD_SCRIPT)}`)
  }
  const testFiles = listTestFiles()
  if (testFiles.length === 0) {
    throw new Error(`no *.test.mjs files found in ${path.relative(PACKAGE_ROOT, TESTS_DIR)}`)
  }

  // 1. Build the browser bundle (fails loudly on wrapper/import/output problems).
  run(`build client bundle (${path.relative(PACKAGE_ROOT, BUILD_SCRIPT)})`, [BUILD_SCRIPT], PACKAGE_ROOT)

  if (!fs.existsSync(BUNDLE)) throw new Error('build finished but lib/client.js is missing')
  const bundleBytes = fs.statSync(BUNDLE).size
  console.log(
    `[verify] bundle OK: lib/client.js ${bundleBytes} bytes (${(bundleBytes / 1024).toFixed(1)} KB)`,
  )

  // 2. Run the whole offline test suite (bundle + SSR + data layer).
  runTests(testFiles)

  // 3. Summarize.
  console.log('\n[verify] ======================================')
  console.log(`[verify] PASS — ${PACKAGE_JSON.name}`)
  console.log(`[verify] bundle: lib/client.js (${bundleBytes} bytes)`)
  console.log(`[verify] tests:  ${testFiles.join(', ')}`)
  console.log('[verify] ======================================')
}

try {
  main()
} catch (error) {
  console.error(`\n[verify] FAILED: ${error.message}`)
  process.exitCode = 1
}
