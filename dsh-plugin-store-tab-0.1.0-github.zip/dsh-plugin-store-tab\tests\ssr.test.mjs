/**
 * SSR tests for the Store tab: render the captured StoreTab component with react-dom/server
 * against a fake controller seeded with realistic catalog entries. No network, no browser.
 *
 * Interaction-heavy paths (opening a detail view by clicking a card) cannot be exercised
 * without a DOM, so these tests assert grid-level contract output and drive filtering through
 * the controller API instead, which is exactly what the UI wires to its controls.
 */

import test from 'node:test'
import assert from 'node:assert/strict'

import {
  createFakeController,
  includesAny,
  react as React,
  renderToStaticMarkup,
  setupClient,
} from './harness.mjs'

const PLUGIN_NAMES = [
  'dsh-foo',
  'dsh-theme-night',
  'dsh-shell-tools',
  'dsh-memory-bank',
  'dsh-browser-pilot',
]

/**
 * Load + apply the bundle, then mount StoreTab with the registration inject face overridden
 * with the fake controller (so filtering is deterministic and offline).
 */
async function mountStore(options = {}) {
  const { registration, t, ctx } = await setupClient({ locale: options.locale })

  assert.ok(registration, 'no plugins.tab registration captured from apply()')
  assert.equal(typeof registration.component, 'function', 'registration component must be StoreTab')

  const controller = options.controller ?? createFakeController()
  const face = typeof registration.def.inject === 'function' ? registration.def.inject() : {}
  const props = { ...face, controller, t }

  const render = () =>
    renderToStaticMarkup(React.createElement(registration.component, props))

  return { render, controller, t, registration, ctx, props }
}

test('StoreTab renders the plugin grid with names, descriptions, icons and chips', async () => {
  const { render } = await mountStore()

  const html = render()

  // Header title.
  assert.ok(includesAny(html, ['商店', 'Store']), `expected the store title in:\n${html.slice(0, 600)}`)

  // Every seeded plugin has a card.
  for (const name of PLUGIN_NAMES) {
    assert.ok(html.includes(name), `expected card for "${name}" in rendered HTML`)
  }

  // Descriptions (either language is accepted; the fake controller exposes both).
  assert.ok(
    includesAny(html, [
      '把插件页面变成可筛选的商店：图标、简介与标签一屏浏览。',
      'Turns the Plugins page into a filterable storefront with icons, blurbs, and tags.',
    ]),
    'expected dsh-foo description text',
  )
  assert.ok(
    includesAny(html, [
      '在会话里执行 shell 命令，并读取环境变量。',
      'Run shell commands inside a session and read environment variables.',
    ]),
    'expected dsh-shell-tools description text',
  )

  // Icon URLs: declared catalog icon + GitHub avatar fallback for icon-less plugins.
  assert.ok(
    html.includes('https://raw.githubusercontent.com/github-owner/dsh-foo/main/icon.png'),
    'expected the declared plugin icon URL',
  )
  assert.ok(
    html.includes('https://github.com/night-owl.png?size=96'),
    'expected the GitHub owner avatar fallback for a plugin without an icon',
  )

  // Remote icon attributes required by the contract.
  assert.match(html, /loading="lazy"/)
  assert.match(html, /decoding="async"/)
  assert.match(html, /referrerpolicy="no-referrer"/i)

  // Category chips (localized labels come from the controller facets).
  assert.ok(includesAny(html, ['UI 增强', 'UI Enhancements']), 'expected a UI category chip')
  assert.ok(includesAny(html, ['主题', 'Themes']), 'expected a theme category chip')
  assert.ok(includesAny(html, ['记忆', 'Memory']), 'expected a memory category chip')

  // Capability chips.
  assert.ok(includesAny(html, ['终端命令', 'Shell']), 'expected a shell capability chip')
  assert.ok(includesAny(html, ['读取文件', 'File read']), 'expected an fs-read capability chip')
  assert.ok(includesAny(html, ['网络访问', 'Network']), 'expected a network capability chip')

  // Chips are toggle buttons.
  assert.match(html, /aria-pressed=/, 'expected aria-pressed chip buttons')

  // Grid state, not detail state.
  assert.ok(!html.includes('返回商店'), 'grid render must not contain the detail back button')
})

test('text search re-renders only matching cards', async () => {
  const { render, controller } = await mountStore()
  assert.ok(render().includes('dsh-shell-tools'), 'precondition: all plugins rendered')

  controller.setText('memory')
  const html = render()

  assert.ok(html.includes('dsh-memory-bank'), 'expected the matching memory plugin')
  for (const name of ['dsh-foo', 'dsh-theme-night', 'dsh-shell-tools', 'dsh-browser-pilot']) {
    assert.ok(!html.includes(name), `text search must hide "${name}"`)
  }
})

test('category filter narrows the grid to one category', async () => {
  const { render, controller } = await mountStore()

  controller.setCategory('theme')
  const html = render()

  assert.ok(html.includes('dsh-theme-night'), 'expected the theme plugin')
  for (const name of ['dsh-foo', 'dsh-shell-tools', 'dsh-memory-bank', 'dsh-browser-pilot']) {
    assert.ok(!html.includes(name), `category filter must hide "${name}"`)
  }
  assert.match(html, /aria-pressed="true"/, 'selected category chip must be pressed')
})

test('capability chips filter as an AND intersection and show the empty state', async () => {
  const { render, controller } = await mountStore()

  controller.toggleCapability('shell')
  let html = render()
  assert.ok(html.includes('dsh-shell-tools'), 'expected the shell-capable plugin')
  assert.ok(!html.includes('dsh-foo'), 'capability filter must hide non-shell plugins')

  // shell AND fs-read: no seeded plugin has both -> empty state.
  controller.toggleCapability('fs-read')
  html = render()
  assert.ok(
    includesAny(html, ['没有符合筛选条件的插件', 'No plugins match the current filters']),
    'expected the no-matches empty state',
  )
  for (const name of PLUGIN_NAMES) {
    assert.ok(!html.includes(name), `empty result must not render "${name}"`)
  }

  // Clearing filters restores the full grid.
  controller.clearFilters()
  html = render()
  for (const name of PLUGIN_NAMES) {
    assert.ok(html.includes(name), `clearFilters() must restore "${name}"`)
  }
})

test('sorting by name orders the rendered cards', async () => {
  const { render, controller } = await mountStore()
  controller.setSort('name')

  const html = render()
  let previousIndex = -1
  for (const name of [
    'dsh-browser-pilot',
    'dsh-foo',
    'dsh-memory-bank',
    'dsh-shell-tools',
    'dsh-theme-night',
  ]) {
    const index = html.indexOf(name)
    assert.ok(index >= 0, `missing ${name}`)
    assert.ok(index > previousIndex, `expected ${name} after the previous card (name sort)`)
    previousIndex = index
  }
})

test('english locale renders the Store title and english chip labels', async () => {
  const { render, t } = await mountStore({ locale: 'en' })
  const html = render()

  assert.equal(t('title'), 'Store')
  assert.ok(html.includes('Store'), 'expected the english tab title')
  assert.ok(html.includes('dsh-foo'), 'expected cards in english locale')
  assert.ok(includesAny(html, ['UI Enhancements']), 'expected english category label')
  assert.ok(includesAny(html, ['Shell']), 'expected english capability label')
})

test('SSR render never touches the network', async () => {
  const originalFetch = globalThis.fetch
  let fetchCalls = 0
  globalThis.fetch = () => {
    fetchCalls += 1
    throw new Error('network access is forbidden in plugin-store tests')
  }
  try {
    const { render } = await mountStore()
    render()
  } finally {
    if (originalFetch) globalThis.fetch = originalFetch
    else delete globalThis.fetch
  }
  assert.equal(fetchCalls, 0, 'SSR rendering must not fetch the catalog')
})
