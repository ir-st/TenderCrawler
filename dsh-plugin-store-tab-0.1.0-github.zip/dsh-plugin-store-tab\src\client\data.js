/**
 * Catalog data layer for the DSH Plugin Store (Web client).
 *
 * Plain dependency-free ESM: `scripts/build-client.mjs` bundles this module (plus the generated
 * `snapshot.data.js`) into `lib/client.js`. There is deliberately no import of React or of any DOM
 * API here so the layer can be unit tested with `node:test` and used during SSR.
 *
 * Responsibilities:
 *  - catalog mirrors + validation + timeout + short-lived success cache (`fetchCatalog`)
 *  - raw entry -> normalized plugin (`normalizePlugin` / `normalizeCatalog`)
 *  - facets, filtering and sorting (`computeFacets`, `filterPlugins`, `sortPlugins`)
 *  - an observable store controller with immutable snapshots (`createStoreController`)
 */

import { SNAPSHOT as SNAPSHOT_DATA } from './snapshot.data.js'

/** Generated offline fallback catalog: `{ sourceUrl, generatedAt, plugins: RawCatalogEntry[] }`. */
export const SNAPSHOT = SNAPSHOT_DATA

/** Number of results added by one "show more" click. */
export const PAGE_SIZE = 60

/** Catalog mirrors, tried in order. Keep in sync with scripts/build-snapshot.mjs. */
export const DEFAULT_SOURCE_URLS = Object.freeze([
  'https://cdn.jsdelivr.net/npm/dsh-plugin-catalog@latest/plugins.json',
  'https://unpkg.com/dsh-plugin-catalog@latest/plugins.json',
  'https://awesome-dsh-plugin.com/plugins.json',
])

/** Category ids used by the catalog, with the localized chip labels. Order = display fallback. */
export const CATEGORY_TITLES = freezeLabels({
  agi: { zh: '通用 AGI', en: 'AGI' },
  ui: { zh: 'UI 增强', en: 'UI Enhancements' },
  usage: { zh: '使用统计', en: 'Usage' },
  theme: { zh: '主题外观', en: 'Themes' },
  model: { zh: '模型接入', en: 'Models' },
  identity: { zh: '身份认证', en: 'Identity' },
  session: { zh: '会话管理', en: 'Sessions' },
  memory: { zh: '记忆', en: 'Memory' },
  tools: { zh: '工具集', en: 'Tools' },
  wsl: { zh: 'WSL', en: 'WSL' },
  browser: { zh: '浏览器', en: 'Browser' },
  vision: { zh: '视觉', en: 'Vision' },
  voice: { zh: '语音', en: 'Voice' },
  docs: { zh: '文档', en: 'Docs' },
  skill: { zh: '技能', en: 'Skills' },
  workflow: { zh: '工作流', en: 'Workflows' },
  git: { zh: 'Git', en: 'Git' },
  notify: { zh: '通知', en: 'Notifications' },
  dev: { zh: '开发', en: 'Developer' },
  security: { zh: '安全', en: 'Security' },
  remote: { zh: '远程', en: 'Remote' },
  market: { zh: '市场', en: 'Marketplace' },
  fun: { zh: '娱乐', en: 'Fun' },
})

/** Capability ids used by the catalog, with the localized chip labels (fixed display order). */
export const CAPABILITY_TITLES = freezeLabels({
  shell: { zh: '终端命令', en: 'Shell' },
  'fs-write': { zh: '文件写入', en: 'File writes' },
  'fs-read': { zh: '文件读取', en: 'File reads' },
  network: { zh: '网络访问', en: 'Network' },
  env: { zh: '环境变量', en: 'Environment' },
  subagent: { zh: '子代理', en: 'Subagents' },
  llm: { zh: '模型调用', en: 'LLM calls' },
  'dynamic-code': { zh: '动态代码', en: 'Dynamic code' },
  credentials: { zh: '凭据读取', en: 'Credentials' },
  'host-runtime': { zh: '宿主运行时', en: 'Host runtime' },
})

const CATEGORY_IDS = Object.freeze(Object.keys(CATEGORY_TITLES))
const CAPABILITY_IDS = Object.freeze(Object.keys(CAPABILITY_TITLES))

/** A 5 minute cache of a successful catalog download (module level, per page load). */
const CATALOG_CACHE_TTL_MS = 5 * 60 * 1000
/** Default per-request timeout for catalog mirror requests. */
const DEFAULT_FETCH_TIMEOUT_MS = 20000
/** Catalog payloads with this many plugins or fewer are treated as broken/partial. */
const MIN_CATALOG_PLUGINS = 100

let catalogCache = null // { key: string, at: number, value: CatalogResult }

/* -------------------------------------------------------------------------------------------------
 * Small coercion helpers. The catalog is community-maintained: every field can be missing or of the
 * wrong type, so normalization never throws and always yields the documented string/number shapes.
 * ----------------------------------------------------------------------------------------------- */

function isPlainObject(value) {
  return typeof value === 'object' && value !== null && !Array.isArray(value)
}

function toText(value) {
  if (typeof value === 'string') return value.trim()
  if (typeof value === 'number' && Number.isFinite(value)) return String(value)
  return ''
}

function toOptionalText(value) {
  if (typeof value === 'string') {
    const text = value.trim()
    return text === '' ? null : text
  }
  if (typeof value === 'number' && Number.isFinite(value)) return String(value)
  return null
}

function toStars(value) {
  let numeric = null
  if (typeof value === 'number') numeric = value
  else if (typeof value === 'string' && value.trim() !== '') numeric = Number(value.replace(/[,_\s]/g, ''))
  if (numeric === null || !Number.isFinite(numeric) || numeric < 0) return null
  const floored = Math.floor(numeric)
  return floored <= Number.MAX_SAFE_INTEGER ? floored : null
}

function toHttpUrl(value) {
  const text = toText(value)
  if (!text || !/^https?:\/\/\S+$/i.test(text)) return ''
  try {
    const url = new URL(text)
    return url.protocol === 'http:' || url.protocol === 'https:' ? text : ''
  } catch {
    return ''
  }
}

function toIcon(value) {
  const text = toText(value)
  if (!text) return null
  if (/^https?:\/\/\S+$/i.test(text)) return text
  if (/^data:image\/[a-z0-9.+-]+(;[a-z0-9=.+-]+)*,/i.test(text)) return text
  return null
}

/** Accepts `YYYY-MM-DD` (optionally with a time part); returns '' for anything that is not a real date. */
function toDate(value) {
  const text = toText(value)
  const match = /^(\d{4})-(\d{2})-(\d{2})/.exec(text)
  if (!match) return ''
  const year = Number(match[1])
  const month = Number(match[2])
  const day = Number(match[3])
  const date = new Date(Date.UTC(year, month - 1, day))
  if (date.getUTCFullYear() !== year || date.getUTCMonth() !== month - 1 || date.getUTCDate() !== day) {
    return ''
  }
  return `${match[1]}-${match[2]}-${match[3]}`
}

/** Trims, strips a leading `@`, a GitHub URL prefix and any trailing path so avatars stay valid. */
function normalizeOwner(value) {
  let text = toText(value)
  if (!text) return ''
  if (/^https?:\/\//i.test(text)) {
    try {
      const url = new URL(text)
      const segments = url.pathname.split('/').filter(Boolean)
      const isGithub = /(^|\.)github\.com$/i.test(url.hostname)
      text = isGithub && segments.length > 0 ? segments[0] : segments[0] || url.hostname
    } catch {
      // not a real URL: fall through to the plain string cleanup
    }
  }
  text = text.replace(/^@+/, '').replace(/[?#].*$/, '').replace(/\/+$/, '')
  if (text.includes('/')) text = text.split('/')[0]
  return text.replace(/\.git$/i, '').trim()
}

function normalizeName(value) {
  return toText(value).replace(/\s+/g, ' ')
}

function normalizeCategory(value) {
  const id = toText(value).toLowerCase()
  return CATEGORY_TITLES[id] ? id : ''
}

function normalizeCapabilities(value) {
  let items = []
  if (Array.isArray(value)) items = value
  else if (typeof value === 'string') items = value.split(/[,\s]+/)
  const found = new Set()
  for (const item of items) {
    const id = toText(item).toLowerCase()
    if (CAPABILITY_TITLES[id]) found.add(id)
  }
  // Canonical order, independent of the catalog's ordering.
  return CAPABILITY_IDS.filter((id) => found.has(id))
}

function normalizeDescription(value) {
  if (isPlainObject(value)) {
    return {
      zh: toText(value.zh),
      en: toText(value.en),
    }
  }
  // A bare string has no language: expose it for both locales instead of hiding it.
  if (typeof value === 'string') {
    const text = value.trim()
    return { zh: text, en: text }
  }
  return { zh: '', en: '' }
}

function makeId(name, owner, index) {
  const lowerName = name.toLowerCase()
  if (lowerName.startsWith('@')) return lowerName
  if (owner && lowerName) return `${owner.toLowerCase()}/${lowerName}`
  if (lowerName) return lowerName
  if (owner) return `${owner.toLowerCase()}/*`
  return `entry-${index}`
}

function buildSearchText(plugin) {
  const parts = [
    plugin.id,
    plugin.name,
    plugin.title,
    plugin.owner,
    plugin.description.zh,
    plugin.description.en,
    plugin.category,
    plugin.npm || '',
    plugin.version || '',
    plugin.install,
    plugin.added,
  ]
  const categoryTitle = plugin.category ? CATEGORY_TITLES[plugin.category] : null
  if (categoryTitle) parts.push(categoryTitle.zh, categoryTitle.en)
  for (const id of plugin.capabilities) {
    parts.push(id)
    const title = CAPABILITY_TITLES[id]
    if (title) parts.push(title.zh, title.en)
  }
  return parts.filter(Boolean).join('\n').toLowerCase()
}

function searchTextOf(plugin) {
  if (isPlainObject(plugin) && typeof plugin.searchText === 'string') return plugin.searchText
  if (!isPlainObject(plugin)) return ''
  const description = normalizeDescription(plugin.description)
  return [plugin.name, plugin.owner, description.zh, description.en, plugin.category]
    .filter((value) => typeof value === 'string' && value !== '')
    .join('\n')
    .toLowerCase()
}

/* -------------------------------------------------------------------------------------------------
 * Normalization
 * ----------------------------------------------------------------------------------------------- */

/**
 * Human-facing card title. Published packages use their npm name (the installable identity); repo
 * sub-package entries such as `owner/repo#packages/foo` display the sub-package name instead of the
 * raw catalog path. `plugin.name` keeps the full catalog value for the detail view.
 *
 * @param {string} name normalized catalog name
 * @param {string|null} npm npm package name when published
 * @returns {string}
 */
function displayTitle(name, npm) {
  if (npm) return npm
  const hash = name.lastIndexOf('#')
  if (hash >= 0 && hash < name.length - 1) return name.slice(hash + 1)
  return name
}

/**
 * Turn one raw catalog entry into a `NormalizedPlugin`. Never throws; malformed fields fall back to
 * the documented empty values.
 *
 * @param {unknown} entry raw catalog entry (may be null / a string / anything).
 * @param {number} [index] position in the catalog, used only for the id of otherwise anonymous entries.
 * @returns {NormalizedPlugin}
 */
export function normalizePlugin(entry, index = 0) {
  const raw = isPlainObject(entry) ? entry : {}
  const name = normalizeName(raw.name)
  const owner = normalizeOwner(raw.owner)
  const description = normalizeDescription(raw.description)
  const category = normalizeCategory(raw.category)
  const capabilities = normalizeCapabilities(raw.capabilities)
  const install = toText(raw.install)
  const page = toHttpUrl(raw.page)
  // `repo` is the raw `url`; also accept an already-normalized plugin / a `repository` alias.
  const repo = toHttpUrl(raw.url) || toHttpUrl(raw.repo) || toHttpUrl(raw.repository)
  const npm = toOptionalText(raw.npm)

  const plugin = {
    id: makeId(name, owner, index),
    name,
    owner,
    title: displayTitle(name, npm),
    description,
    icon: toIcon(raw.icon),
    avatar: owner ? `https://github.com/${encodeURIComponent(owner)}.png?size=96` : '',
    category,
    capabilities,
    stars: toStars(raw.stars),
    npm,
    version: toOptionalText(raw.version),
    install,
    page,
    repo,
    added: toDate(raw.added),
  }
  plugin.searchText = buildSearchText(plugin)
  return plugin
}

/**
 * Normalize a raw catalog payload (`{ plugins: [...] }`) or a bare array of entries.
 * Entries without a name are dropped; duplicate ids keep the first occurrence.
 *
 * @param {unknown} raw
 * @returns {NormalizedPlugin[]}
 */
export function normalizeCatalog(raw) {
  const list = Array.isArray(raw) ? raw : isPlainObject(raw) && Array.isArray(raw.plugins) ? raw.plugins : []
  const normalized = []
  const seen = new Set()
  for (let index = 0; index < list.length; index += 1) {
    const plugin = normalizePlugin(list[index], index)
    if (plugin.name === '') continue
    if (seen.has(plugin.id)) continue
    seen.add(plugin.id)
    normalized.push(plugin)
  }
  return normalized
}

/* -------------------------------------------------------------------------------------------------
 * Facets, filtering, sorting
 * ----------------------------------------------------------------------------------------------- */

function compareFacet(a, b) {
  if (a.count !== b.count) return b.count - a.count
  const byLabel = a.label.zh.localeCompare(b.label.zh, 'zh')
  if (byLabel !== 0) return byLabel
  return a.id.localeCompare(b.id, 'en')
}

/**
 * Compute the filter chip facets over the catalog.
 * Categories are ordered by count desc (then localized label); capabilities keep the fixed
 * CAPABILITY_TITLES order and only include ids that at least one plugin declares.
 *
 * @param {NormalizedPlugin[]} plugins all plugins (not the filtered result set).
 * @returns {{ categories: Facet[], capabilities: Facet[] }}
 */
export function computeFacets(plugins) {
  const list = Array.isArray(plugins) ? plugins : []
  const categoryCounts = new Map()
  const capabilityCounts = new Map()
  for (const plugin of list) {
    if (!isPlainObject(plugin)) continue
    const category = plugin.category
    if (typeof category === 'string' && CATEGORY_TITLES[category]) {
      categoryCounts.set(category, (categoryCounts.get(category) || 0) + 1)
    }
    if (Array.isArray(plugin.capabilities)) {
      for (const id of plugin.capabilities) {
        if (!CAPABILITY_TITLES[id]) continue
        capabilityCounts.set(id, (capabilityCounts.get(id) || 0) + 1)
      }
    }
  }
  const categories = Array.from(categoryCounts, ([id, count]) => ({
    id,
    label: CATEGORY_TITLES[id],
    count,
  })).sort(compareFacet)
  const capabilities = CAPABILITY_IDS
    .map((id) => ({ id, label: CAPABILITY_TITLES[id], count: capabilityCounts.get(id) || 0 }))
    .filter((facet) => facet.count > 0)
  return { categories, capabilities }
}

/**
 * Apply the filter set. Every constraint is ANDed:
 *  - `text`: case-insensitive substring of the precomputed haystack (all whitespace-separated terms
 *    must match);
 *  - `category`: exact category id (null / '' = no constraint);
 *  - `capabilities`: the plugin must declare every selected capability.
 *
 * @param {NormalizedPlugin[]} plugins
 * @param {{ text?: string, category?: string | null, capabilities?: string[] }} [query]
 * @returns {NormalizedPlugin[]} a new array (never mutates the input)
 */
export function filterPlugins(plugins, query) {
  const list = Array.isArray(plugins) ? plugins : []
  const filter = isPlainObject(query) ? query : {}
  const text = toText(filter.text).toLowerCase()
  const terms = text === '' ? [] : text.split(/\s+/).filter(Boolean)
  const category = typeof filter.category === 'string' && filter.category !== '' ? filter.category : null
  const capabilities = Array.isArray(filter.capabilities)
    ? filter.capabilities.filter((id) => typeof id === 'string' && CAPABILITY_TITLES[id])
    : []
  if (terms.length === 0 && category === null && capabilities.length === 0) return list.slice()
  return list.filter((plugin) => {
    if (!isPlainObject(plugin)) return false
    if (category !== null && plugin.category !== category) return false
    if (capabilities.length > 0) {
      const declared = Array.isArray(plugin.capabilities) ? plugin.capabilities : []
      for (const id of capabilities) {
        if (!declared.includes(id)) return false
      }
    }
    if (terms.length > 0) {
      const haystack = searchTextOf(plugin)
      for (const term of terms) {
        if (!haystack.includes(term)) return false
      }
    }
    return true
  })
}

function compareNames(a, b) {
  return toText(a && a.name).localeCompare(toText(b && b.name), 'en')
}

function compareIds(a, b) {
  return toText(a && a.id).localeCompare(toText(b && b.id), 'en')
}

function compareAddedDesc(a, b) {
  const left = toText(a && a.added)
  const right = toText(b && b.added)
  if (left === right) return 0
  if (left === '') return 1
  if (right === '') return -1
  return right.localeCompare(left, 'en')
}

function compareStarsDesc(a, b) {
  const left = a && typeof a.stars === 'number' && Number.isFinite(a.stars) ? a.stars : null
  const right = b && typeof b.stars === 'number' && Number.isFinite(b.stars) ? b.stars : null
  if (left === null && right === null) return 0
  if (left === null) return 1
  if (right === null) return -1
  return right - left
}

/**
 * Sort a copy of the plugin list. `stars` is the default; nulls (or missing stars) always sort last.
 *
 * @param {NormalizedPlugin[]} plugins
 * @param {'stars' | 'added' | 'name' | string} [sort]
 * @returns {NormalizedPlugin[]} a new sorted array (never mutates the input)
 */
export function sortPlugins(plugins, sort) {
  const list = Array.isArray(plugins) ? plugins.slice() : []
  const mode = sort === 'added' || sort === 'name' ? sort : 'stars'
  if (mode === 'added') {
    list.sort((a, b) => compareAddedDesc(a, b) || compareStarsDesc(a, b) || compareNames(a, b) || compareIds(a, b))
  } else if (mode === 'name') {
    list.sort((a, b) => compareNames(a, b) || compareStarsDesc(a, b) || compareIds(a, b))
  } else {
    list.sort((a, b) => compareStarsDesc(a, b) || compareAddedDesc(a, b) || compareNames(a, b) || compareIds(a, b))
  }
  return list
}

/* -------------------------------------------------------------------------------------------------
 * Catalog fetching
 * ----------------------------------------------------------------------------------------------- */

function abortError() {
  const error = new Error('The catalog request was aborted.')
  error.name = 'AbortError'
  return error
}

function isAborted(signal) {
  return Boolean(signal && signal.aborted)
}

/**
 * Fetch one JSON document, aborting the request after `timeoutMs` (AbortController) or when the
 * caller-provided signal aborts.
 */
async function requestJson(url, fetchImpl, timeoutMs, externalSignal) {
  const controller = new AbortController()
  let timedOut = false
  const abort = () => {
    try {
      controller.abort()
    } catch {
      // AbortController.abort() never throws in practice; stay defensive.
    }
  }
  const forwardAbort = () => abort()
  if (externalSignal) {
    if (externalSignal.aborted) abort()
    else externalSignal.addEventListener('abort', forwardAbort)
  }
  const timer = setTimeout(() => {
    timedOut = true
    abort()
  }, timeoutMs)
  try {
    const response = await fetchImpl(url, {
      signal: controller.signal,
      headers: { accept: 'application/json' },
      cache: 'no-store',
      credentials: 'omit',
    })
    if (!response || typeof response !== 'object') throw new Error(`no response for ${url}`)
    if (typeof response.ok === 'boolean' && !response.ok) {
      throw new Error(`HTTP ${response.status} for ${url}`)
    }
    if (typeof response.status === 'number' && (response.status < 200 || response.status >= 300)) {
      throw new Error(`HTTP ${response.status} for ${url}`)
    }
    if (typeof response.json === 'function') return await response.json()
    if (typeof response.text === 'function') return JSON.parse(await response.text())
    throw new Error(`response has no JSON body for ${url}`)
  } catch (error) {
    if (timedOut) {
      const timeoutError = new Error(`Timed out after ${timeoutMs}ms fetching ${url}`)
      timeoutError.name = 'TimeoutError'
      timeoutError.cause = error
      throw timeoutError
    }
    throw error
  } finally {
    clearTimeout(timer)
    if (externalSignal) externalSignal.removeEventListener('abort', forwardAbort)
  }
}

/**
 * Download the official catalog, trying every mirror in order.
 *
 * Every request is aborted after `timeoutMs`; a mirror only counts when it answers HTTP 2xx with a
 * JSON object whose `plugins` array has more than 100 entries. The first valid answer wins and is
 * normalized. Successful results are cached in-module for 5 minutes (keyed by the URL list).
 *
 * @param {{
 *   fetchImpl?: typeof fetch,
 *   urls?: string[],
 *   timeoutMs?: number,
 *   signal?: AbortSignal,
 * }} [options]
 * @returns {Promise<{ plugins: NormalizedPlugin[], sourceUrl: string, fetchedAt: number }>}
 */
export async function fetchCatalog(options) {
  const opts = isPlainObject(options) ? options : {}
  const fetchImpl = typeof opts.fetchImpl === 'function'
    ? opts.fetchImpl
    : typeof globalThis !== 'undefined' && typeof globalThis.fetch === 'function'
      ? globalThis.fetch
      : null
  const urls = Array.isArray(opts.urls) && opts.urls.length > 0
    ? opts.urls.filter((url) => typeof url === 'string' && url !== '')
    : DEFAULT_SOURCE_URLS.slice()
  const timeoutMs = typeof opts.timeoutMs === 'number' && Number.isFinite(opts.timeoutMs) && opts.timeoutMs > 0
    ? opts.timeoutMs
    : DEFAULT_FETCH_TIMEOUT_MS
  const externalSignal = opts.signal || null

  if (isAborted(externalSignal)) throw abortError()
  if (urls.length === 0) throw new Error('No plugin catalog URL was provided.')
  if (typeof fetchImpl !== 'function') {
    throw new Error('No fetch implementation is available to load the plugin catalog.')
  }

  const cacheKey = urls.join('|')
  const now = Date.now()
  if (catalogCache && catalogCache.key === cacheKey && now - catalogCache.at < CATALOG_CACHE_TTL_MS) {
    return catalogCache.value
  }

  let lastError = null
  for (const url of urls) {
    if (isAborted(externalSignal)) throw abortError()
    try {
      const json = await requestJson(url, fetchImpl, timeoutMs, externalSignal)
      if (!isPlainObject(json) || !Array.isArray(json.plugins) || json.plugins.length <= MIN_CATALOG_PLUGINS) {
        const count = isPlainObject(json) && Array.isArray(json.plugins) ? json.plugins.length : 'no'
        throw new Error(`invalid catalog payload from ${url} (${count} plugins)`)
      }
      const value = {
        plugins: normalizeCatalog(json),
        sourceUrl: url,
        fetchedAt: Date.now(),
      }
      catalogCache = { key: cacheKey, at: Date.now(), value }
      return value
    } catch (error) {
      if (isAborted(externalSignal)) throw abortError()
      lastError = error
    }
  }

  const failure = new Error(
    'Could not load the plugin catalog from any mirror. Check your network connection and try again.',
  )
  failure.name = 'CatalogFetchError'
  if (lastError) failure.cause = lastError
  throw failure
}

/* -------------------------------------------------------------------------------------------------
 * Store controller
 * ----------------------------------------------------------------------------------------------- */

function freezeLabels(table) {
  const frozen = {}
  for (const [id, label] of Object.entries(table)) frozen[id] = Object.freeze({ zh: label.zh, en: label.en })
  return Object.freeze(frozen)
}

function freezeState(state) {
  Object.freeze(state.source)
  Object.freeze(state.query)
  Object.freeze(state.query.capabilities)
  Object.freeze(state.facets)
  Object.freeze(state.facets.categories)
  Object.freeze(state.facets.capabilities)
  Object.freeze(state.plugins)
  Object.freeze(state.results)
  return Object.freeze(state)
}

function createInitialState() {
  return {
    status: 'idle',
    refreshing: false,
    error: null,
    source: { url: null, title: '', fetchedAt: null, offline: false },
    plugins: [],
    results: [],
    facets: { categories: [], capabilities: [] },
    query: { text: '', category: null, capabilities: [] },
    sort: 'stars',
    pageSize: PAGE_SIZE,
    visible: 0,
    total: 0,
    hasMore: false,
  }
}

function errorMessage(error) {
  if (error && typeof error.message === 'string' && error.message !== '') return error.message
  if (typeof error === 'string' && error !== '') return error
  return 'The plugin catalog could not be loaded.'
}

function hostOf(url) {
  try {
    return new URL(url).hostname
  } catch {
    return ''
  }
}

function sourceTitle(url, offline) {
  if (offline) return 'Built-in snapshot'
  return hostOf(url) || 'Plugin catalog'
}

function parseTimestamp(value) {
  if (typeof value !== 'string' || value === '') return null
  const parsed = Date.parse(value)
  return Number.isFinite(parsed) ? parsed : null
}

/** Normalize the injected snapshot (or the generated SNAPSHOT) once, at controller creation. */
function normalizeSnapshot(value) {
  const list = Array.isArray(value) ? value : isPlainObject(value) && Array.isArray(value.plugins) ? value.plugins : []
  return {
    sourceUrl: isPlainObject(value) && typeof value.sourceUrl === 'string' ? value.sourceUrl : '',
    generatedAt: isPlainObject(value) && typeof value.generatedAt === 'string' ? value.generatedAt : '',
    plugins: normalizeCatalog(list),
  }
}

/**
 * Create the Store tab controller.
 *
 * `getSnapshot()` returns a frozen object whose identity changes only when state changes.
 * State updates are synchronous; `results` is always `sortPlugins(filterPlugins(plugins, query), sort)`.
 *
 * `load()` is idempotent: concurrent calls share one promise, and once loaded, plain `load()` calls
 * are no-ops. It never rejects: if `deps.load`/`fetchCatalog` fails and no list is displayed, it falls
 * back to the bundled snapshot (source.offline = true); if even that is unavailable it exposes the
 * error through the snapshot (`status: 'error'`).
 *
 * @param {{
 *   load?: () => Promise<{ plugins: unknown[], sourceUrl?: string, fetchedAt?: number, offline?: boolean }>,
 *   snapshot?: { sourceUrl?: string, generatedAt?: string, plugins?: unknown[] } | unknown[] | null,
 * }} [deps]
 * @returns {Controller}
 */
export function createStoreController(deps) {
  const options = isPlainObject(deps) ? deps : {}
  const loader = typeof options.load === 'function' ? options.load : null
  const offlineCatalog = normalizeSnapshot(options.snapshot !== undefined ? options.snapshot : SNAPSHOT)
  const offlineFetchedAt = parseTimestamp(offlineCatalog.generatedAt)

  let disposed = false
  let inFlight = null
  const subscribers = new Set()
  let state = freezeState(createInitialState())

  function getSnapshot() {
    return state
  }

  function commit(next) {
    if (disposed) return
    state = freezeState(next)
    if (subscribers.size === 0) return
    for (const listener of Array.from(subscribers)) {
      if (disposed) return
      try {
        listener(state)
      } catch {
        // A broken subscriber must never take down the store or other subscribers.
      }
    }
  }

  function subscribe(listener) {
    if (typeof listener !== 'function' || disposed) return () => {}
    subscribers.add(listener)
    return () => {
      subscribers.delete(listener)
    }
  }

  /** Replace the catalog and reset pagination. Filters/sort are kept (they define the result view). */
  function applyReady(plugins, source) {
    const results = sortPlugins(filterPlugins(plugins, state.query), state.sort)
    const total = results.length
    const visible = Math.min(state.pageSize, total)
    commit({
      ...state,
      status: 'ready',
      refreshing: false,
      error: null,
      source,
      plugins,
      results,
      facets: computeFacets(plugins),
      visible,
      total,
      hasMore: visible < total,
    })
  }

  /** Recompute results/pagination after a query change, resetting to the first page. */
  function applyQuery(query) {
    const results = sortPlugins(filterPlugins(state.plugins, query), state.sort)
    const total = results.length
    const visible = Math.min(state.pageSize, total)
    commit({ ...state, query, results, visible, total, hasMore: visible < total })
  }

  async function runLoad() {
    try {
      const payload = loader ? await loader() : await fetchCatalog()
      if (disposed) return
      if (!isPlainObject(payload) || !Array.isArray(payload.plugins)) {
        throw new Error('The plugin catalog loader returned an invalid payload.')
      }
      const plugins = normalizeCatalog(payload.plugins)
      const sourceUrl = typeof payload.sourceUrl === 'string' && payload.sourceUrl !== '' ? payload.sourceUrl : null
      const fetchedAt = typeof payload.fetchedAt === 'number' && Number.isFinite(payload.fetchedAt)
        ? payload.fetchedAt
        : Date.now()
      const offline = payload.offline === true
      applyReady(plugins, Object.freeze({
        url: sourceUrl,
        title: sourceTitle(sourceUrl, offline),
        fetchedAt,
        offline,
      }))
    } catch (error) {
      if (disposed) return
      const message = errorMessage(error)
      if (state.plugins.length > 0) {
        // Keep displaying the previously loaded catalog; expose the failure without blanking the tab.
        commit({ ...state, status: 'ready', refreshing: false, error: message })
      } else if (offlineCatalog.plugins.length > 0) {
        // Offline fallback: built-in snapshot generated by scripts/build-snapshot.mjs.
        applyReady(offlineCatalog.plugins, Object.freeze({
          url: offlineCatalog.sourceUrl || null,
          title: 'Built-in snapshot',
          fetchedAt: offlineFetchedAt,
          offline: true,
        }))
      } else {
        commit({ ...state, status: 'error', refreshing: false, error: message })
      }
    }
  }

  /**
   * Load the catalog once. `{ force: true }` forces a refresh that keeps the current list visible.
   * @param {{ force?: boolean }} [loadOptions]
   * @returns {Promise<object>} resolves to the current snapshot; never rejects
   */
  function load(loadOptions) {
    const force = Boolean(loadOptions && loadOptions.force)
    if (disposed) return Promise.resolve(state)
    if (inFlight) return inFlight
    if (!force && (state.status === 'ready' || state.status === 'error' || state.status === 'loading')) {
      return Promise.resolve(state)
    }
    const hasPlugins = state.plugins.length > 0
    commit({
      ...state,
      status: hasPlugins ? state.status : 'loading',
      refreshing: true,
      // A refresh keeps the old error visible until it succeeds or fails again.
      error: hasPlugins ? state.error : null,
    })
    const task = (async () => {
      try {
        await runLoad()
      } finally {
        inFlight = null
      }
      return state
    })()
    inFlight = task
    return task
  }

  function refresh() {
    return load({ force: true })
  }

  function retry() {
    return load({ force: true })
  }

  function setText(text) {
    if (disposed) return
    const nextText = typeof text === 'string' ? text : text == null ? '' : String(text)
    if (nextText === state.query.text) return
    applyQuery({ ...state.query, text: nextText })
  }

  function setCategory(id) {
    if (disposed) return
    const nextCategory = typeof id === 'string' && CATEGORY_TITLES[id] ? id : null
    if (nextCategory === state.query.category) return
    applyQuery({ ...state.query, category: nextCategory })
  }

  function toggleCapability(id) {
    if (disposed) return
    if (typeof id !== 'string' || !CAPABILITY_TITLES[id]) return
    const selected = new Set(state.query.capabilities)
    if (selected.has(id)) selected.delete(id)
    else selected.add(id)
    const capabilities = CAPABILITY_IDS.filter((capabilityId) => selected.has(capabilityId))
    const unchanged = capabilities.length === state.query.capabilities.length
      && capabilities.every((capabilityId) => state.query.capabilities.includes(capabilityId))
    if (unchanged) return
    applyQuery({ ...state.query, capabilities })
  }

  function clearFilters() {
    if (disposed) return
    const { text, category, capabilities } = state.query
    if (text === '' && category === null && capabilities.length === 0) return
    applyQuery({ text: '', category: null, capabilities: [] })
  }

  function setSort(sort) {
    if (disposed) return
    const nextSort = sort === 'added' || sort === 'name' ? sort : sort === 'stars' ? 'stars' : null
    if (nextSort === null || nextSort === state.sort) return
    commit({ ...state, sort: nextSort, results: sortPlugins(state.results, nextSort) })
  }

  function showMore() {
    if (disposed) return
    const nextVisible = Math.min(state.total, state.visible + state.pageSize)
    if (nextVisible === state.visible) return
    commit({ ...state, visible: nextVisible, hasMore: nextVisible < state.total })
  }

  function dispose() {
    if (disposed) return
    disposed = true
    subscribers.clear()
    inFlight = null
  }

  return Object.freeze({
    getSnapshot,
    subscribe,
    load,
    refresh,
    retry,
    setText,
    setCategory,
    toggleCapability,
    clearFilters,
    setSort,
    showMore,
    dispose,
  })
}

/**
 * @typedef {object} NormalizedPlugin
 * @property {string} id
 * @property {string} name
 * @property {string} owner
 * @property {string} title
 * @property {{ zh: string, en: string }} description
 * @property {string | null} icon
 * @property {string} avatar
 * @property {string} category
 * @property {string[]} capabilities
 * @property {number | null} stars
 * @property {string | null} npm
 * @property {string | null} version
 * @property {string} install
 * @property {string} page
 * @property {string} repo
 * @property {string} added
 * @property {string} searchText
 */

/**
 * @typedef {object} Facet
 * @property {string} id
 * @property {{ zh: string, en: string }} label
 * @property {number} count
 */

/**
 * @typedef {object} Controller
 * @property {() => object} getSnapshot
 * @property {(listener: (snapshot: object) => void) => () => void} subscribe
 * @property {(options?: { force?: boolean }) => Promise<object>} load
 * @property {() => Promise<object>} refresh
 * @property {() => Promise<object>} retry
 * @property {(text: string) => void} setText
 * @property {(category: string | null) => void} setCategory
 * @property {(capabilityId: string) => void} toggleCapability
 * @property {() => void} clearFilters
 * @property {(sort: 'stars' | 'added' | 'name') => void} setSort
 * @property {() => void} showMore
 * @property {() => void} dispose
 */
