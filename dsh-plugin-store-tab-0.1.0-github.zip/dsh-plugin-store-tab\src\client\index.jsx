import { createStoreController } from './data.js'
import { StoreTab } from './ui.jsx'
import { STORE_CSS } from './styles.js'

/** Locale namespace owned by this plugin. */
const NS = 'pluginStore'

/** Simplified Chinese dictionary — key source of truth. */
const zh = {
  title: '商店',
  subtitle: '浏览 DSH 插件目录（社区维护），按分类与能力筛选',
  refresh: '刷新',
  refreshAria: '刷新插件目录',
  tooltipRefresh: '重新抓取插件目录',
  searchPlaceholder: '搜索插件名称、作者或描述',
  sortLabel: '排序',
  sortStars: '最热',
  sortAdded: '最新',
  sortName: '名称',
  categoriesLabel: '分类',
  allCategories: '全部',
  capabilitiesLabel: '能力',
  count: '{count} 个插件',
  countFiltered: '{count} / {total} 个插件',
  loading: '正在抓取插件目录',
  loadingHint: '首次加载需要下载目录数据，请稍候',
  retry: '重试',
  errorTitle: '无法读取插件目录',
  errorDescription: '插件目录暂时不可访问。检查网络后重试，或稍后再试。',
  emptyTitle: '目录里还没有插件',
  emptyDescription: '插件目录返回了空列表。',
  noMatches: '没有符合筛选条件的插件',
  noMatchesHint: '换一个关键词，或清除分类与能力筛选。',
  clearFilters: '清除筛选',
  showMore: '显示更多',
  showingMore: '已显示 {shown} / {total}',
  sourceLabel: '数据源',
  sourceOffline: '内置快照（离线）',
  sourceLive: '社区目录',
  attribution: '数据来自 awesome-dsh-plugin.com 的 DeepSeek Harness 插件目录 · 第三方内容，安装前请自行核实',
  openDetail: '查看 {name} 详情',
  back: '返回商店',
  detailDescription: '简介',
  detailTags: '标签',
  detailSource: '来源信息',
  detailStars: '星标',
  detailVersion: '版本',
  detailInstall: '安装命令',
  detailLinks: '链接',
  detailOwner: '作者',
  detailCategory: '分类',
  detailCapabilities: '能力',
  detailAdded: '收录时间',
  detailCatalogName: '目录名称',
  copy: '复制',
  copied: '已复制',
  copyFailed: '复制失败',
  visitPage: '打开目录页',
  visitRepo: '源代码',
  starsCount: '{stars} 星标',
  npmBadge: 'npm',
  installHint: '在「设置 → 插件」或终端中执行；本商店不直接安装插件。',
}

/** English dictionary. */
const en = {
  title: 'Store',
  subtitle: 'Browse the community-maintained DSH plugin catalog by category and capability',
  refresh: 'Refresh',
  refreshAria: 'Refresh the plugin catalog',
  tooltipRefresh: 'Fetch the plugin catalog again',
  searchPlaceholder: 'Search name, author, or description',
  sortLabel: 'Sort',
  sortStars: 'Most starred',
  sortAdded: 'Newest',
  sortName: 'Name',
  categoriesLabel: 'Category',
  allCategories: 'All',
  capabilitiesLabel: 'Capabilities',
  count: '{count} plugins',
  countFiltered: '{count} / {total} plugins',
  loading: 'Fetching the plugin catalog',
  loadingHint: 'The first load downloads the catalog, this may take a moment',
  retry: 'Retry',
  errorTitle: 'Could not read the plugin catalog',
  errorDescription: 'The catalog is unreachable right now. Check your network and try again.',
  emptyTitle: 'The catalog is empty',
  emptyDescription: 'The catalog returned no plugins.',
  noMatches: 'No plugins match the current filters',
  noMatchesHint: 'Try another keyword, or clear the category and capability filters.',
  clearFilters: 'Clear filters',
  showMore: 'Show more',
  showingMore: 'Showing {shown} / {total}',
  sourceLabel: 'Source',
  sourceOffline: 'Built-in snapshot (offline)',
  sourceLive: 'Community catalog',
  attribution: 'Data from the DeepSeek Harness plugin catalog at awesome-dsh-plugin.com · third-party content, verify before installing',
  openDetail: 'Open details for {name}',
  back: 'Back to store',
  detailDescription: 'About',
  detailTags: 'Tags',
  detailSource: 'Source',
  detailStars: 'Stars',
  detailVersion: 'Version',
  detailInstall: 'Install command',
  detailLinks: 'Links',
  detailOwner: 'Author',
  detailCategory: 'Category',
  detailCapabilities: 'Capabilities',
  detailAdded: 'Added',
  detailCatalogName: 'Catalog name',
  copy: 'Copy',
  copied: 'Copied',
  copyFailed: 'Copy failed',
  visitPage: 'Catalog page',
  visitRepo: 'Source code',
  starsCount: '{stars} stars',
  npmBadge: 'npm',
  installHint: 'Run it from Settings → Plugins or a terminal; this store never installs plugins itself.',
}

/** Style element identity: one tag per plugin, removed with the plugin effect. */
const STYLE_ID = 'dsh-plugin-store-tab/styles.css'

function applyStyles() {
  if (typeof document === 'undefined') return () => {}
  const existing = document.querySelector(`style[data-plugin-css=${JSON.stringify(STYLE_ID)}]`)
  if (existing) return () => {}
  const tag = document.createElement('style')
  tag.dataset.plugin = 'dsh-plugin-store-tab'
  tag.dataset.pluginCss = STYLE_ID
  tag.textContent = STORE_CSS
  document.head.appendChild(tag)
  return () => {
    tag.remove()
  }
}

/** Services this client plugin reads. */
export const inject = ['slots', 'locale']

/**
 * Contribute the Store tab to the Plugins page.
 * @param ctx - the browser plugin context.
 */
export function apply(ctx) {
  ctx.effect(() => ctx.locale.register(NS, { zh, en }), 'dsh-plugin-store: dictionaries')
  ctx.effect(() => applyStyles(), 'dsh-plugin-store: styles')

  const t = ctx.locale.bind(NS)
  ctx.slots.inject('plugins.tab', () => {
    const controller = createStoreController()
    ctx.effect(() => () => controller.dispose(), 'dsh-plugin-store: controller')
    return ctx.slots.register(
      {
        name: 'plugins.tab',
        id: 'store',
        order: 20,
        label: () => t('title'),
        locale: NS,
        // resolveText localizes catalog LocalizedText ({ zh, en }) with the active UI language.
        inject: () => ({ controller, resolveText: (text) => ctx.locale.resolveText(text) }),
      },
      StoreTab,
    )
  })
}
