/**
 * Shared test harness for the Plugin Store client bundle.
 *
 * The bundle is a classic-script CJS closure that registers itself via
 * `window.__ModuleLoader__.load({ id, factory })`. Tests therefore:
 *   1. install a fake `globalThis.window.__ModuleLoader__`,
 *   2. dynamically import the built `lib/client.js`,
 *   3. call the captured `factory(require)` with a React-only require,
 *   4. run `apply(ctx)` against a small mock plugin context.
 *
 * No network access: the fake controller used by the SSR tests never loads a catalog.
 */

import fs from 'node:fs'
import path from 'node:path'
import { createRequire } from 'node:module'
import { fileURLToPath, pathToFileURL } from 'node:url'

// Re-use the build script's code masker so tests ignore string literals/comments exactly like
// the build audit does (catalog descriptions legitimately contain text such as `import(`).
export { maskNonCode } from '../scripts/build-client.mjs'

const HARNESS_DIR = path.dirname(fileURLToPath(import.meta.url))

export const PACKAGE_ROOT = path.resolve(HARNESS_DIR, '..')
export const CLIENT_BUNDLE = path.join(PACKAGE_ROOT, 'lib', 'client.js')
export const PLUGIN_NAME = JSON.parse(fs.readFileSync(path.join(PACKAGE_ROOT, 'package.json'), 'utf8')).name

export const paths = {
  packageRoot: PACKAGE_ROOT,
  pluginName: PLUGIN_NAME,
  clientBundle: CLIENT_BUNDLE,
}

const packageRequire = createRequire(path.join(PACKAGE_ROOT, 'package.json'))

/** React instance shared with the bundle under test (same module cache entry). */
export const react = packageRequire('react')
export const reactDomServer = packageRequire('react-dom/server')

/**
 * `require` implementation handed to the bundle factory. Only platform modules are allowed.
 * @param {string} id
 */
export function reactRequire(id) {
  if (id === 'react') return react
  if (id === 'react/jsx-runtime') return packageRequire('react/jsx-runtime')
  throw new Error(
    `unexpected external require from ${PLUGIN_NAME} client bundle: "${id}" (allowed: react, react/jsx-runtime)`,
  )
}

/** Render a React element to static HTML (SSR, effects never run). */
export function renderToStaticMarkup(element) {
  return reactDomServer.renderToStaticMarkup(element)
}

/** True when `html` contains at least one of the candidate strings. */
export function includesAny(html, candidates) {
  return candidates.some((candidate) => html.includes(candidate))
}

// ---------------------------------------------------------------------------------------------
// Module-loader simulation.
// ---------------------------------------------------------------------------------------------

let bundleLoadCount = 0

/**
 * Install `window.__ModuleLoader__`, import the built client bundle, and return the
 * captured loader definition (`{ id, factory }`). `window` is restored afterwards.
 */
export async function loadClientBundle() {
  if (!fs.existsSync(CLIENT_BUNDLE)) {
    throw new Error(
      `built client bundle missing: ${path.relative(PACKAGE_ROOT, CLIENT_BUNDLE)}\n` +
        'run: node scripts/build-client.mjs',
    )
  }

  const captured = { def: null }
  const hadWindow = 'window' in globalThis
  const previousWindow = globalThis.window
  globalThis.window = {
    __ModuleLoader__: {
      load(definition) {
        if (captured.def) {
          throw new Error('client bundle called window.__ModuleLoader__.load() more than once')
        }
        captured.def = definition
      },
    },
  }

  try {
    bundleLoadCount += 1
    const cacheBust = `verify-harness=${process.pid}-${bundleLoadCount}-${Date.now()}`
    await import(`${pathToFileURL(CLIENT_BUNDLE).href}?${cacheBust}`)
  } finally {
    if (hadWindow) globalThis.window = previousWindow
    else delete globalThis.window
  }

  if (!captured.def) {
    throw new Error(
      'client bundle did not call window.__ModuleLoader__.load() on import (missing wrapper?)',
    )
  }
  if (captured.def.id !== PLUGIN_NAME) {
    throw new Error(`expected bundle id "${PLUGIN_NAME}", got "${captured.def.id}"`)
  }
  if (typeof captured.def.factory !== 'function') {
    throw new Error('bundle definition has no factory function')
  }
  return captured.def
}

// ---------------------------------------------------------------------------------------------
// Mock plugin context.
// ---------------------------------------------------------------------------------------------

function interpolate(template, params) {
  return String(template).replace(/\{(\w+)\}/g, (match, key) => {
    if (params && Object.prototype.hasOwnProperty.call(params, key)) return String(params[key])
    return match
  })
}

/**
 * Minimal `ctx` implementing the services used by the client entry:
 * `locale.register/bind/resolveText`, `slots.inject/register`, `effect`, `on`.
 *
 * @param {{ locale?: 'zh' | 'en' }} [options]
 */
export function createMockContext(options = {}) {
  const localeName = options.locale === 'en' ? 'en' : 'zh'
  const dictionaries = new Map()
  const registrations = []
  const injections = []
  const effects = []
  const listeners = []
  const loggerCalls = []

  function dictionaryFor(namespace) {
    const dictionary = dictionaries.get(namespace)
    if (!dictionary) {
      throw new Error(`locale namespace "${namespace}" was registered after it was used`)
    }
    return dictionary
  }

  function translate(namespace, key, params = {}) {
    const dictionary = dictionaryFor(namespace)
    const table = dictionary[localeName] ?? dictionary.zh ?? dictionary.en ?? {}
    const template = table[key] ?? dictionary.en?.[key] ?? dictionary.zh?.[key]
    if (template === undefined) {
      throw new Error(
        `missing locale key "${key}" in namespace "${namespace}" (locale "${localeName}")`,
      )
    }
    return interpolate(template, params)
  }

  function resolveText(text) {
    if (text === null || text === undefined) return ''
    if (typeof text === 'string') return text
    if (typeof text !== 'object') return String(text)
    if (localeName === 'en') return text.en || text.zh || ''
    return text.zh || text.en || ''
  }

  const ctx = {
    locale: {
      register(namespace, dictionary) {
        dictionaries.set(namespace, dictionary)
        return () => dictionaries.delete(namespace)
      },
      bind(namespace) {
        return (key, params) => translate(namespace, key, params)
      },
      resolveText,
    },
    slots: {
      inject(name, callback) {
        injections.push({ name, callback })
        callback()
        return () => {}
      },
      register(definition, component) {
        const entry = { name: definition?.name ?? null, def: definition, component, disposed: false }
        registrations.push(entry)
        return () => {
          entry.disposed = true
        }
      },
    },
    effect(fn) {
      const result = fn()
      const dispose = typeof result === 'function' ? result : undefined
      effects.push(dispose)
      return dispose
    },
    on(name, handler) {
      listeners.push({ name, handler })
      return () => {}
    },
    logger: {
      debug: (...args) => loggerCalls.push(['debug', ...args]),
      info: (...args) => loggerCalls.push(['info', ...args]),
      warn: (...args) => loggerCalls.push(['warn', ...args]),
      error: (...args) => loggerCalls.push(['error', ...args]),
    },
    // Test introspection helpers.
    localeName,
    dictionaries,
    registrations,
    injections,
    effects,
    listeners,
    loggerCalls,
    getDictionary(namespace, name = localeName) {
      return dictionaries.get(namespace)?.[name]
    },
    dispose() {
      for (let index = effects.length - 1; index >= 0; index -= 1) {
        const dispose = effects[index]
        if (typeof dispose === 'function') dispose()
      }
      effects.length = 0
    },
  }

  return ctx
}

/**
 * Fake DOM document that records style tags appended to `<head>`.
 * Installed as `globalThis.document` only while `apply()` runs.
 */
export function createFakeDocument() {
  const appended = []
  const removed = []
  const document = {
    head: {
      appendChild(element) {
        appended.push(element)
        return element
      },
    },
    querySelector() {
      return null
    },
    createElement(tagName) {
      const element = {
        tagName: String(tagName).toUpperCase(),
        dataset: {},
        textContent: '',
        remove() {
          removed.push(element)
        },
      }
      return element
    },
  }
  return { document, appended, removed }
}

/**
 * Load the bundle, create a mock context, and run `apply(ctx)`.
 * Returns `{ def, exports, ctx, registration, t }` where `t` is the locale-bound translator
 * and `registration` is the captured `plugins.tab` registration.
 *
 * @param {{ locale?: 'zh' | 'en', document?: object }} [options]
 */
export async function setupClient(options = {}) {
  const def = await loadClientBundle()
  const exports = def.factory(reactRequire)
  const ctx = createMockContext(options)

  const hadDocument = 'document' in globalThis
  const previousDocument = globalThis.document
  if (options.document !== undefined) globalThis.document = options.document
  try {
    exports.apply(ctx)
  } finally {
    if (hadDocument) globalThis.document = previousDocument
    else if (options.document !== undefined) delete globalThis.document
  }

  const registration =
    ctx.registrations.find((entry) => entry.def?.name === 'plugins.tab') ?? null
  const t = ctx.locale.bind('pluginStore')

  return { def, exports, ctx, registration, t }
}

// ---------------------------------------------------------------------------------------------
// Fake store controller for SSR tests (implements the CONTRACT.md snapshot shape).
// ---------------------------------------------------------------------------------------------

/** Localized labels used by the fake controller facets. */
export const DEFAULT_CATEGORY_LABELS = {
  agi: { zh: 'AGI', en: 'AGI' },
  ui: { zh: 'UI 增强', en: 'UI Enhancements' },
  theme: { zh: '主题', en: 'Themes' },
  tools: { zh: '工具', en: 'Tools' },
  memory: { zh: '记忆', en: 'Memory' },
  browser: { zh: '浏览器', en: 'Browser' },
  model: { zh: '模型', en: 'Models' },
  dev: { zh: '开发', en: 'Development' },
  usage: { zh: '用量', en: 'Usage' },
}

export const DEFAULT_CAPABILITY_LABELS = {
  shell: { zh: '终端命令', en: 'Shell' },
  'fs-write': { zh: '写入文件', en: 'File write' },
  'fs-read': { zh: '读取文件', en: 'File read' },
  network: { zh: '网络访问', en: 'Network' },
  env: { zh: '环境变量', en: 'Environment' },
  subagent: { zh: '子代理', en: 'Subagent' },
  llm: { zh: '模型调用', en: 'LLM' },
  'dynamic-code': { zh: '动态代码', en: 'Dynamic code' },
  credentials: { zh: '凭证', en: 'Credentials' },
  'host-runtime': { zh: '宿主运行时', en: 'Host runtime' },
}

/** Build one normalized plugin object (same shape as data.js `normalizePlugin`). */
export function makePlugin(overrides = {}) {
  const owner = overrides.owner ?? 'github-owner'
  const name = overrides.name ?? 'dsh-foo'
  const description = { zh: '', en: '', ...(overrides.description ?? {}) }
  const capabilities = [...(overrides.capabilities ?? [])]
  const category = overrides.category ?? ''

  const plugin = {
    id: overrides.id ?? `${owner}/${name}`.toLowerCase(),
    name,
    owner,
    title: overrides.title ?? name,
    description,
    icon: overrides.icon ?? null,
    avatar: overrides.avatar ?? `https://github.com/${encodeURIComponent(owner)}.png?size=96`,
    category,
    capabilities,
    stars: overrides.stars ?? null,
    npm: overrides.npm ?? null,
    version: overrides.version ?? null,
    install: overrides.install ?? `dsh plugin --profile web add ${name}`,
    page: overrides.page ?? '',
    repo: overrides.repo ?? '',
    added: overrides.added ?? '',
  }

  plugin.searchText = [
    plugin.name,
    plugin.title,
    plugin.owner,
    plugin.description.zh,
    plugin.description.en,
    plugin.category,
    ...plugin.capabilities,
    plugin.npm ?? '',
    plugin.version ?? '',
  ]
    .join(' ')
    .toLowerCase()

  return plugin
}

/** Five realistic catalog entries used by the SSR tests. */
export function createFixturePlugins() {
  return [
    makePlugin({
      name: 'dsh-foo',
      owner: 'github-owner',
      category: 'ui',
      capabilities: ['fs-read'],
      stars: 421,
      npm: 'dsh-foo',
      version: '1.2.3',
      added: '2026-10-25',
      icon: 'https://raw.githubusercontent.com/github-owner/dsh-foo/main/icon.png',
      description: {
        zh: '把插件页面变成可筛选的商店：图标、简介与标签一屏浏览。',
        en: 'Turns the Plugins page into a filterable storefront with icons, blurbs, and tags.',
      },
      page: 'https://awesome-dsh-plugin.com/p/github-owner/dsh-foo/',
      repo: 'https://github.com/github-owner/dsh-foo',
    }),
    makePlugin({
      name: 'dsh-theme-night',
      owner: 'night-owl',
      category: 'theme',
      capabilities: ['fs-write'],
      stars: 188,
      npm: 'dsh-theme-night',
      version: '0.9.0',
      added: '2026-10-02',
      icon: null,
      description: {
        zh: '深色主题与可自定义的配色方案。',
        en: 'A dark theme with configurable color palettes.',
      },
      page: 'https://awesome-dsh-plugin.com/p/night-owl/dsh-theme-night/',
      repo: 'https://github.com/night-owl/dsh-theme-night',
    }),
    makePlugin({
      name: 'dsh-shell-tools',
      owner: 'shellworks',
      category: 'tools',
      capabilities: ['shell', 'env'],
      stars: 907,
      npm: 'dsh-shell-tools',
      version: '3.1.0',
      added: '2026-09-30',
      icon: 'https://raw.githubusercontent.com/shellworks/dsh-shell-tools/main/assets/icon.png',
      description: {
        zh: '在会话里执行 shell 命令，并读取环境变量。',
        en: 'Run shell commands inside a session and read environment variables.',
      },
      page: 'https://awesome-dsh-plugin.com/p/shellworks/dsh-shell-tools/',
      repo: 'https://github.com/shellworks/dsh-shell-tools',
    }),
    makePlugin({
      name: 'dsh-memory-bank',
      owner: 'memory-labs',
      category: 'memory',
      capabilities: ['llm', 'fs-read'],
      stars: 63,
      npm: null,
      version: null,
      added: '2026-10-14',
      icon: null,
      description: {
        zh: '用本地文件保存长期记忆，并交给模型调用。',
        en: 'Keep long-term memory in local files and surface it to the model.',
      },
      page: 'https://awesome-dsh-plugin.com/p/memory-labs/dsh-memory-bank/',
      repo: 'https://github.com/memory-labs/dsh-memory-bank',
    }),
    makePlugin({
      name: 'dsh-browser-pilot',
      owner: 'pilot-team',
      category: 'browser',
      capabilities: ['network', 'subagent'],
      stars: 274,
      npm: 'dsh-browser-pilot',
      version: '2.0.0',
      added: '2026-10-20',
      icon: 'https://raw.githubusercontent.com/pilot-team/dsh-browser-pilot/main/logo.png',
      description: {
        zh: '驱动无头浏览器抓取页面，并把结果交给子代理处理。',
        en: 'Drive a headless browser and hand the results to a subagent.',
      },
      page: 'https://awesome-dsh-plugin.com/p/pilot-team/dsh-browser-pilot/',
      repo: 'https://github.com/pilot-team/dsh-browser-pilot',
    }),
  ]
}

function sortFakeResults(plugins, sort) {
  const results = [...plugins]
  if (sort === 'name') {
    results.sort((left, right) => left.name.localeCompare(right.name))
  } else if (sort === 'added') {
    results.sort((left, right) => (right.added || '').localeCompare(left.added || ''))
  } else {
    // stars desc, nulls last
    results.sort((left, right) => {
      const leftStars = left.stars ?? -1
      const rightStars = right.stars ?? -1
      return rightStars - leftStars
    })
  }
  return results
}

function matchesFakeQuery(plugin, query) {
  const text = query.text.trim().toLowerCase()
  if (text && !plugin.searchText.includes(text)) return false
  if (query.category && plugin.category !== query.category) return false
  for (const capability of query.capabilities) {
    if (!plugin.capabilities.includes(capability)) return false
  }
  return true
}

function computeFakeFacets(plugins, categoryLabels, capabilityLabels) {
  const categoryCounts = new Map()
  const capabilityCounts = new Map()
  for (const plugin of plugins) {
    if (plugin.category) {
      categoryCounts.set(plugin.category, (categoryCounts.get(plugin.category) ?? 0) + 1)
    }
    for (const capability of plugin.capabilities) {
      capabilityCounts.set(capability, (capabilityCounts.get(capability) ?? 0) + 1)
    }
  }

  const categories = [...categoryCounts.entries()]
    .map(([id, count]) => ({
      id,
      label: categoryLabels[id] ?? { zh: id, en: id },
      count,
    }))
    .sort((left, right) => right.count - left.count || left.id.localeCompare(right.id))

  const capabilityOrder = Object.keys(capabilityLabels)
  const capabilities = [...capabilityCounts.entries()]
    .map(([id, count]) => ({
      id,
      label: capabilityLabels[id] ?? { zh: id, en: id },
      count,
    }))
    .sort(
      (left, right) => capabilityOrder.indexOf(left.id) - capabilityOrder.indexOf(right.id),
    )

  return { categories, capabilities }
}

/**
 * Fake store controller implementing the CONTRACT.md controller surface.
 * Filtering/sorting/pagination are implemented locally so SSR assertions do not need the
 * real data layer and never touch the network.
 *
 * @param {{
 *   plugins?: ReturnType<typeof makePlugin>[],
 *   pageSize?: number,
 *   sort?: 'stars' | 'added' | 'name',
 *   source?: object,
 *   categoryLabels?: Record<string, { zh: string, en: string }>,
 *   capabilityLabels?: Record<string, { zh: string, en: string }>,
 * }} [options]
 */
export function createFakeController(options = {}) {
  const pageSize = options.pageSize ?? 60
  const plugins = (options.plugins ?? createFixturePlugins()).map((plugin) => ({
    ...plugin,
    capabilities: [...plugin.capabilities],
    description: { ...plugin.description },
  }))
  const categoryLabels = { ...DEFAULT_CATEGORY_LABELS, ...(options.categoryLabels ?? {}) }
  const capabilityLabels = {
    ...DEFAULT_CAPABILITY_LABELS,
    ...(options.capabilityLabels ?? {}),
  }

  const calls = {
    load: 0,
    refresh: 0,
    retry: 0,
    setText: [],
    setCategory: [],
    toggleCapability: [],
    clearFilters: 0,
    setSort: [],
    showMore: 0,
  }

  const listeners = new Set()
  const query = { text: '', category: null, capabilities: [] }
  let sort = options.sort ?? 'stars'
  let visiblePages = 1
  let snapshot = null
  let disposed = false

  function buildSnapshot() {
    const results = sortFakeResults(
      plugins.filter((plugin) => matchesFakeQuery(plugin, query)),
      sort,
    )
    const facets = computeFakeFacets(plugins, categoryLabels, capabilityLabels)
    const visible = Math.min(results.length, visiblePages * pageSize)

    snapshot = Object.freeze({
      status: 'ready',
      refreshing: false,
      error: null,
      source: options.source ?? {
        url: 'https://cdn.jsdelivr.net/npm/dsh-plugin-catalog@latest/plugins.json',
        title: 'Official catalog',
        fetchedAt: 1762080000000,
        offline: false,
      },
      plugins: Object.freeze(plugins.map((plugin) => Object.freeze(plugin))),
      results,
      facets,
      query: {
        text: query.text,
        category: query.category,
        capabilities: [...query.capabilities],
      },
      sort,
      pageSize,
      visible,
      total: results.length,
      hasMore: results.length > visible,
    })
  }

  function emit() {
    if (disposed) return
    buildSnapshot()
    for (const listener of listeners) listener()
  }

  buildSnapshot()

  const controller = {
    subscribe(listener) {
      listeners.add(listener)
      return () => listeners.delete(listener)
    },
    getSnapshot() {
      return snapshot
    },
    async load() {
      calls.load += 1
      return snapshot
    },
    async refresh() {
      calls.refresh += 1
      return snapshot
    },
    async retry() {
      calls.retry += 1
      return snapshot
    },
    setText(text) {
      calls.setText.push(text)
      query.text = String(text ?? '')
      visiblePages = 1
      emit()
    },
    setCategory(category) {
      calls.setCategory.push(category)
      query.category = category || null
      visiblePages = 1
      emit()
    },
    toggleCapability(capability) {
      calls.toggleCapability.push(capability)
      const index = query.capabilities.indexOf(capability)
      if (index === -1) query.capabilities.push(capability)
      else query.capabilities.splice(index, 1)
      visiblePages = 1
      emit()
    },
    clearFilters() {
      calls.clearFilters += 1
      query.text = ''
      query.category = null
      query.capabilities = []
      visiblePages = 1
      emit()
    },
    setSort(nextSort) {
      calls.setSort.push(nextSort)
      if (nextSort === 'stars' || nextSort === 'added' || nextSort === 'name') sort = nextSort
      emit()
    },
    showMore() {
      calls.showMore += 1
      visiblePages += 1
      emit()
    },
    dispose() {
      disposed = true
      listeners.clear()
    },
    calls,
  }

  return controller
}
