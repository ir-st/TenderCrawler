/**
 * Unit tests for the built DSH client bundle: module-loader wrapper, factory exports,
 * the `plugins.tab` registration, locale dictionaries, and style-tag lifecycle.
 */

import test from 'node:test'
import assert from 'node:assert/strict'
import fs from 'node:fs'

import {
  createFakeDocument,
  loadClientBundle,
  maskNonCode,
  paths,
  reactRequire,
  setupClient,
} from './harness.mjs'

test('built bundle exists and carries the DSH ModuleLoader wrapper', () => {
  assert.ok(
    fs.existsSync(paths.clientBundle),
    `missing ${paths.clientBundle}; run node scripts/build-client.mjs first`,
  )
  const source = fs.readFileSync(paths.clientBundle, 'utf8')
  assert.match(source, /^window\.__ModuleLoader__\.load\(\{/)
  const escapedName = paths.pluginName.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
  assert.match(source, new RegExp(`id: "${escapedName}"`))
  assert.match(source, /factory: \(require\) => \{/)
  assert.match(source, /return module\.exports;/)

  // Code-shape checks ignore string literals/comments (catalog descriptions may contain
  // text such as `import(` or `require(`).
  const code = maskNonCode(source)
  assert.doesNotMatch(code, /\bimport\s*\(/, 'bundle must not contain dynamic import()')
  assert.doesNotMatch(code, /^import\b/m, 'bundle must not contain top-level import statements')

  // The only runtime requires are the declared platform externals.
  const requiredModules = []
  for (const match of code.matchAll(/\brequire\s*\(/g)) {
    const literal = /^\s*(['"])([^'"]+)\1\s*\)/.exec(source.slice(match.index + match[0].length))
    assert.ok(literal, 'every require() in the bundle must be a literal')
    requiredModules.push(literal[2])
  }
  assert.deepEqual(
    [...new Set(requiredModules)].sort(),
    ['react', 'react/jsx-runtime'],
    'bundle must only require react / react/jsx-runtime',
  )
})

test('factory returns the plugin client exports', async () => {
  const def = await loadClientBundle()
  assert.equal(def.id, paths.pluginName)
  assert.equal(typeof def.factory, 'function')

  const exports = def.factory(reactRequire)
  assert.ok(exports && typeof exports === 'object', 'factory must return module.exports')
  assert.equal(typeof exports.apply, 'function', 'client bundle must export apply(ctx)')
  assert.ok(Array.isArray(exports.inject), 'client bundle must export an inject array')
  assert.deepEqual([...exports.inject], ['slots', 'locale'])
})

test('apply registers the Store tab on plugins.tab with the contracted metadata', async () => {
  const { ctx, registration } = await setupClient()

  assert.ok(registration, 'apply() must register a plugins.tab slot')
  assert.equal(registration.name, 'plugins.tab')
  assert.equal(registration.def.name, 'plugins.tab')
  assert.equal(registration.def.id, 'store')
  assert.equal(registration.def.order, 20)
  assert.equal(registration.def.locale, 'pluginStore')
  assert.equal(typeof registration.def.label, 'function', 'tab label must be a function')
  assert.equal(typeof registration.component, 'function', 'tab component must be StoreTab')

  // Exactly one slot contribution, through slots.inject.
  assert.equal(ctx.injections.length, 1)
  assert.equal(ctx.injections[0].name, 'plugins.tab')
})

test('tab label resolves to 商店 / Store through the mock locale', async () => {
  const zh = await setupClient({ locale: 'zh' })
  assert.equal(zh.registration.def.label(), '商店')
  assert.equal(zh.t('title'), '商店')

  const en = await setupClient({ locale: 'en' })
  assert.equal(en.registration.def.label(), 'Store')
  assert.equal(en.t('title'), 'Store')
})

test('locale dictionaries exist for zh and en with identical key sets', async () => {
  const { ctx } = await setupClient()
  const zh = ctx.getDictionary('pluginStore', 'zh')
  const en = ctx.getDictionary('pluginStore', 'en')
  assert.ok(zh && typeof zh === 'object', 'zh dictionary must be registered')
  assert.ok(en && typeof en === 'object', 'en dictionary must be registered')

  const zhKeys = Object.keys(zh).sort()
  const enKeys = Object.keys(en).sort()
  assert.deepEqual(
    enKeys,
    zhKeys,
    `zh/en dictionaries must share the same keys (zh only: ${zhKeys
      .filter((key) => !enKeys.includes(key))
      .join(', ')}; en only: ${enKeys.filter((key) => !zhKeys.includes(key)).join(', ')})`,
  )

  // Interpolation contract used by the UI: t('count', { count: 3 }).
  const { t } = await setupClient()
  assert.equal(t('count', { count: 3 }), '3 个插件')
  assert.equal(t('showingMore', { shown: 60, total: 120 }), '已显示 60 / 120')
})

test('registration inject face provides the controller and resolveText', async () => {
  const { registration } = await setupClient()
  const face = registration.def.inject
  assert.equal(typeof face, 'function', 'registration must declare inject()')
  const props = registration.def.inject()
  assert.ok(props && typeof props === 'object', 'inject() must return a props object')

  const { controller } = props
  assert.ok(controller, 'inject() must provide a controller')
  for (const method of [
    'getSnapshot',
    'subscribe',
    'load',
    'refresh',
    'retry',
    'setText',
    'setCategory',
    'toggleCapability',
    'clearFilters',
    'setSort',
    'showMore',
    'dispose',
  ]) {
    assert.equal(typeof controller[method], 'function', `controller.${method} must be a function`)
  }

  if (typeof props.resolveText !== 'undefined') {
    assert.equal(typeof props.resolveText, 'function', 'resolveText must be a function')
    assert.equal(props.resolveText({ zh: '中文', en: 'English' }), '中文')
    assert.equal(props.resolveText('plain'), 'plain')
  }

  const snapshot = controller.getSnapshot()
  assert.ok(['idle', 'loading'].includes(snapshot.status), `unexpected initial status ${snapshot.status}`)
  assert.ok(Array.isArray(snapshot.plugins))
  assert.ok(Array.isArray(snapshot.results))
  assert.ok(Array.isArray(snapshot.facets?.categories))
  assert.ok(Array.isArray(snapshot.facets?.capabilities))
  controller.dispose()
})

test('apply injects exactly one style tag and removes it on dispose', async () => {
  const fake = createFakeDocument()
  const { ctx } = await setupClient({ document: fake.document })

  assert.equal(fake.appended.length, 1, 'apply() must inject exactly one <style> tag')
  const [tag] = fake.appended
  assert.equal(tag.tagName, 'STYLE')
  assert.ok(tag.textContent.length > 100, 'style tag must contain the STORE_CSS string')
  assert.ok(tag.textContent.includes('ps-'), 'stylesheet must use the ps- class prefix')
  assert.equal(fake.removed.length, 0, 'style tag must not be removed before dispose')

  ctx.dispose()
  assert.equal(fake.removed.length, 1, 'dispose() must remove the injected style tag')
})
