/**
 * Unit tests for the Plugin Store data layer.
 *
 * Everything runs offline: `fetchCatalog` always receives a mock `fetchImpl`, and the controller is
 * driven either with an injected `load()` or with the bundled snapshot. Run with:
 *
 *   node --test tests/data.test.mjs
 */

import { test } from 'node:test'
import assert from 'node:assert/strict'
import { readFileSync, statSync } from 'node:fs'
import { fileURLToPath } from 'node:url'

import {
  CATEGORY_TITLES,
  CAPABILITY_TITLES,
  DEFAULT_SOURCE_URLS,
  PAGE_SIZE,
  SNAPSHOT,
  normalizePlugin,
  normalizeCatalog,
  computeFacets,
  filterPlugins,
  sortPlugins,
  fetchCatalog,
  createStoreController,
} from '../src/client/data.js'

const CATEGORY_IDS = Object.keys(CATEGORY_TITLES)
const CAPABILITY_IDS = Object.keys(CAPABILITY_TITLES)
const SNAPSHOT_FILE = fileURLToPath(new URL('../src/client/snapshot.data.js', import.meta.url))

/* -------------------------------------------------------------------------------------------------
 * Fixtures / helpers
 * ----------------------------------------------------------------------------------------------- */

/** One valid raw catalog entry; override any field (including with `undefined`). */
function rawEntry(overrides = {}) {
  return {
    name: 'dsh-demo',
    owner: 'octo',
    url: 'https://github.com/octo/dsh-demo',
    page: 'https://awesome-dsh-plugin.com/p/octo/dsh-demo/',
    category: 'ui',
    description: { zh: '演示插件', en: 'Demo plugin' },
    npm: 'dsh-demo',
    version: '1.0.0',
    stars: 10,
    capabilities: ['fs-read'],
    install: 'dsh plugin --profile web add dsh-demo',
    added: '2026-10-01',
    icon: null,
    ...overrides,
  }
}

function normalized(overrides = {}, index = 0) {
  return normalizePlugin(rawEntry(overrides), index)
}

/** Payload with `count` distinct raw plugins, accepted by the fetchCatalog > 100 validation rule. */
function catalogPayload(count) {
  const plugins = []
  for (let index = 0; index < count; index += 1) {
    plugins.push(rawEntry({ name: `plugin-${index}`, owner: `owner-${index}`, stars: index }))
  }
  return { plugins }
}

let mirrorSequence = 0
/** Unique mirror URL list per test so the module-level catalog cache cannot leak between tests. */
function mirrorUrls(count = 3) {
  mirrorSequence += 1
  return Array.from({ length: count }, (_, index) => `https://mirror-${mirrorSequence}-${index}.test/plugins.json`)
}

/** Raw plugins used by the controller/filter tests (UI, tools; shell/fs-read/network). */
function fixturePlugins() {
  return [
    rawEntry({
      name: 'dsh-ui-read',
      owner: 'octo',
      category: 'ui',
      capabilities: ['fs-read'],
      stars: 40,
      added: '2026-03-01',
      description: { zh: '界面读取', en: 'UI reader' },
    }),
    rawEntry({
      name: 'dsh-ui-shell',
      owner: 'octo',
      category: 'ui',
      capabilities: ['shell'],
      stars: 30,
      added: '2026-05-01',
      description: { zh: '界面终端', en: 'UI shell' },
    }),
    rawEntry({
      name: 'dsh-tool-net',
      owner: 'iris',
      category: 'tools',
      capabilities: ['network'],
      stars: 20,
      added: '2026-01-01',
      description: { zh: '网络工具', en: 'Network tool' },
    }),
    rawEntry({
      name: 'dsh-tool-shell',
      owner: 'iris',
      category: 'tools',
      capabilities: ['shell', 'network'],
      stars: 10,
      added: '2026-06-01',
      description: { zh: '终端网络', en: 'Shell network' },
    }),
  ]
}

/** Deterministic plugin factory with stars == index (so sorting is easy to assert). */
function makePlugins(count) {
  return Array.from({ length: count }, (_, index) => rawEntry({
    name: `plugin-${String(index).padStart(3, '0')}`,
    owner: 'octo',
    category: index % 2 === 0 ? 'tools' : 'ui',
    capabilities: index % 3 === 0 ? ['shell'] : ['fs-read'],
    stars: index,
    added: `2026-01-${String((index % 28) + 1).padStart(2, '0')}`,
  }))
}

function loaderOf(plugins, extras = {}) {
  const calls = { count: 0 }
  const load = async () => {
    calls.count += 1
    return {
      plugins,
      sourceUrl: DEFAULT_SOURCE_URLS[0],
      fetchedAt: 1700000000000,
      ...extras,
    }
  }
  return { load, calls }
}

/* -------------------------------------------------------------------------------------------------
 * Constants / bundled snapshot
 * ----------------------------------------------------------------------------------------------- */

test('CATEGORY_TITLES exposes all 23 localized categories', () => {
  assert.deepEqual(CATEGORY_IDS, [
    'agi', 'ui', 'usage', 'theme', 'model', 'identity', 'session', 'memory', 'tools', 'wsl',
    'browser', 'vision', 'voice', 'docs', 'skill', 'workflow', 'git', 'notify', 'dev', 'security',
    'remote', 'market', 'fun',
  ])
  for (const [id, label] of Object.entries(CATEGORY_TITLES)) {
    assert.equal(typeof label.zh, 'string', `${id}.zh`)
    assert.ok(label.zh.length > 0, `${id}.zh is empty`)
    assert.equal(typeof label.en, 'string', `${id}.en`)
    assert.ok(label.en.length > 0, `${id}.en is empty`)
  }
  assert.ok(Object.isFrozen(CATEGORY_TITLES))
})

test('CAPABILITY_TITLES exposes the 10 capabilities in fixed order', () => {
  assert.deepEqual(CAPABILITY_IDS, [
    'shell', 'fs-write', 'fs-read', 'network', 'env', 'subagent', 'llm', 'dynamic-code',
    'credentials', 'host-runtime',
  ])
  for (const [id, label] of Object.entries(CAPABILITY_TITLES)) {
    assert.ok(label.zh.length > 0, `${id}.zh is empty`)
    assert.ok(label.en.length > 0, `${id}.en is empty`)
  }
})

test('DEFAULT_SOURCE_URLS lists the three catalog mirrors in contract order', () => {
  assert.deepEqual(DEFAULT_SOURCE_URLS, [
    'https://cdn.jsdelivr.net/npm/dsh-plugin-catalog@latest/plugins.json',
    'https://unpkg.com/dsh-plugin-catalog@latest/plugins.json',
    'https://awesome-dsh-plugin.com/plugins.json',
  ])
  assert.ok(Object.isFrozen(DEFAULT_SOURCE_URLS))
  assert.equal(PAGE_SIZE, 60)
})

test('bundled SNAPSHOT is a usable offline catalog', () => {
  assert.equal(typeof SNAPSHOT, 'object')
  assert.match(SNAPSHOT.sourceUrl, /^https:\/\//)
  assert.ok(Number.isFinite(Date.parse(SNAPSHOT.generatedAt)), 'generatedAt is an ISO timestamp')
  assert.ok(Array.isArray(SNAPSHOT.plugins))
  assert.ok(SNAPSHOT.plugins.length > 0, 'snapshot has entries')
  assert.ok(SNAPSHOT.plugins.length <= 300, 'snapshot has at most 300 entries')

  const plugins = normalizeCatalog(SNAPSHOT.plugins)
  assert.equal(plugins.length, SNAPSHOT.plugins.length, 'every snapshot entry is usable and unique')
  const categories = new Set(plugins.map((plugin) => plugin.category))
  assert.equal(categories.size, CATEGORY_IDS.length, 'all categories are represented')
  for (const plugin of plugins) {
    assert.ok(plugin.name.length > 0)
    assert.equal(typeof plugin.description.zh, 'string')
    assert.equal(typeof plugin.description.en, 'string')
    assert.equal(typeof plugin.avatar, 'string')
  }
})

test('generated snapshot.data.js stays under the 400 KB budget', () => {
  const { size } = statSync(SNAPSHOT_FILE)
  assert.ok(size > 1024, `snapshot is suspiciously small: ${size} bytes`)
  assert.ok(size <= 400 * 1024, `snapshot is ${size} bytes, above the 400 KB budget`)
  // Keep output ASCII-safe for tooling: no raw BOM / no U+2028 line separators.
  const text = readFileSync(SNAPSHOT_FILE, 'utf8')
  assert.ok(!text.startsWith('\uFEFF'))
  assert.ok(!text.includes('\u2028'))
  assert.ok(text.includes('export const SNAPSHOT ='))
})

/* -------------------------------------------------------------------------------------------------
 * normalizePlugin
 * ----------------------------------------------------------------------------------------------- */

test('normalizePlugin maps a complete catalog entry', () => {
  const plugin = normalizePlugin(rawEntry({
    name: 'dsh-demo',
    owner: 'Octo',
    icon: 'https://raw.githubusercontent.com/Octo/dsh-demo/main/icon.png',
    capabilities: ['fs-read', 'shell', 'llm'],
    stars: 12,
  }), 7)

  assert.equal(plugin.id, 'octo/dsh-demo')
  assert.equal(plugin.name, 'dsh-demo')
  assert.equal(plugin.title, 'dsh-demo')
  assert.equal(plugin.owner, 'Octo')
  assert.deepEqual(plugin.description, { zh: '演示插件', en: 'Demo plugin' })
  assert.equal(plugin.icon, 'https://raw.githubusercontent.com/Octo/dsh-demo/main/icon.png')
  assert.equal(plugin.avatar, 'https://github.com/Octo.png?size=96')
  assert.equal(plugin.category, 'ui')
  assert.deepEqual(plugin.capabilities, ['shell', 'fs-read', 'llm']) // canonical CAPABILITY order
  assert.equal(plugin.stars, 12)
  assert.equal(plugin.npm, 'dsh-demo')
  assert.equal(plugin.version, '1.0.0')
  assert.equal(plugin.install, 'dsh plugin --profile web add dsh-demo')
  assert.equal(plugin.page, 'https://awesome-dsh-plugin.com/p/octo/dsh-demo/')
  assert.equal(plugin.repo, 'https://github.com/octo/dsh-demo')
  assert.equal(plugin.added, '2026-10-01')

  assert.equal(plugin.searchText, plugin.searchText.toLowerCase())
  for (const token of ['dsh-demo', 'octo', '演示插件', 'demo plugin', 'ui 增强', '终端命令', 'llm']) {
    assert.ok(plugin.searchText.includes(token), `searchText should contain ${token}`)
  }
})

test('normalizePlugin never throws on non-object entries', () => {
  const entries = [null, undefined, 'nope', 42, true, [1, 2], () => {}]
  entries.forEach((entry, index) => {
    const plugin = normalizePlugin(entry, index)
    assert.equal(plugin.name, '')
    assert.equal(plugin.id, `entry-${index}`)
    assert.deepEqual(plugin.description, { zh: '', en: '' })
    assert.deepEqual(plugin.capabilities, [])
    assert.equal(plugin.stars, null)
    assert.equal(plugin.avatar, '')
    assert.equal(plugin.icon, null)
    assert.equal(plugin.page, '')
    assert.equal(plugin.repo, '')
    assert.equal(plugin.added, '')
    assert.equal(plugin.install, '')
    assert.equal(plugin.npm, null)
    assert.equal(plugin.version, null)
  })
})

test('description is always an object with both language strings', () => {
  assert.deepEqual(normalized({ description: { zh: '中文', en: 'English' } }).description, { zh: '中文', en: 'English' })
  assert.deepEqual(normalized({ description: { zh: '只有中文' } }).description, { zh: '只有中文', en: '' })
  assert.deepEqual(normalized({ description: { en: 'only english' } }).description, { zh: '', en: 'only english' })
  assert.deepEqual(normalized({ description: 'plain description' }).description, {
    zh: 'plain description',
    en: 'plain description',
  })
  assert.deepEqual(normalized({ description: 42 }).description, { zh: '', en: '' })
  assert.deepEqual(normalized({ description: null }).description, { zh: '', en: '' })
  assert.deepEqual(normalized({ description: ['a', 'b'] }).description, { zh: '', en: '' })
  assert.deepEqual(normalized({ description: { zh: 42, en: { nope: true } } }).description, { zh: '42', en: '' })
})

test('icon keeps only absolute http(s) and data:image URLs', () => {
  assert.equal(normalized({ icon: 'https://example.com/icon.png' }).icon, 'https://example.com/icon.png')
  assert.equal(normalized({ icon: 'data:image/png;base64,AAAA' }).icon, 'data:image/png;base64,AAAA')
  for (const bad of ['icon.png', '/icon.png', 'javascript:alert(1)', '  ', 42, null, {}, 'data:text/html,<b>x</b>']) {
    assert.equal(normalized({ icon: bad }).icon, null, `icon ${String(bad)} should be rejected`)
  }
})

test('avatar derives from a sanitized owner', () => {
  assert.equal(normalized({ owner: 'Octo' }).avatar, 'https://github.com/Octo.png?size=96')
  assert.equal(normalized({ owner: '@octo' }).owner, 'octo')
  assert.equal(normalized({ owner: ' https://github.com/Octo/dsh-demo/ ' }).owner, 'Octo')
  assert.equal(normalized({ owner: 'weird name' }).avatar, 'https://github.com/weird%20name.png?size=96')
  assert.equal(normalized({ owner: '   ' }).avatar, '')
  assert.equal(normalized({ owner: null }).owner, '')
})

test('stars parse numeric values but reject nonsense and negatives', () => {
  const cases = [
    [10, 10],
    [0, 0],
    ['12', 12],
    ['1,234', 1234],
    [' 42 ', 42],
    [3.9, 3],
    [-3, null],
    [Number.NaN, null],
    [Number.POSITIVE_INFINITY, null],
    ['abc', null],
    ['', null],
    [{}, null],
    [true, null],
    [null, null],
  ]
  for (const [input, expected] of cases) {
    assert.equal(normalized({ stars: input }).stars, expected, `stars=${String(input)}`)
  }
})

test('category and capabilities are validated against the fixed catalogs', () => {
  assert.equal(normalized({ category: 'UI' }).category, 'ui')
  assert.equal(normalized({ category: 'unknown' }).category, '')
  assert.equal(normalized({ category: 42 }).category, '')
  assert.deepEqual(normalized({ capabilities: ['llm', 'shell', 'LLM', 'nope', 'fs-write', 'shell'] }).capabilities, [
    'shell',
    'fs-write',
    'llm',
  ])
  assert.deepEqual(normalized({ capabilities: 'shell, llm' }).capabilities, ['shell', 'llm'])
  assert.deepEqual(normalized({ capabilities: 'not-real' }).capabilities, [])
  assert.deepEqual(normalized({ capabilities: {} }).capabilities, [])
  assert.deepEqual(normalized({ capabilities: null }).capabilities, [])
})

test('page/repo/added/npm/version are sanitized', () => {
  assert.equal(normalized({ page: 'https://awesome-dsh-plugin.com/p/octo/dsh-demo/' }).page, 'https://awesome-dsh-plugin.com/p/octo/dsh-demo/')
  assert.equal(normalized({ page: '//evil.example/x' }).page, '')
  assert.equal(normalized({ page: '/relative' }).page, '')
  assert.equal(normalized({ url: 'https://github.com/octo/other' }).repo, 'https://github.com/octo/other')
  assert.equal(normalized({ url: 'javascript:alert(1)' }).repo, '')
  assert.equal(normalized({ url: 'javascript:alert(1)', repo: 'https://github.com/octo/other' }).repo, 'https://github.com/octo/other')
  assert.equal(normalized({ added: '2026-10-25T13:00:00Z' }).added, '2026-10-25')
  assert.equal(normalized({ added: '2026-2-5' }).added, '')
  assert.equal(normalized({ added: 'not-a-date' }).added, '')
  assert.equal(normalized({ added: '2026-13-01' }).added, '')
  assert.equal(normalized({ added: '2026-02-30' }).added, '')
  assert.equal(normalized({ added: 20261025 }).added, '')
  assert.equal(normalized({ npm: '' }).npm, null)
  assert.equal(normalized({ npm: {} }).npm, null)
  assert.equal(normalized({ npm: 42 }).npm, '42')
  assert.equal(normalized({ version: '' }).version, null)
  assert.equal(normalized({ version: null }).version, null)
  assert.equal(normalized({ version: { major: 1 } }).version, null)
  assert.equal(normalized({ install: undefined }).install, '')
})

test('ids are unique, lowercased, and scope-aware', () => {
  assert.equal(normalized({ name: 'DSH-Demo', owner: 'Octo' }).id, 'octo/dsh-demo')
  assert.equal(normalized({ name: '@Scope/Pkg', owner: 'anyone' }).id, '@scope/pkg')
  assert.equal(normalized({ name: 'dsh-solo', owner: '' }).id, 'dsh-solo')
})

/* -------------------------------------------------------------------------------------------------
 * normalizeCatalog
 * ----------------------------------------------------------------------------------------------- */

test('normalizeCatalog handles raw payloads, nameless entries and duplicate ids', () => {
  const plugins = normalizeCatalog({
    plugins: [
      rawEntry({ name: 'dsh-a', owner: 'o', stars: 5 }),
      rawEntry({ name: 'dsh-a', owner: 'o', stars: 99 }), // duplicate id: first wins
      rawEntry({ name: 'dsh-b', owner: 'O', stars: 1 }),
      { name: '' },
      null,
      'garbage',
    ],
  })
  assert.equal(plugins.length, 2)
  assert.equal(plugins[0].stars, 5)
  assert.equal(plugins[1].id, 'o/dsh-b')

  assert.deepEqual(normalizeCatalog(null), [])
  assert.deepEqual(normalizeCatalog({}), [])
  assert.deepEqual(normalizeCatalog({ plugins: 'nope' }), [])
  assert.deepEqual(normalizeCatalog('nope'), [])
  assert.equal(normalizeCatalog([rawEntry({ name: 'dsh-c' })]).length, 1)
})

test('normalizeCatalog is idempotent for already-normalized entries', () => {
  const once = normalizeCatalog([rawEntry({ name: 'dsh-d' })])
  const twice = normalizeCatalog(once)
  assert.equal(twice.length, 1)
  assert.equal(twice[0].id, once[0].id)
  assert.equal(twice[0].repo, once[0].repo)
  assert.deepEqual(twice[0].capabilities, once[0].capabilities)
  assert.equal(twice[0].searchText, once[0].searchText)
})

/* -------------------------------------------------------------------------------------------------
 * computeFacets
 * ----------------------------------------------------------------------------------------------- */

test('computeFacets counts plugins and orders chips', () => {
  const plugins = normalizeCatalog([
    rawEntry({ name: 'a', owner: 'o', category: 'ui', capabilities: ['shell', 'network'] }),
    rawEntry({ name: 'b', owner: 'o', category: 'ui', capabilities: ['shell'] }),
    rawEntry({ name: 'c', owner: 'o', category: 'tools', capabilities: ['llm'] }),
    rawEntry({ name: 'd', owner: 'o', category: '', capabilities: ['shell'] }),
    rawEntry({ name: 'e', owner: 'o', category: 'not-a-category', capabilities: ['not-a-capability'] }),
  ])
  const facets = computeFacets(plugins)

  assert.deepEqual(facets.categories.map((facet) => facet.id), ['ui', 'tools'])
  assert.deepEqual(facets.categories.map((facet) => facet.count), [2, 1])
  assert.deepEqual(facets.categories[0].label, CATEGORY_TITLES.ui)
  // fixed CAPABILITY_TITLES order, only capabilities present in the data
  assert.deepEqual(facets.capabilities.map((facet) => facet.id), ['shell', 'network', 'llm'])
  assert.deepEqual(facets.capabilities.map((facet) => facet.count), [3, 1, 1])
  assert.deepEqual(facets.capabilities[0].label, CAPABILITY_TITLES.shell)

  assert.deepEqual(computeFacets([]), { categories: [], capabilities: [] })
  assert.deepEqual(computeFacets(null), { categories: [], capabilities: [] })
})

/* -------------------------------------------------------------------------------------------------
 * filterPlugins
 * ----------------------------------------------------------------------------------------------- */

test('filterPlugins searches name/owner/description/category/capabilities case-insensitively', () => {
  const plugins = normalizeCatalog(fixturePlugins())
  const names = (query) => filterPlugins(plugins, query).map((plugin) => plugin.name)

  assert.deepEqual(names({ text: 'alpha' }), [])
  assert.deepEqual(names({ text: 'Dsh-UI-ReAd' }), ['dsh-ui-read'])
  assert.deepEqual(names({ text: 'IRIS' }), ['dsh-tool-net', 'dsh-tool-shell'])
  assert.deepEqual(names({ text: '界面读取' }), ['dsh-ui-read'])
  assert.deepEqual(names({ text: 'ui reader' }), ['dsh-ui-read'])
  assert.deepEqual(names({ text: 'ui 增强' }), ['dsh-ui-read', 'dsh-ui-shell'])
  assert.deepEqual(names({ text: '终端命令' }), ['dsh-ui-shell', 'dsh-tool-shell'])
  assert.deepEqual(names({ text: 'octo network' }), [])

  // no constraints -> copy of all
  const all = filterPlugins(plugins, {})
  assert.deepEqual(all.map((plugin) => plugin.name), plugins.map((plugin) => plugin.name))
  assert.notEqual(all, plugins)
  assert.deepEqual(filterPlugins(plugins, { text: '   ' }).length, plugins.length)
})

test('filterPlugins ANDs category and every selected capability', () => {
  const plugins = normalizeCatalog(fixturePlugins())
  const names = (query) => filterPlugins(plugins, query).map((plugin) => plugin.name)

  assert.deepEqual(names({ category: 'ui' }), ['dsh-ui-read', 'dsh-ui-shell'])
  assert.deepEqual(names({ capabilities: ['shell'] }), ['dsh-ui-shell', 'dsh-tool-shell'])
  assert.deepEqual(names({ capabilities: ['shell', 'network'] }), ['dsh-tool-shell'])
  assert.deepEqual(names({ category: 'ui', capabilities: ['fs-read'] }), ['dsh-ui-read'])
  assert.deepEqual(names({ category: 'tools', capabilities: ['shell'] }), ['dsh-tool-shell'])
  assert.deepEqual(names({ category: 'tools', capabilities: ['shell', 'fs-read'] }), [])
  assert.deepEqual(names({ category: 'fun' }), [])

  // unknown ids are ignored instead of matching nothing
  assert.equal(filterPlugins(plugins, { capabilities: ['not-real'] }).length, plugins.length)
})

test('filterPlugins tolerates malformed plugin entries and never mutates input', () => {
  const plugins = normalizeCatalog(fixturePlugins())
  const snapshotNames = plugins.map((plugin) => plugin.name)
  const mixed = [null, { name: 'x' }, ...plugins]
  assert.equal(filterPlugins(mixed, { text: 'dsh' }).length, plugins.length)
  filterPlugins(plugins, { text: 'ui', category: 'ui', capabilities: ['fs-read'] })
  assert.deepEqual(plugins.map((plugin) => plugin.name), snapshotNames)
})

/* -------------------------------------------------------------------------------------------------
 * sortPlugins
 * ----------------------------------------------------------------------------------------------- */

test('sortPlugins puts null stars last and never mutates the input', () => {
  const plugins = normalizeCatalog([
    rawEntry({ name: 'a', stars: null }),
    rawEntry({ name: 'b', stars: 5 }),
    rawEntry({ name: 'c', stars: 9 }),
    rawEntry({ name: 'd', stars: null }),
  ])
  const names = plugins.map((plugin) => plugin.name)
  const sorted = sortPlugins(plugins, 'stars')
  assert.deepEqual(sorted.map((plugin) => plugin.name), ['c', 'b', 'a', 'd'])
  assert.notEqual(sorted, plugins)
  assert.deepEqual(plugins.map((plugin) => plugin.name), names)
  assert.deepEqual(sortPlugins(plugins, 'unknown-mode').map((plugin) => plugin.name), ['c', 'b', 'a', 'd'])
})

test('sortPlugins added sorts newest first with empty dates last', () => {
  const plugins = normalizeCatalog([
    rawEntry({ name: 'old', added: '2026-01-01' }),
    rawEntry({ name: 'new', added: '2026-10-25' }),
    rawEntry({ name: 'none', added: '' }),
    rawEntry({ name: 'mid', added: '2026-03-03' }),
    rawEntry({ name: 'also-none', added: '' }),
  ])
  const sorted = sortPlugins(plugins, 'added')
  assert.deepEqual(sorted.slice(0, 3).map((plugin) => plugin.name), ['new', 'mid', 'old'])
  assert.deepEqual(sorted.slice(3).map((plugin) => plugin.name).sort(), ['also-none', 'none'])
})

test('sortPlugins name sorts with localeCompare', () => {
  const plugins = normalizeCatalog([
    rawEntry({ name: 'dsh-beta' }),
    rawEntry({ name: 'dsh-Alpha' }),
    rawEntry({ name: 'dsh-gamma' }),
  ])
  assert.deepEqual(sortPlugins(plugins, 'name').map((plugin) => plugin.name), [
    'dsh-Alpha',
    'dsh-beta',
    'dsh-gamma',
  ])
  assert.deepEqual(sortPlugins([], 'stars'), [])
})

/* -------------------------------------------------------------------------------------------------
 * fetchCatalog
 * ----------------------------------------------------------------------------------------------- */

test('fetchCatalog falls back through mirrors and normalizes the first valid payload', async () => {
  const urls = mirrorUrls(3)
  const calls = []
  const fetchImpl = async (url, init) => {
    calls.push({ url, init })
    if (url === urls[0]) return { ok: false, status: 503, json: async () => ({}) }
    if (url === urls[1]) return { ok: true, status: 200, json: async () => ({ plugins: [] }) }
    return { ok: true, status: 200, json: async () => catalogPayload(101) }
  }

  const before = Date.now()
  const result = await fetchCatalog({ fetchImpl, urls, timeoutMs: 1000 })

  assert.equal(result.sourceUrl, urls[2])
  assert.equal(result.plugins.length, 101)
  assert.ok(Number.isFinite(result.fetchedAt) && result.fetchedAt >= before)
  assert.equal(result.plugins[0].id, 'owner-0/plugin-0')
  assert.equal(calls.length, 3)
  assert.ok(calls[0].init.signal instanceof AbortSignal, 'requests pass an AbortController signal')
})

test('fetchCatalog caches a successful result for the same mirror list', async () => {
  const urls = mirrorUrls(1)
  let fetchCount = 0
  const fetchImpl = async () => {
    fetchCount += 1
    return { ok: true, status: 200, json: async () => catalogPayload(150) }
  }

  const first = await fetchCatalog({ fetchImpl, urls, timeoutMs: 1000 })
  const second = await fetchCatalog({ fetchImpl, urls, timeoutMs: 1000 })
  assert.equal(fetchCount, 1)
  assert.equal(second, first, 'cached result is reused')

  const otherUrls = mirrorUrls(1)
  const third = await fetchCatalog({ fetchImpl, urls: otherUrls, timeoutMs: 1000 })
  assert.equal(fetchCount, 2, 'a different mirror list bypasses the cache')
  assert.equal(third.sourceUrl, otherUrls[0])
})

test('fetchCatalog rejects catalogs that are too small or malformed', async () => {
  const urls = mirrorUrls(3)
  let calls = 0
  const smallCatalog = async () => {
    calls += 1
    return { ok: true, status: 200, json: async () => catalogPayload(100) } // must be > 100
  }

  await assert.rejects(fetchCatalog({ fetchImpl: smallCatalog, urls, timeoutMs: 1000 }), (error) => {
    assert.equal(error.name, 'CatalogFetchError')
    assert.match(error.message, /catalog/i)
    return true
  })
  assert.equal(calls, 3)

  const notJson = async () => ({
    ok: true,
    status: 200,
    json: async () => {
      throw new Error('invalid json')
    },
  })
  await assert.rejects(fetchCatalog({ fetchImpl: notJson, urls: mirrorUrls(1), timeoutMs: 1000 }), (error) => {
    assert.equal(error.name, 'CatalogFetchError')
    return true
  })
})

test('fetchCatalog skips a bad mirror and uses the next one', async () => {
  const urls = mirrorUrls(2)
  const fetchImpl = async (url) => {
    if (url === urls[0]) {
      return {
        ok: true,
        status: 200,
        json: async () => {
          throw new Error('invalid json')
        },
      }
    }
    return { ok: true, status: 200, json: async () => catalogPayload(101) }
  }
  const result = await fetchCatalog({ fetchImpl, urls, timeoutMs: 1000 })
  assert.equal(result.sourceUrl, urls[1])
})

test('fetchCatalog aborts a hanging mirror after timeoutMs and moves on', async () => {
  const urls = mirrorUrls(2)
  const requested = []
  const fetchImpl = (url, init) => {
    requested.push(url)
    if (url === urls[0]) {
      return new Promise((resolve, reject) => {
        init.signal.addEventListener('abort', () => {
          const error = new Error('aborted')
          error.name = 'AbortError'
          reject(error)
        })
      })
    }
    return Promise.resolve({ ok: true, status: 200, json: async () => catalogPayload(101) })
  }

  const started = Date.now()
  const result = await fetchCatalog({ fetchImpl, urls, timeoutMs: 25 })
  const elapsed = Date.now() - started

  assert.equal(result.sourceUrl, urls[1])
  assert.deepEqual(requested, urls)
  assert.ok(elapsed >= 15, `expected the timeout to wait, took ${elapsed}ms`)
  assert.ok(elapsed < 2000, `expected the fallback to be fast, took ${elapsed}ms`)
})

test('fetchCatalog honours an already-aborted external signal without fetching', async () => {
  const controller = new AbortController()
  controller.abort()
  let called = false
  const fetchImpl = async () => {
    called = true
    return { ok: true, status: 200, json: async () => catalogPayload(101) }
  }
  await assert.rejects(
    fetchCatalog({ fetchImpl, urls: mirrorUrls(1), signal: controller.signal }),
    (error) => error.name === 'AbortError',
  )
  assert.equal(called, false)
})

/* -------------------------------------------------------------------------------------------------
 * createStoreController
 * ----------------------------------------------------------------------------------------------- */

test('controller starts idle with a stable frozen snapshot', () => {
  const controller = createStoreController({ snapshot: null })
  const snapshot = controller.getSnapshot()

  assert.equal(controller.getSnapshot(), snapshot)
  assert.equal(snapshot.status, 'idle')
  assert.equal(snapshot.refreshing, false)
  assert.equal(snapshot.error, null)
  assert.deepEqual(snapshot.source, { url: null, title: '', fetchedAt: null, offline: false })
  assert.deepEqual(snapshot.plugins, [])
  assert.deepEqual(snapshot.results, [])
  assert.deepEqual(snapshot.facets, { categories: [], capabilities: [] })
  assert.deepEqual(snapshot.query, { text: '', category: null, capabilities: [] })
  assert.equal(snapshot.sort, 'stars')
  assert.equal(snapshot.pageSize, PAGE_SIZE)
  assert.equal(snapshot.visible, 0)
  assert.equal(snapshot.total, 0)
  assert.equal(snapshot.hasMore, false)

  assert.ok(Object.isFrozen(snapshot))
  assert.ok(Object.isFrozen(snapshot.plugins))
  assert.ok(Object.isFrozen(snapshot.results))
  assert.ok(Object.isFrozen(snapshot.query))
  assert.ok(Object.isFrozen(snapshot.query.capabilities))
  assert.ok(Object.isFrozen(snapshot.source))
  assert.ok(Object.isFrozen(snapshot.facets.categories))
  assert.throws(() => snapshot.plugins.push({}), TypeError)
  controller.dispose()
})

test('controller load goes loading -> ready with facets, results and pagination', async () => {
  const { load: loader, calls } = loaderOf(makePlugins(65))
  const controller = createStoreController({ load: loader, snapshot: null })
  const states = []
  const unsubscribe = controller.subscribe((snapshot) => states.push(snapshot))

  const pending = controller.load()
  assert.equal(controller.getSnapshot().status, 'loading')
  assert.equal(controller.getSnapshot().refreshing, true)
  await pending
  unsubscribe()

  const snapshot = controller.getSnapshot()
  assert.equal(snapshot.status, 'ready')
  assert.equal(snapshot.refreshing, false)
  assert.equal(snapshot.error, null)
  assert.equal(calls.count, 1)
  assert.equal(snapshot.source.url, DEFAULT_SOURCE_URLS[0])
  assert.equal(snapshot.source.offline, false)
  assert.equal(snapshot.source.fetchedAt, 1700000000000)
  assert.equal(snapshot.plugins.length, 65)
  assert.equal(snapshot.total, 65)
  assert.equal(snapshot.visible, 60)
  assert.equal(snapshot.hasMore, true)
  assert.equal(snapshot.results.length, 65, 'results are not paginated')
  assert.equal(snapshot.results[0].stars, 64, 'default sort is stars desc')
  assert.equal(snapshot.facets.categories.length, 2)
  assert.deepEqual(states.map((state) => state.status), ['loading', 'ready'])
  controller.dispose()
})

test('controller load is idempotent: concurrent calls share one promise', async () => {
  const { load: loader, calls } = loaderOf(makePlugins(3))
  const controller = createStoreController({ load: loader, snapshot: null })

  const first = controller.load()
  const second = controller.load()
  assert.equal(first, second, 'concurrent load calls share the in-flight promise')
  await first
  assert.equal(calls.count, 1)

  await controller.load()
  assert.equal(calls.count, 1, 'load() is a no-op once ready')
  controller.dispose()
})

test('controller refresh keeps the current list visible and updates the data', async () => {
  let version = 0
  const controller = createStoreController({
    snapshot: null,
    load: async () => {
      version += 1
      return {
        plugins: version === 1 ? makePlugins(2) : makePlugins(4),
        sourceUrl: DEFAULT_SOURCE_URLS[1],
        fetchedAt: version,
      }
    },
  })

  await controller.load()
  const ready = controller.getSnapshot()
  assert.equal(ready.plugins.length, 2)

  const pending = controller.refresh()
  const during = controller.getSnapshot()
  assert.equal(during.refreshing, true)
  assert.equal(during.status, 'ready')
  assert.equal(during.plugins.length, 2, 'previous list stays visible while refreshing')

  await pending
  const after = controller.getSnapshot()
  assert.equal(after.refreshing, false)
  assert.equal(after.plugins.length, 4)
  assert.equal(after.total, 4)
  assert.equal(after.source.url, DEFAULT_SOURCE_URLS[1])
  assert.notEqual(after, ready)
  controller.dispose()
})

test('controller surfaces a load error and recovers on retry', async () => {
  let fail = true
  let attempts = 0
  const controller = createStoreController({
    snapshot: null,
    load: async () => {
      attempts += 1
      if (fail) throw new Error('network down')
      return { plugins: makePlugins(3), sourceUrl: DEFAULT_SOURCE_URLS[2], fetchedAt: 5 }
    },
  })

  await controller.load()
  let snapshot = controller.getSnapshot()
  assert.equal(snapshot.status, 'error')
  assert.equal(snapshot.refreshing, false)
  assert.equal(snapshot.error, 'network down')
  assert.deepEqual(snapshot.plugins, [])

  await controller.load()
  assert.equal(attempts, 1, 'a plain load() after an error does not refetch')

  fail = false
  await controller.retry()
  snapshot = controller.getSnapshot()
  assert.equal(snapshot.status, 'ready')
  assert.equal(snapshot.error, null)
  assert.equal(snapshot.refreshing, false)
  assert.equal(snapshot.plugins.length, 3)
  assert.equal(attempts, 2)
  controller.dispose()
})

test('controller keeps the previous catalog when a refresh fails', async () => {
  let fail = false
  const controller = createStoreController({
    snapshot: null,
    load: async () => {
      if (fail) throw new Error('refresh boom')
      return { plugins: makePlugins(3), sourceUrl: DEFAULT_SOURCE_URLS[0], fetchedAt: 1 }
    },
  })

  await controller.load()
  const before = controller.getSnapshot()
  fail = true
  await controller.refresh()
  const after = controller.getSnapshot()

  assert.equal(after.status, 'ready')
  assert.equal(after.refreshing, false)
  assert.equal(after.error, 'refresh boom')
  assert.equal(after.plugins.length, 3)
  assert.equal(after.total, before.total)
  assert.deepEqual(after.results, before.results)
  controller.dispose()
})

test('controller falls back to the injected snapshot when loading fails', async () => {
  const injected = {
    sourceUrl: 'https://awesome-dsh-plugin.com/plugins.json',
    generatedAt: '2026-11-01T00:00:00.000Z',
    plugins: makePlugins(4),
  }
  const controller = createStoreController({
    snapshot: injected,
    load: async () => {
      throw new Error('offline')
    },
  })

  await controller.load()
  const state = controller.getSnapshot()
  assert.equal(state.status, 'ready')
  assert.equal(state.error, null)
  assert.equal(state.source.offline, true)
  assert.equal(state.source.url, injected.sourceUrl)
  assert.equal(state.source.title, 'Built-in snapshot')
  assert.equal(state.source.fetchedAt, Date.parse(injected.generatedAt))
  assert.equal(state.plugins.length, 4)
  assert.equal(state.total, 4)
  assert.ok(state.facets.categories.length > 0)
  controller.dispose()
})

test('controller falls back to the bundled SNAPSHOT by default', async () => {
  const controller = createStoreController({
    load: async () => {
      throw new Error('offline')
    },
  })
  await controller.load()
  const state = controller.getSnapshot()
  assert.equal(state.status, 'ready')
  assert.equal(state.error, null)
  assert.equal(state.source.offline, true)
  assert.equal(state.source.url, SNAPSHOT.sourceUrl)
  assert.ok(state.plugins.length > 0)
  assert.ok(state.facets.categories.length > 0)
  assert.ok(state.results.length > 0)
  controller.dispose()
})

test('controller can reach ready with an empty catalog', async () => {
  const controller = createStoreController({
    snapshot: null,
    load: async () => ({ plugins: [], sourceUrl: DEFAULT_SOURCE_URLS[0], fetchedAt: 1 }),
  })
  await controller.load()
  const state = controller.getSnapshot()
  assert.equal(state.status, 'ready')
  assert.equal(state.total, 0)
  assert.equal(state.visible, 0)
  assert.equal(state.hasMore, false)
  controller.dispose()
})

test('controller filters by text/category/capabilities and clears filters', async () => {
  const controller = createStoreController({
    snapshot: null,
    load: async () => ({ plugins: fixturePlugins(), sourceUrl: DEFAULT_SOURCE_URLS[0], fetchedAt: 1 }),
  })
  await controller.load()
  assert.equal(controller.getSnapshot().total, 4)

  controller.setText('UI')
  let state = controller.getSnapshot()
  assert.equal(state.query.text, 'UI')
  assert.deepEqual(state.results.map((plugin) => plugin.name), ['dsh-ui-read', 'dsh-ui-shell'])
  assert.equal(state.total, 2)
  assert.equal(state.visible, 2)
  assert.equal(state.hasMore, false)
  assert.equal(state.facets.categories.length, 2, 'facets stay computed over all plugins')

  controller.clearFilters()
  assert.equal(controller.getSnapshot().total, 4)

  controller.setCategory('tools')
  state = controller.getSnapshot()
  assert.equal(state.query.category, 'tools')
  assert.deepEqual(state.results.map((plugin) => plugin.name), ['dsh-tool-net', 'dsh-tool-shell'])

  controller.toggleCapability('shell')
  state = controller.getSnapshot()
  assert.deepEqual(state.query.capabilities, ['shell'])
  assert.deepEqual(state.results.map((plugin) => plugin.name), ['dsh-tool-shell'])

  controller.toggleCapability('network')
  state = controller.getSnapshot()
  assert.deepEqual(state.query.capabilities, ['shell', 'network'])
  assert.deepEqual(state.results.map((plugin) => plugin.name), ['dsh-tool-shell'])

  controller.toggleCapability('shell')
  state = controller.getSnapshot()
  assert.deepEqual(state.query.capabilities, ['network'])
  assert.deepEqual(state.results.map((plugin) => plugin.name), ['dsh-tool-net', 'dsh-tool-shell'])

  controller.clearFilters()
  state = controller.getSnapshot()
  assert.deepEqual(state.query, { text: '', category: null, capabilities: [] })
  assert.equal(state.total, 4)
  controller.dispose()
})

test('controller sorting and no-op setters keep snapshot identity stable', async () => {
  const controller = createStoreController({
    snapshot: null,
    load: async () => ({ plugins: fixturePlugins(), sourceUrl: DEFAULT_SOURCE_URLS[0], fetchedAt: 1 }),
  })
  await controller.load()
  const ready = controller.getSnapshot()

  controller.setText('')
  assert.equal(controller.getSnapshot(), ready)
  controller.setCategory(null)
  assert.equal(controller.getSnapshot(), ready)
  controller.setSort('stars')
  assert.equal(controller.getSnapshot(), ready)
  controller.setSort('bogus')
  assert.equal(controller.getSnapshot(), ready)
  controller.toggleCapability('not-a-capability')
  assert.equal(controller.getSnapshot(), ready)

  controller.setSort('name')
  let state = controller.getSnapshot()
  assert.equal(state.sort, 'name')
  assert.deepEqual(state.results.map((plugin) => plugin.name), [
    'dsh-tool-net', 'dsh-tool-shell', 'dsh-ui-read', 'dsh-ui-shell',
  ])

  controller.setSort('added')
  state = controller.getSnapshot()
  assert.deepEqual(state.results.map((plugin) => plugin.name), [
    'dsh-tool-shell', 'dsh-ui-shell', 'dsh-ui-read', 'dsh-tool-net',
  ])
  controller.dispose()
})

test('controller pagination counters and showMore', async () => {
  const plugins = Array.from({ length: 130 }, (_, index) => rawEntry({
    name: `plugin-${String(index).padStart(3, '0')}`,
    owner: 'octo',
    category: 'ui',
    capabilities: ['fs-read'],
    stars: index,
    added: `2026-01-${String((index % 28) + 1).padStart(2, '0')}`,
  }))
  const controller = createStoreController({
    snapshot: null,
    load: async () => ({ plugins, sourceUrl: DEFAULT_SOURCE_URLS[0], fetchedAt: 1 }),
  })
  await controller.load()

  let state = controller.getSnapshot()
  assert.equal(state.total, 130)
  assert.equal(state.pageSize, 60)
  assert.equal(state.visible, 60)
  assert.equal(state.hasMore, true)
  assert.equal(state.results.length, 130)

  controller.showMore()
  state = controller.getSnapshot()
  assert.equal(state.visible, 120)
  assert.equal(state.hasMore, true)
  assert.equal(state.total, 130)

  controller.showMore()
  state = controller.getSnapshot()
  assert.equal(state.visible, 130)
  assert.equal(state.hasMore, false)
  const complete = state

  controller.showMore()
  assert.equal(controller.getSnapshot(), complete, 'showMore is a no-op on the last page')

  controller.setText('plugin-01')
  state = controller.getSnapshot()
  assert.equal(state.total, 10)
  assert.equal(state.visible, 10, 'filtering resets pagination')
  assert.equal(state.hasMore, false)
  controller.dispose()
})

test('controller subscribe returns an unsubscribe function and survives throwing listeners', async () => {
  const controller = createStoreController({
    snapshot: null,
    load: async () => ({ plugins: makePlugins(2), sourceUrl: DEFAULT_SOURCE_URLS[0], fetchedAt: 1 }),
  })
  const seen = []
  const unsubscribeBad = controller.subscribe(() => {
    throw new Error('subscriber boom')
  })
  const unsubscribeGood = controller.subscribe((snapshot) => seen.push(snapshot.status))

  await controller.load()
  assert.deepEqual(seen, ['loading', 'ready'])

  unsubscribeBad()
  unsubscribeGood()
  controller.setText('x')
  assert.deepEqual(seen, ['loading', 'ready'])
  controller.dispose()
})

test('controller dispose stops notifications and ignores further mutations/loads', async () => {
  const { load: loader, calls } = loaderOf(makePlugins(5))
  const controller = createStoreController({ load: loader, snapshot: null })
  await controller.load()

  let notifications = 0
  controller.subscribe(() => {
    notifications += 1
  })

  controller.dispose()
  const frozen = controller.getSnapshot()
  controller.setText('nothing')
  controller.setCategory('ui')
  controller.toggleCapability('shell')
  controller.clearFilters()
  controller.setSort('name')
  controller.showMore()
  await controller.load()
  controller.dispose() // idempotent

  assert.equal(controller.getSnapshot(), frozen)
  assert.equal(notifications, 0)
  assert.equal(calls.count, 1, 'load() after dispose does not fetch')
})

test('controller ignores an in-flight load that finishes after dispose', async () => {
  let resolveLoad
  const pending = new Promise((resolve) => {
    resolveLoad = resolve
  })
  const controller = createStoreController({ snapshot: null, load: () => pending })

  const loadPromise = controller.load()
  assert.equal(controller.getSnapshot().status, 'loading')
  controller.dispose()
  resolveLoad({ plugins: makePlugins(3), sourceUrl: DEFAULT_SOURCE_URLS[0], fetchedAt: 1 })
  await loadPromise

  assert.equal(controller.getSnapshot().status, 'loading')
  assert.deepEqual(controller.getSnapshot().plugins, [])
})

test('controller accepts already-normalized plugin lists from deps.load', async () => {
  const alreadyNormalized = normalizeCatalog([rawEntry({ name: 'dsh-x', owner: 'octo' })])
  const controller = createStoreController({
    snapshot: null,
    load: async () => ({ plugins: alreadyNormalized, sourceUrl: DEFAULT_SOURCE_URLS[0], fetchedAt: 1 }),
  })
  await controller.load()
  const plugin = controller.getSnapshot().plugins[0]
  assert.equal(plugin.id, 'octo/dsh-x')
  assert.equal(plugin.repo, 'https://github.com/octo/dsh-demo')
  controller.dispose()
})

test('controller falls back to fetchCatalog (mocked global fetch) when no loader is injected', async () => {
  const originalFetch = globalThis.fetch
  try {
    globalThis.fetch = async (url) => {
      assert.equal(url, DEFAULT_SOURCE_URLS[0], 'the first mirror is tried first')
      return { ok: true, status: 200, json: async () => catalogPayload(101) }
    }
    const controller = createStoreController({ snapshot: null })
    await controller.load()
    const state = controller.getSnapshot()
    assert.equal(state.status, 'ready')
    assert.equal(state.plugins.length, 101)
    assert.equal(state.source.url, DEFAULT_SOURCE_URLS[0])
    assert.equal(state.source.offline, false)
    controller.dispose()
  } finally {
    globalThis.fetch = originalFetch
  }
})
