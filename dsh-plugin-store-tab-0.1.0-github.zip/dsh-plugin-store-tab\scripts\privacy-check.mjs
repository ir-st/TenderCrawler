#!/usr/bin/env node
/**
 * Pre-commit privacy check for this repository.
 *
 * Fails when tracked sources contain machine-specific or secret-looking content:
 *   - absolute home/user paths (C:\Users\..., /Users/..., /home/...)
 *   - email addresses (use a GitHub noreply address in commits instead)
 *   - API tokens / private keys / credential-bearing URLs
 *   - machine-specific config files accidentally added at the repo root
 *
 * Public catalog data is allowed: plugin descriptions in snapshot.data.js may contain the words
 * "password", "secret" or "api_key" because they describe third-party plugins. This script looks
 * for actual values (token shapes, key blocks, credentials in URLs), not those words.
 *
 * Usage: node scripts/privacy-check.mjs
 */

import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const SKIP_DIRS = new Set(['node_modules', '.git', 'artifacts', 'coverage'])
const SKIP_EXT = new Set(['.png', '.jpg', '.jpeg', '.webp', '.gif', '.tgz', '.zip', '.woff', '.woff2'])

const PATTERNS = [
  ['absolute home path', /(?:[A-Za-z]:[\\/]+Users[\\/]+|\/Users\/|\/home\/)[^\s"'<>\\/]+/g],
  ['email address', /[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}/g],
  ['known token shape', /\b(?:sk|ghp|gho|ghs|github_pat|xox[baprs])[_-][A-Za-z0-9_-]{20,}/g],
  ['AWS access key id', /\bAKIA[0-9A-Z]{16}\b/g],
  ['private key block', /BEGIN (?:RSA |EC |OPENSSH |DSA )?PRIVATE KEY/g],
  ['credential URL', /https?:\/\/[^\s"'<>]*:[^\s"'<>@/]*@[^\s"'<>]+/g],
  ['secret query parameter', /[?&](?:token|api_key|apikey|access_token|secret|signature|sig)=[^\s&"'<>]+/gi],
]

const MACHINE_FILES = new Set(['.npmrc', '.env', '.env.local', '.netrc', '.git-credentials'])

const files = []
function walk(dir) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    if (entry.isDirectory()) {
      if (!SKIP_DIRS.has(entry.name)) walk(path.join(dir, entry.name))
      continue
    }
    if (SKIP_EXT.has(path.extname(entry.name).toLowerCase())) continue
    files.push(path.join(dir, entry.name))
  }
}
walk(ROOT)

const findings = []
const SELF = path.resolve(fileURLToPath(import.meta.url))
for (const file of files) {
  // This script documents the patterns it forbids; scanning itself would always self-flag.
  if (path.resolve(file) === SELF) continue
  const relative = path.relative(ROOT, file)
  if (MACHINE_FILES.has(path.basename(file)) && path.dirname(file) === ROOT) {
    findings.push({ file: relative, label: 'machine-specific file', sample: path.basename(file) })
  }
  const text = fs.readFileSync(file, 'utf8')
  for (const [label, pattern] of PATTERNS) {
    for (const match of text.matchAll(pattern)) {
      findings.push({ file: relative, label, sample: match[0].slice(0, 140) })
    }
  }
}

if (findings.length === 0) {
  console.log(`privacy-check: OK (${files.length} files scanned, no sensitive patterns)`)
  process.exit(0)
}

console.error(`privacy-check: ${findings.length} finding(s)`)
for (const finding of findings) console.error(`  [${finding.label}] ${finding.file}: ${finding.sample}`)
console.error('\nRemove the values above before committing/publishing.')
process.exit(1)
