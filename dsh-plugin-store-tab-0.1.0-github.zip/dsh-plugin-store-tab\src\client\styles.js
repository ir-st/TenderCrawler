/**
 * Scoped stylesheet for the Store tab.
 *
 * Exported as one string; `index.jsx` injects it once into a `<style>` tag.
 * Every selector is scoped under `.ps-root` so the host GUI styles are never
 * touched. Colors, radii and focus rings reuse the DSH design tokens listed in
 * CONTRACT.md (each with a safe fallback), so light and dark themes both work.
 */
export const STORE_CSS = `
.ps-root {
  display: flex;
  flex-direction: column;
  gap: 14px;
  min-width: 0;
  font-size: 13px;
  line-height: 1.5;
  color: var(--dsw-alias-label-primary, inherit);
}

/* ---------- header ---------- */
.ps-root .ps-header {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 12px;
  flex-wrap: wrap;
}
.ps-root .ps-heading {
  min-width: 0;
}
.ps-root .ps-title {
  margin: 0;
  font-size: 20px;
  line-height: 1.3;
  font-weight: 600;
}
.ps-root .ps-subtitle {
  margin: 4px 0 0;
  font-size: 12px;
  color: var(--dsw-alias-label-secondary, #666);
}
.ps-root .ps-header-actions {
  display: flex;
  align-items: center;
  gap: 10px;
  margin-left: auto;
}
.ps-root .ps-count {
  font-size: 12px;
  color: var(--dsw-alias-label-tertiary, #888);
  white-space: nowrap;
}

/* ---------- buttons ---------- */
.ps-root .ps-button,
.ps-root .ps-refresh {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  padding: 6px 12px;
  border: 1px solid var(--dsw-alias-border-l2, rgba(127, 127, 127, 0.28));
  border-radius: var(--dsw-radius-md, 8px);
  background: transparent;
  color: inherit;
  font: inherit;
  font-size: 12px;
  line-height: 1.4;
  cursor: pointer;
  transition: background-color 0.12s ease, border-color 0.12s ease, color 0.12s ease;
}
.ps-root .ps-button:hover,
.ps-root .ps-refresh:hover {
  background: var(--dsw-alias-interactive-bg-hover, rgba(127, 127, 127, 0.12));
  border-color: var(--dsw-alias-border-l3, rgba(127, 127, 127, 0.4));
}
.ps-root .ps-button-primary {
  border-color: var(--dsw-alias-link, #3f7fff);
  color: var(--dsw-alias-link, #3f7fff);
}
.ps-root .ps-button:disabled,
.ps-root .ps-refresh:disabled {
  cursor: default;
  opacity: 0.55;
}
.ps-root .ps-refresh:disabled:hover {
  background: transparent;
  border-color: var(--dsw-alias-border-l2, rgba(127, 127, 127, 0.28));
}
.ps-root .ps-refresh-icon {
  flex: none;
}

/* ---------- spinner ---------- */
.ps-root .ps-spinner {
  display: inline-block;
  width: 12px;
  height: 12px;
  flex: none;
  border: 2px solid currentColor;
  border-right-color: transparent;
  border-radius: 50%;
  animation: ps-spin 0.8s linear infinite;
}

@keyframes ps-spin {
  to {
    transform: rotate(360deg);
  }
}

/* ---------- toolbar ---------- */
.ps-root .ps-toolbar {
  display: flex;
  align-items: center;
  gap: 8px;
  flex-wrap: wrap;
}
.ps-root .ps-search {
  flex: 1 1 220px;
  min-width: 0;
  padding: 7px 10px;
  border: 1px solid var(--dsw-alias-border-l2, rgba(127, 127, 127, 0.28));
  border-radius: var(--dsw-radius-md, 8px);
  background: transparent;
  color: inherit;
  font: inherit;
  font-size: 13px;
}
.ps-root .ps-search::placeholder {
  color: var(--dsw-alias-label-tertiary, #888);
}
.ps-root .ps-sort {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  flex: none;
  font-size: 12px;
  color: var(--dsw-alias-label-secondary, #666);
}
.ps-root .ps-sort-label {
  white-space: nowrap;
}
.ps-root .ps-select {
  padding: 6px 8px;
  border: 1px solid var(--dsw-alias-border-l2, rgba(127, 127, 127, 0.28));
  border-radius: var(--dsw-radius-md, 8px);
  background: var(--dsw-alias-bg-module-platform, transparent);
  color: inherit;
  font: inherit;
  font-size: 12px;
}

/* ---------- filter chip rows ---------- */
.ps-root .ps-filters {
  display: flex;
  flex-direction: column;
  gap: 8px;
}
.ps-root .ps-chip-row {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 6px;
}
.ps-root .ps-chip-row-label {
  margin-right: 2px;
  font-size: 12px;
  color: var(--dsw-alias-label-tertiary, #888);
  white-space: nowrap;
}
.ps-root .ps-chip {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  padding: 3px 9px;
  border: 1px solid var(--dsw-alias-border-l2, rgba(127, 127, 127, 0.28));
  border-radius: 999px;
  background: transparent;
  color: var(--dsw-alias-label-secondary, #666);
  font: inherit;
  font-size: 12px;
  line-height: 1.4;
  cursor: pointer;
  transition: background-color 0.12s ease, border-color 0.12s ease, color 0.12s ease;
}
.ps-root .ps-chip:hover {
  background: var(--dsw-alias-interactive-bg-hover, rgba(127, 127, 127, 0.12));
  color: var(--dsw-alias-label-primary, inherit);
}
.ps-root .ps-chip[aria-pressed="true"] {
  border-color: var(--dsw-alias-link, #3f7fff);
  color: var(--dsw-alias-link, #3f7fff);
  background: var(--dsw-alias-interactive-bg-hover, rgba(63, 127, 255, 0.12));
}
.ps-root .ps-chip-count {
  font-size: 11px;
  opacity: 0.7;
}
.ps-root .ps-chip-tiny {
  padding: 1px 6px;
  font-size: 11px;
  border-color: var(--dsw-alias-border-l2, rgba(127, 127, 127, 0.28));
  color: var(--dsw-alias-label-tertiary, #888);
  cursor: default;
}
.ps-root .ps-chip-tiny:hover {
  background: transparent;
  color: var(--dsw-alias-label-tertiary, #888);
}

/* ---------- grid + cards ---------- */
.ps-root .ps-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(260px, 1fr));
  gap: 10px;
}
.ps-root .ps-card {
  display: flex;
  align-items: flex-start;
  gap: 10px;
  min-width: 0;
  padding: 12px;
  border: 1px solid var(--dsw-alias-border-l2, rgba(127, 127, 127, 0.28));
  border-radius: var(--dsw-radius-lg, 12px);
  background: var(--dsw-alias-bg-module-platform, transparent);
  color: inherit;
  font: inherit;
  text-align: left;
  cursor: pointer;
  transition: background-color 0.12s ease, border-color 0.12s ease;
}
.ps-root .ps-card:hover {
  background: var(--dsw-alias-interactive-bg-hover, rgba(127, 127, 127, 0.1));
  border-color: var(--dsw-alias-border-l3, rgba(127, 127, 127, 0.4));
}
.ps-root .ps-card-main {
  display: flex;
  flex-direction: column;
  gap: 3px;
  flex: 1 1 auto;
  min-width: 0;
}
.ps-root .ps-card-title {
  overflow: hidden;
  font-size: 14px;
  font-weight: 600;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ps-root .ps-card-owner {
  overflow: hidden;
  font-size: 12px;
  color: var(--dsw-alias-label-tertiary, #888);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ps-root .ps-card-desc {
  display: -webkit-box;
  overflow: hidden;
  font-size: 12px;
  color: var(--dsw-alias-label-secondary, #666);
  overflow-wrap: anywhere;
  -webkit-box-orient: vertical;
  -webkit-line-clamp: 2;
  line-clamp: 2;
}
.ps-root .ps-card-tags {
  display: flex;
  flex-wrap: wrap;
  gap: 4px;
  margin-top: 2px;
}
.ps-root .ps-card-meta {
  display: flex;
  align-items: center;
  gap: 8px;
  margin-top: 3px;
  font-size: 11px;
  color: var(--dsw-alias-label-tertiary, #888);
}
.ps-root .ps-stars::before {
  content: "\\2605";
  margin-right: 3px;
}
.ps-root .ps-badge {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  padding: 0 5px;
  border: 1px solid var(--dsw-alias-border-l2, rgba(127, 127, 127, 0.28));
  border-radius: 4px;
  font-size: 10px;
  line-height: 1.6;
  letter-spacing: 0.02em;
}
.ps-root .ps-badge-version {
  opacity: 0.8;
}

/* ---------- artwork ---------- */
.ps-root .ps-art {
  width: 48px;
  height: 48px;
  flex: none;
  border-radius: var(--dsw-radius-md, 8px);
  background: var(--dsw-alias-interactive-bg-hover, rgba(127, 127, 127, 0.12));
  object-fit: cover;
}
.ps-root .ps-art-lg {
  width: 56px;
  height: 56px;
}
.ps-root .ps-art-letter {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  font-size: 19px;
  font-weight: 600;
  line-height: 1;
  letter-spacing: 0.02em;
  color: #fff;
  background: var(--ps-letter-bg, #5b7cfa);
  background: linear-gradient(
    135deg,
    color-mix(in srgb, var(--ps-letter-bg, #5b7cfa) 78%, #ffffff),
    var(--ps-letter-bg, #5b7cfa) 55%,
    color-mix(in srgb, var(--ps-letter-bg, #5b7cfa) 72%, #000000)
  );
  box-shadow: inset 0 0 0 0.5px rgba(255, 255, 255, 0.22);
}
.ps-root .ps-art-lg.ps-art-letter {
  font-size: 24px;
}

/* ---------- loading skeleton ---------- */
.ps-root .ps-loading {
  display: flex;
  flex-direction: column;
  gap: 4px;
}
.ps-root .ps-loading-title {
  margin: 0;
  font-size: 13px;
}
.ps-root .ps-loading-hint {
  margin: 0 0 6px;
  font-size: 12px;
  color: var(--dsw-alias-label-tertiary, #888);
}
.ps-root .ps-grid-skeleton {
  margin-top: 2px;
}
.ps-root .ps-card-skeleton {
  cursor: default;
  pointer-events: none;
}
.ps-root .ps-skeleton {
  display: block;
  border-radius: 4px;
  background: var(--dsw-alias-interactive-bg-hover, rgba(127, 127, 127, 0.14));
  animation: ps-pulse 1.4s ease-in-out infinite;
}
.ps-root .ps-skeleton-art {
  width: 48px;
  height: 48px;
  flex: none;
  border-radius: var(--dsw-radius-md, 8px);
}
.ps-root .ps-skeleton-lines {
  display: flex;
  flex-direction: column;
  gap: 6px;
  flex: 1 1 auto;
  min-width: 0;
}
.ps-root .ps-skeleton-line {
  width: 100%;
  height: 9px;
}
.ps-root .ps-skeleton-title {
  width: 55%;
  height: 11px;
}
.ps-root .ps-skeleton-short {
  width: 70%;
}

@keyframes ps-pulse {
  0%,
  100% {
    opacity: 0.55;
  }
  50% {
    opacity: 1;
  }
}

/* ---------- state panels + stale-data banner ---------- */
.ps-root .ps-state {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 8px;
  padding: 36px 20px;
  border: 1px dashed var(--dsw-alias-border-l2, rgba(127, 127, 127, 0.28));
  border-radius: var(--dsw-radius-lg, 12px);
  text-align: center;
}
.ps-root .ps-state-title {
  margin: 0;
  font-size: 15px;
  font-weight: 600;
}
.ps-root .ps-state-text {
  margin: 0;
  max-width: 52ch;
  font-size: 12px;
  color: var(--dsw-alias-label-secondary, #666);
}
.ps-root .ps-state-detail {
  margin: 0;
  max-width: 60ch;
  font-size: 11px;
  color: var(--dsw-alias-state-error-primary, #c0392b);
  overflow-wrap: anywhere;
}
.ps-root .ps-state-actions {
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
  gap: 8px;
  margin-top: 6px;
}
.ps-root .ps-banner {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 10px;
  padding: 8px 10px;
  border: 1px solid var(--dsw-alias-state-error-primary, #c0392b);
  border-radius: var(--dsw-radius-md, 8px);
  color: var(--dsw-alias-state-error-primary, #c0392b);
  font-size: 12px;
  overflow-wrap: anywhere;
}

/* ---------- pagination ---------- */
.ps-root .ps-more {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 12px;
  padding: 2px 0 4px;
}
.ps-root .ps-more-count {
  font-size: 12px;
  color: var(--dsw-alias-label-tertiary, #888);
}

/* ---------- detail view ---------- */
.ps-root .ps-detail {
  display: flex;
  flex-direction: column;
  gap: 14px;
  min-width: 0;
}
.ps-root .ps-back {
  align-self: flex-start;
  display: inline-flex;
  align-items: center;
  gap: 5px;
  padding: 4px 8px;
  border: 0;
  border-radius: var(--dsw-radius-md, 8px);
  background: transparent;
  color: var(--dsw-alias-label-secondary, #666);
  font: inherit;
  font-size: 12px;
  cursor: pointer;
  transition: background-color 0.12s ease, color 0.12s ease;
}
.ps-root .ps-back::before {
  content: "\\2190";
  font-size: 13px;
}
.ps-root .ps-back:hover {
  background: var(--dsw-alias-interactive-bg-hover, rgba(127, 127, 127, 0.12));
  color: var(--dsw-alias-label-primary, inherit);
}
.ps-root .ps-detail-head {
  display: flex;
  align-items: flex-start;
  gap: 14px;
}
.ps-root .ps-detail-headings {
  display: flex;
  flex-direction: column;
  gap: 3px;
  min-width: 0;
}
.ps-root .ps-detail-title {
  margin: 0;
  font-size: 20px;
  font-weight: 600;
  line-height: 1.3;
  overflow-wrap: anywhere;
}
.ps-root .ps-detail-owner {
  margin: 0;
  font-size: 12px;
  color: var(--dsw-alias-label-tertiary, #888);
}
.ps-root .ps-detail-desc {
  margin: 0;
  max-width: 80ch;
  font-size: 13px;
  line-height: 1.6;
  color: var(--dsw-alias-label-secondary, #666);
  white-space: pre-wrap;
  overflow-wrap: anywhere;
}
.ps-root .ps-detail-section {
  display: flex;
  flex-direction: column;
  gap: 6px;
  min-width: 0;
}
.ps-root .ps-detail-heading {
  margin: 0;
  font-size: 12px;
  font-weight: 600;
  color: var(--dsw-alias-label-tertiary, #888);
}
.ps-root .ps-tag-row {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
}
.ps-root .ps-facts {
  display: flex;
  flex-direction: column;
  gap: 5px;
  margin: 0;
}
.ps-root .ps-fact {
  display: flex;
  align-items: baseline;
  gap: 8px;
  font-size: 12px;
}
.ps-root .ps-fact dt {
  flex: none;
  width: 76px;
  color: var(--dsw-alias-label-tertiary, #888);
}
.ps-root .ps-fact dd {
  margin: 0;
  min-width: 0;
  overflow-wrap: anywhere;
}
.ps-root .ps-install {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 8px;
  padding: 8px 10px;
  border: 1px solid var(--dsw-alias-border-l2, rgba(127, 127, 127, 0.28));
  border-radius: var(--dsw-radius-md, 8px);
  background: var(--dsw-alias-bg-module-platform, transparent);
}
.ps-root .ps-install code {
  flex: 1 1 auto;
  min-width: 0;
  overflow-x: auto;
  font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
  font-size: 12px;
  line-height: 1.6;
  white-space: nowrap;
  background: transparent;
  color: var(--dsw-alias-label-primary, inherit);
}
.ps-root .ps-install-hint {
  margin: 6px 0 0;
  font-size: 11px;
  color: var(--dsw-alias-label-tertiary, #888);
}
.ps-root .ps-links {
  display: flex;
  flex-wrap: wrap;
  gap: 10px;
}
.ps-root .ps-link {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  font-size: 12px;
  color: var(--dsw-alias-link, #3f7fff);
  text-decoration: none;
  overflow-wrap: anywhere;
}
.ps-root .ps-link:hover {
  text-decoration: underline;
}
.ps-root .ps-link::after {
  content: "\\2197";
  font-size: 11px;
}

/* ---------- footer ---------- */
.ps-root .ps-footer {
  display: flex;
  flex-direction: column;
  gap: 2px;
  padding-top: 8px;
  border-top: 1px solid var(--dsw-alias-border-l2, rgba(127, 127, 127, 0.28));
  font-size: 11px;
  color: var(--dsw-alias-label-tertiary, #888);
}
.ps-root .ps-source {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 6px;
  margin: 0;
  min-width: 0;
}
.ps-root .ps-source-label {
  font-weight: 600;
}
.ps-root .ps-source-value {
  overflow-wrap: anywhere;
}
.ps-root .ps-source-url {
  max-width: 100%;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
  opacity: 0.8;
}
.ps-root .ps-attribution {
  margin: 0;
  line-height: 1.5;
}

/* ---------- a11y helpers ---------- */
.ps-root .ps-visually-hidden {
  position: absolute;
  width: 1px;
  height: 1px;
  margin: -1px;
  padding: 0;
  overflow: hidden;
  clip: rect(0 0 0 0);
  white-space: nowrap;
  border: 0;
}
.ps-root :focus-visible {
  outline: var(--dsw-focus-ring-width, 2px) solid var(--dsw-focus-ring-color, #3f7fff);
  outline-offset: 2px;
}
.ps-root .ps-card:focus-visible,
.ps-root .ps-chip:focus-visible {
  outline-offset: 1px;
}

/* ---------- responsive (works down to 360px) ---------- */
@media (max-width: 480px) {
  .ps-root .ps-header {
    flex-direction: column;
    align-items: stretch;
  }
  .ps-root .ps-header-actions {
    margin-left: 0;
    justify-content: space-between;
  }
  .ps-root .ps-grid {
    grid-template-columns: 1fr;
  }
  .ps-root .ps-detail-head {
    flex-direction: column;
  }
  .ps-root .ps-fact dt {
    width: 64px;
  }
}

/* ---------- reduced motion ---------- */
@media (prefers-reduced-motion: reduce) {
  .ps-root .ps-card,
  .ps-root .ps-chip,
  .ps-root .ps-button,
  .ps-root .ps-refresh,
  .ps-root .ps-back,
  .ps-root .ps-link {
    transition: none;
  }
  .ps-root .ps-skeleton {
    animation: none;
    opacity: 0.7;
  }
  .ps-root .ps-spinner {
    animation-duration: 2.4s;
  }
}
`
